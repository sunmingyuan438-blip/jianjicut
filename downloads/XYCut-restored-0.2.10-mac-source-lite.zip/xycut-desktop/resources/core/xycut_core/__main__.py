import sys
from .runner import main
raise SystemExit(main())
