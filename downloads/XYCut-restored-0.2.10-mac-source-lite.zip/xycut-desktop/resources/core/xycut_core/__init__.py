"""Recovered bytecode loader; requires CPython 3.9."""
from xycut_core._recovery_loader import hydrate as _hydrate
_hydrate(__name__, globals(), __file__)
