"""Load normalized Python bytecode without the original Windows runtime."""
import ast
import importlib
import json
import marshal
import sys
import types
from pathlib import Path

def hydrate(module_name, namespace, module_file):
    if sys.version_info[:2] != (3, 9):
        raise RuntimeError("Recovered bytecode requires CPython 3.9; use decompiled source for migration.")
    file = Path(module_file)
    metadata = json.loads(file.with_suffix(".exports.json").read_text("utf-8"))
    for name, text in metadata["constants"].items():
        namespace[name] = ast.literal_eval(text)
    for item in metadata["functions"]:
        code = marshal.loads((file.parent / item["bytecode"]).read_bytes())
        function = types.FunctionType(code, namespace, item["name"],
                                      ast.literal_eval(item["defaults"]))
        function.__kwdefaults__ = ast.literal_eval(item["keyword_defaults"])
        function.__annotations__ = ast.literal_eval(item["annotations"])
        namespace[item["name"]] = function
    for item in metadata["imports"]:
        imported = importlib.import_module(item["module"])
        namespace[item["name"]] = getattr(imported, item["attribute"]) if "attribute" in item else imported
