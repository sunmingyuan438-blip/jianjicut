from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
from pathlib import Path


PERCENTS_BY_COUNT = {
    3: [0.2, 0.5, 0.8],
    4: [0.15, 0.38, 0.62, 0.85],
    5: [0.1, 0.3, 0.5, 0.7, 0.9],
}


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, text=True, capture_output=True)


def require_ok(result: subprocess.CompletedProcess[str], action: str) -> None:
    if result.returncode != 0:
        message = (result.stderr or result.stdout or "").strip()
        raise RuntimeError(f"{action} failed: {message}")


def existing_file(value: str | None) -> str:
    if not value:
        return ""
    path = Path(value).expanduser()
    return str(path) if path.is_file() else ""


def candidate_runtime_tool(name: str) -> str:
    exe_name = f"{name}.exe" if os.name == "nt" else name
    here = Path(__file__).resolve()
    candidates = [
        here.parents[3] / "docs" / "ffmpeg" / exe_name,
        here.parents[4] / "docs" / "ffmpeg" / exe_name,
    ]
    localappdata = os.environ.get("LOCALAPPDATA")
    if localappdata:
        candidates.append(Path(localappdata) / "com.xiaoyuan.jianji" / "runtime" / "ffmpeg" / "ffmpeg" / exe_name)
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return ""


def resolve_ffmpeg(explicit: str = "") -> str:
    return (
        existing_file(explicit)
        or existing_file(os.environ.get("XYCUT_FFMPEG_PATH"))
        or shutil.which("ffmpeg.exe")
        or shutil.which("ffmpeg")
        or candidate_runtime_tool("ffmpeg")
    )


def resolve_ffprobe(explicit: str = "", ffmpeg: str = "") -> str:
    if explicit:
        resolved = existing_file(explicit)
        if resolved:
            return resolved
    env_path = existing_file(os.environ.get("XYCUT_FFPROBE_PATH"))
    if env_path:
        return env_path
    if ffmpeg:
        ffmpeg_path = Path(ffmpeg)
        sibling = ffmpeg_path.with_name("ffprobe.exe" if ffmpeg_path.suffix.lower() == ".exe" else "ffprobe")
        if sibling.is_file():
            return str(sibling)
    return shutil.which("ffprobe.exe") or shutil.which("ffprobe") or candidate_runtime_tool("ffprobe")


def probe_duration_seconds(video_path: Path, ffprobe: str) -> float:
    result = run(
        [
            ffprobe,
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(video_path),
        ]
    )
    require_ok(result, "ffprobe")
    try:
        return max(0.1, float((result.stdout or "").strip()))
    except ValueError as exc:
        raise RuntimeError("ffprobe did not return a numeric duration") from exc


def extract_frame(ffmpeg: str, video_path: Path, output_path: Path, timestamp: float) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    vf = "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2"
    result = run(
        [
            ffmpeg,
            "-y",
            "-ss",
            f"{timestamp:.3f}",
            "-i",
            str(video_path),
            "-frames:v",
            "1",
            "-vf",
            vf,
            str(output_path),
        ]
    )
    require_ok(result, f"extract frame {output_path.name}")


def make_blurred_background(ffmpeg: str, frame_path: Path, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result = run(
        [
            ffmpeg,
            "-y",
            "-i",
            str(frame_path),
            "-vf",
            "boxblur=24:2",
            str(output_path),
        ]
    )
    require_ok(result, f"make blurred background {output_path.name}")


def extract_audio(ffmpeg: str, video_path: Path, output_path: Path) -> Path | None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result = run(
        [
            ffmpeg,
            "-y",
            "-i",
            str(video_path),
            "-vn",
            "-acodec",
            "libmp3lame",
            "-q:a",
            "2",
            str(output_path),
        ]
    )
    if result.returncode != 0 or not output_path.is_file() or output_path.stat().st_size <= 0:
        output_path.unlink(missing_ok=True)
        return None
    return output_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Prepare video frames and audio for xycut template designer.")
    parser.add_argument("--video", required=True, help="Source video path.")
    parser.add_argument("--task-dir", required=True, help="Task directory for extracted assets.")
    parser.add_argument("--frame-count", type=int, default=5, choices=[3, 4, 5], help="Number of reference frames.")
    parser.add_argument("--output", help="Manifest JSON path. Defaults to <task-dir>/video_reference_manifest.json.")
    parser.add_argument("--ffmpeg", default="", help="Explicit ffmpeg executable path.")
    parser.add_argument("--ffprobe", default="", help="Explicit ffprobe executable path.")
    parser.add_argument("--make-backgrounds", action="store_true", help="Also generate blurred background candidates for each frame.")
    args = parser.parse_args()

    video_path = Path(args.video).expanduser().resolve()
    if not video_path.is_file():
        raise FileNotFoundError(f"Video file does not exist: {video_path}")

    task_dir = Path(args.task_dir).expanduser().resolve()
    frames_dir = task_dir / "frames"
    backgrounds_dir = task_dir / "backgrounds"
    audio_dir = task_dir / "audio"
    task_dir.mkdir(parents=True, exist_ok=True)

    ffmpeg = resolve_ffmpeg(args.ffmpeg)
    ffprobe = resolve_ffprobe(args.ffprobe, ffmpeg)
    if not ffmpeg or not ffprobe:
        missing = []
        if not ffmpeg:
            missing.append("ffmpeg")
        if not ffprobe:
            missing.append("ffprobe")
        raise RuntimeError(
            "Missing video tools: "
            + ", ".join(missing)
            + ". Install the XYCut FFmpeg runtime or pass --ffmpeg/--ffprobe."
        )

    duration = probe_duration_seconds(video_path, ffprobe)
    frame_count = min(5, max(3, args.frame_count))
    frames = []
    for index, percent in enumerate(PERCENTS_BY_COUNT[frame_count], start=1):
        timestamp = max(0.0, min(duration - 0.05, duration * percent))
        frame_path = frames_dir / f"frame_{int(percent * 100):02d}.png"
        background_path = backgrounds_dir / f"frame_{int(percent * 100):02d}_background.png"
        extract_frame(ffmpeg, video_path, frame_path, timestamp)
        frame_item = {
            "index": index,
            "percent": percent,
            "timestamp_sec": round(timestamp, 3),
            "path": str(frame_path),
            "canvas": {"width": 1080, "height": 1920},
        }
        if args.make_backgrounds:
            make_blurred_background(ffmpeg, frame_path, background_path)
            frame_item["background_candidate_path"] = str(background_path)
        frames.append(frame_item)

    audio_path = extract_audio(ffmpeg, video_path, audio_dir / "source.mp3")
    manifest = {
        "ok": True,
        "source_video_path": str(video_path),
        "ffmpeg_path": ffmpeg,
        "ffprobe_path": ffprobe,
        "duration_sec": round(duration, 3),
        "frames": frames,
        "audio_path": str(audio_path) if audio_path else None,
        "recommended_layout_design_fields": {
            "canvas": {"width": 1080, "height": 1920},
            "source_video_path": str(video_path),
            "include_reference_video": True,
            "reference_video_visible": False,
            "source_audio_path": str(audio_path) if audio_path else None,
        },
    }

    output_path = Path(args.output).expanduser().resolve() if args.output else task_dir / "video_reference_manifest.json"
    output_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
