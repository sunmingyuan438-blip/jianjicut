from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from PIL import Image, ImageFilter

try:
    import cv2
    import numpy as np
except Exception:  # pragma: no cover - optional runtime dependency
    cv2 = None
    np = None


def as_int(value: Any, default: int = 0) -> int:
    try:
        return int(round(float(value)))
    except (TypeError, ValueError):
        return default


def clamp_box(raw: dict[str, Any], width: int, height: int, pad: int) -> tuple[int, int, int, int]:
    x = as_int(raw.get("x"), 0)
    y = as_int(raw.get("y"), 0)
    w = as_int(raw.get("w") or raw.get("width"), 0)
    h = as_int(raw.get("h") or raw.get("height"), 0)
    left = max(0, x - pad)
    top = max(0, y - pad)
    right = min(width, x + max(1, w) + pad)
    bottom = min(height, y + max(1, h) + pad)
    return left, top, right, bottom


def background_box_from_block(block: dict[str, Any]) -> dict[str, Any] | None:
    for owner in (block, block.get("style") if isinstance(block.get("style"), dict) else {}):
        if not isinstance(owner, dict):
            continue
        for key in ("background_box", "background"):
            value = owner.get(key)
            if isinstance(value, dict):
                box = value.get("box")
                if isinstance(box, dict):
                    return box
    return None


def collect_boxes(design: dict[str, Any], width: int, height: int, pad: int) -> list[tuple[int, int, int, int]]:
    boxes: list[tuple[int, int, int, int]] = []
    for block in design.get("text_blocks") or design.get("texts") or design.get("layers") or []:
        if not isinstance(block, dict):
            continue
        raw_box = block.get("box") if isinstance(block.get("box"), dict) else block.get("bbox")
        if isinstance(raw_box, dict):
            boxes.append(clamp_box(raw_box, width, height, pad))
        bg_box = background_box_from_block(block)
        if isinstance(bg_box, dict):
            boxes.append(clamp_box(bg_box, width, height, pad))
    for shape in design.get("shape_blocks") or design.get("shapes") or design.get("rect_blocks") or []:
        if not isinstance(shape, dict):
            continue
        raw_box = shape.get("box") if isinstance(shape.get("box"), dict) else shape.get("bbox")
        if isinstance(raw_box, dict):
            boxes.append(clamp_box(raw_box, width, height, pad))
    return boxes


def clean_with_inpaint(source_image: Path, output_path: Path, boxes: list[tuple[int, int, int, int]]) -> bool:
    if cv2 is None or np is None:
        return False
    image = cv2.imdecode(np.fromfile(str(source_image), dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        return False
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    for left, top, right, bottom in boxes:
        cv2.rectangle(mask, (left, top), (right, bottom), 255, thickness=-1)
    cleaned = cv2.inpaint(image, mask, 9, cv2.INPAINT_TELEA)
    success, encoded = cv2.imencode(output_path.suffix or ".png", cleaned)
    if not success:
        return False
    encoded.tofile(str(output_path))
    return True


def clean_with_blur(source_image: Path, output_path: Path, boxes: list[tuple[int, int, int, int]], blur_radius: float) -> None:
    image = Image.open(source_image).convert("RGB")
    blurred = image.filter(ImageFilter.GaussianBlur(radius=max(1.0, blur_radius)))
    result = image.copy()
    for box in boxes:
        result.paste(blurred.crop(box), box)
    result.save(output_path)


def clean_with_full_blur(source_image: Path, output_path: Path, blur_radius: float) -> None:
    image = Image.open(source_image).convert("RGB")
    result = image.filter(ImageFilter.GaussianBlur(radius=max(1.0, blur_radius)))
    result.save(output_path)


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a same-frame clean background from layout_design boxes.")
    parser.add_argument("layout_design", help="Path to layout_design.json.")
    parser.add_argument("--output", help="Output background path. Defaults to <layout_dir>/background_clean.png.")
    parser.add_argument("--blur-radius", type=float, default=36.0)
    parser.add_argument("--pad", type=int, default=36)
    parser.add_argument("--mode", choices=["full_blur", "mask_blur", "inpaint"], default="full_blur")
    parser.add_argument("--update-layout", action="store_true", help="Update layout_design.json background.file_path.")
    args = parser.parse_args()

    layout_path = Path(args.layout_design).expanduser().resolve()
    design = json.loads(layout_path.read_text(encoding="utf-8"))
    source_image = Path(str(design.get("source_image_path") or design.get("cover_path") or "")).expanduser()
    if not source_image.is_file():
        raise FileNotFoundError(f"source_image_path does not exist: {source_image}")

    output_path = Path(args.output).expanduser().resolve() if args.output else layout_path.parent / "background_clean.png"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    image = Image.open(source_image)
    width, height = image.size
    image.close()
    boxes = collect_boxes(design, width, height, max(0, args.pad))
    method = args.mode
    if args.mode == "full_blur":
        clean_with_full_blur(source_image, output_path, args.blur_radius)
    elif args.mode == "mask_blur":
        clean_with_blur(source_image, output_path, boxes, args.blur_radius)
        method = "blur"
    elif not clean_with_inpaint(source_image, output_path, boxes):
        clean_with_blur(source_image, output_path, boxes, args.blur_radius)
        method = "blur"

    if args.update_layout:
        design["background"] = {
            "type": "image",
            "file_path": str(output_path),
            "box": {"x": 0, "y": 0, "w": image.width, "h": image.height},
        }
        layout_path.write_text(json.dumps(design, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(json.dumps({"ok": True, "output": str(output_path), "masked_box_count": len(boxes), "method": method}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
