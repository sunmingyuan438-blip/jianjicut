from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def line_count(text: str) -> int:
    return max(1, len([line for line in str(text or "").splitlines() if line.strip()]))


def expected_min_ratio(role: str) -> float:
    role = role.lower()
    if role in {"headline", "title", "subheadline", "caption", "subtitle"}:
        return 0.62
    return 0.52


def audit_block(index: int, block: dict[str, Any]) -> dict[str, Any]:
    style = block.get("style") if isinstance(block.get("style"), dict) else {}
    box = block.get("box") if isinstance(block.get("box"), dict) else block.get("bbox")
    box = box if isinstance(box, dict) else {}
    text = str(block.get("text") or "")
    role = str(block.get("role") or "")
    font_size = as_float(style.get("font_size_px") or style.get("font_size") or style.get("size_px"))
    height = as_float(box.get("h") or box.get("height"))
    lines = line_count(text)
    line_height = height / lines if height > 0 else 0.0
    ratio = font_size / line_height if line_height > 0 else 0.0
    min_ratio = expected_min_ratio(role)
    warning = ""
    suggested_font_size_px = None
    if font_size <= 0:
        warning = "missing_font_size_px"
    elif ratio and ratio < min_ratio:
        warning = "font_size_may_be_too_small"
        suggested_font_size_px = round(line_height * min_ratio)
    return {
        "index": index,
        "role": role,
        "slot_name": block.get("slot_name") or block.get("name") or "",
        "text": text,
        "box_height": height,
        "line_count": lines,
        "line_height": round(line_height, 2),
        "font_size_px": font_size,
        "font_to_line_height_ratio": round(ratio, 3),
        "min_expected_ratio": min_ratio,
        "warning": warning,
        "suggested_font_size_px": suggested_font_size_px,
    }


def audit_background(design: dict[str, Any]) -> list[dict[str, Any]]:
    warnings: list[dict[str, Any]] = []
    source_image = Path(str(design.get("source_image_path") or ""))
    background = design.get("background") if isinstance(design.get("background"), dict) else {}
    background_path = Path(str(background.get("file_path") or background.get("path") or ""))
    source_stem = source_image.stem.lower()
    background_stem = background_path.stem.lower()
    if source_stem.startswith("frame_") and background_stem:
        source_key = source_stem.removesuffix("_background")
        background_key = background_stem.removesuffix("_background").removesuffix("_clean")
        if source_key and source_key not in background_key:
            warnings.append(
                {
                    "warning": "background_may_not_match_source_frame",
                    "source_image_path": str(source_image),
                    "background_file_path": str(background_path),
                    "message": "Video template background should come from the same selected reference frame.",
                }
            )
    return warnings


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit layout_design.json before XYCut template draft assembly.")
    parser.add_argument("layout_design", help="Path to layout_design.json.")
    parser.add_argument("--output", help="Optional audit report JSON path.")
    args = parser.parse_args()

    path = Path(args.layout_design).expanduser().resolve()
    design = json.loads(path.read_text(encoding="utf-8"))
    blocks = design.get("text_blocks") or design.get("texts") or design.get("layers") or []
    reports = [audit_block(index, block) for index, block in enumerate(blocks, start=1) if isinstance(block, dict)]
    warnings = [item for item in reports if item.get("warning")]
    warnings.extend(audit_background(design))
    result = {
        "ok": not warnings,
        "layout_design": str(path),
        "text_block_count": len(reports),
        "warnings": warnings,
        "blocks": reports,
    }
    if args.output:
        Path(args.output).expanduser().resolve().write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    print(json.dumps(result, ensure_ascii=False))
    return 0 if not warnings else 2


if __name__ == "__main__":
    raise SystemExit(main())
