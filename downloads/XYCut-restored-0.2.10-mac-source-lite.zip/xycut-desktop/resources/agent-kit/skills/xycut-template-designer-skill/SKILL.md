---
name: xycut-template-designer-skill
description: 使用小圆 XYCut 从截图或视频中提取可复用模板资产并生成可编辑剪映模板草稿；适用于“从图片生成模板”“参考这个截图做剪映草稿”“分析文字排版/颜色/描边/阴影/字号”“分析视频节奏模板”“template_designer”“layout_design”“rhythm_design”等请求。最终草稿组装必须交给小圆 XYCut 客户端本地 API。
metadata:
  version: 0.3.0
---

# 小圆模板设计 Skill

## 目标

把用户提供的截图、设计图或视频参考，分析成标准 9:16 模板资产，并调用小圆 XYCut 客户端生成一个可在剪映中二次编辑的模板草稿。

本 Skill 生成的是“模板提取结果”：优先还原文字内容、位置、颜色、描边、阴影和字号；如果输入是视频，还应提取粗粒度视频节奏、镜头段落、文字出现时间和音频节奏。后续用户可在剪映里手动微调，也可以把这些模板资产交给爆款复刻流程继续创作。

## 两种模式

### static_design

用于截图、设计图或单帧参考图。本质是提取静态版式：

- 标准化为 1080x1920。
- 输出 `layout_design.json`。
- 背景、文字、文字背景、行间距、描边、阴影、字体大小都以 Agent 分析结果为准。
- AI 生成的背景图、人物图、装饰图等独立图片资源写入 `image_blocks` 或 `asset_blocks`，不要混到文字背景里。
- 核心组装只做剪映参数换算，不按固定规则猜测黄底、红底、字号或文字宽度。

### dynamic_design

用于视频参考。本质是复制模板的动态结构，第一版先记录和组装基础时间线：

- 抽 3 到 5 张标准帧并提取音频。
- 选择主参考帧生成 `layout_design.json`。
- 生成 `rhythm_design.json`，把视频拆成两条时间线：
  - `media_segments`：画面切换时间线，记录原视频或图片素材在目标时间轴里的 `target_start_ms/target_end_ms`，以及源视频里的 `source_start_ms/source_end_ms`。
  - `overlay_events`：覆盖层时间线，记录文字、独立图片资源、贴纸候选、效果候选等在画面中的出现/消失时间。
- 需要复刻原视频画面时，可以把 `media_segments` 同步写入 `layout_design.json`，核心会用原视频按时间戳切段组装。
- 文字如果有时间范围，可以在 `text_blocks` 里写 `start_ms/end_ms`；AI 生成图片或装饰素材如果有时间范围，可以在 `image_blocks` / `asset_blocks` 里写 `start_ms/end_ms`。

第一版不要强行识别具体剪映字体名、贴纸名、特效名。只记录视觉描述和候选类型，后续再通过用户提供的剪映字体/贴纸/效果参考图做多模态匹配和资源绑定。

## 职责边界

- Agent 负责看图/抽帧、理解版式、生成 `layout_design.json` 和调用客户端 API。
- 客户端和 Python core 负责读取 `layout_design.json`、组装合法剪映草稿和写入草稿目录。
- `layout_design.json` 是权威来源：背景、文字背景、行间距、文本框宽度、描边、阴影、独立图片素材等能分析出来的参数都必须显式写入 JSON；不要依赖核心代码按命名猜测样式。
- 视频输入时，`rhythm_design.json` 记录节奏模板：镜头分段、段落时长、文字出现节奏、音频卡点和素材风格。它是爆款复刻的中间资产，不一定直接参与当前模板草稿组装。
- 视频模式下，画面切换和覆盖层出现时间必须分开记录：画面片段写 `media_segments`，文字写带时间字段的 `text_blocks`，AI 生成图片/装饰素材写 `image_blocks` 或 `asset_blocks`，贴纸/效果候选写 `overlay_events`。
- Agent 不直接写剪映草稿目录，不手写或修补完整 `draft_content.json`。
- 第一版默认生成可编辑草稿，不自动注册为爆款模板或视频模板；用户明确要求注册模板时，再按现有客户端能力继续处理。
- 客户端不需要额外 UI 入口；优先使用 `agent_context_file.local_api.template_designer_generate_url` 或 `/ai-editing/generate`。

## 输入

用户可能直接上传图片，或给视频文件路径。也可能给出从小圆 XYCut 复制的 Agent 上下文文件路径：

```text
Agent 上下文文件：
xxx\com.xiaoyuan.jianji\agent-context.json
```

如果没有上下文文件，先让用户打开小圆 XYCut 并复制包含 `Agent 上下文文件` 的提示词；没有客户端本地 API 和草稿目录时不能生成剪映草稿。

## 处理图片

图片必须先标准化到 9:16 参考坐标系。统一使用：

```text
canvas.width = 1080
canvas.height = 1920
origin = 左上角
x/y/w/h = 1080x1920 标准图中的像素
```

如果原图不是 9:16，按“保持主体完整”的方式裁切或补边。版式分析、OCR 和颜色估计都基于标准图，不直接使用原图坐标。

## 处理视频

不要只抽一帧。按视频时长平均抽 3 到 5 张参考帧，优先取 10%、30%、50%、70%、90% 附近；短视频至少抽 3 张。综合比较后选择文字最完整、遮挡最少、版式最标准的一张作为主参考图。

优先使用本 skill 的脚本准备参考帧和音频：

```bash
python <skill_dir>/scripts/prepare_video_reference.py --video "<video_path>" --task-dir "<task_dir>" --frame-count 5
```

如果 `agent_context_file.tools.ffmpeg_path` / `tools.ffprobe_path` 存在，调用脚本时显式传入：

```bash
python <skill_dir>/scripts/prepare_video_reference.py --video "<video_path>" --task-dir "<task_dir>" --frame-count 5 --ffmpeg "<ffmpeg_path>" --ffprobe "<ffprobe_path>"
```

脚本会输出：

- `<task_dir>/frames/frame_10.png` 等 1080x1920 标准参考帧。
- `<task_dir>/audio/source.mp3`，如果源视频有可提取音频。
- `<task_dir>/video_reference_manifest.json`，记录每帧路径、时间点和音频路径。

视频有音频时，必须把提取出的音频路径写入 `layout_design.json` 的 `source_audio_path` 或 `audio_path`，让生成的剪映草稿带参考音轨。

视频输入时，必须把原视频路径写入 `layout_design.json` 的 `source_video_path`。模板设计阶段需要人工对比确认，核心会默认把原视频作为一条“原视频参考（默认隐藏）”轨道写入同一个剪映草稿；它默认静音并隐藏，避免遮挡模板效果，用户可在剪映里手动打开对比。

选定主参考帧后，`source_image_path` / `cover_path` 必须指向该完整帧。不要混用其他帧的背景图；否则文字版式再准确，整体画面也会不像。

生成 `layout_design.json` 后，可以用所选主帧生成同帧模糊背景：

```bash
python <skill_dir>/scripts/make_clean_background.py "<task_dir>/layout_design.json" --output "<task_dir>/background_clean.png" --update-layout
```

默认只做整图模糊，不需要去字或复杂修补。核心要求是背景和 `source_image_path` 同帧，避免错帧导致整体不像。

如果制作 contact sheet，只能用它选择哪一帧最标准；不要直接根据 contact sheet 缩略图估算坐标、字号或文字背景尺寸。选定主参考帧后，必须打开对应的完整 1080x1920 单帧图片来分析 `box`、`font_size_px`、描边、阴影和文字背景。

## 版式分析

识别每段独立文字块，而不是只输出整页 OCR。每个文字块尽量判断：

- `text`：原文，保留换行。
- `box`：标准画布坐标中的 `x/y/w/h`。
- `role`：如 `headline`、`subtitle`、`body`、`caption`、`badge_text`。
- `style.color`：主体文字颜色，使用 HEX。
- `style.font_size_px`：基于标准图估算的像素字号。
- `style.stroke_color` / `style.stroke_width_px`：描边颜色和像素宽度。
- `style.shadow`：阴影颜色、偏移、模糊；没有就省略。
- `style.align`：`left`、`center` 或 `right`。
- `style.line_spacing`：多行文字的剪映行距估计；如果原图行距明显，必须显式写。
- `style.max_line_width` / `style.auto_wrapping`：只有希望剪映自动重排时才写；一般保留原图换行并让核心按显式换行组装。

对于黄底黑字、红底白字、半透明底条、图片/视频背景等，优先把黄底、红底、半透明底条写入对应文字块的 `style.background_box` / 顶层 `background_box`。不要只在 `slot_name` 写“黄底/红底/标题条”。

不要主动生成独立色块层来模拟文字底色；文字底色本质上是文字样式属性。`shape_blocks` 只作为旧 JSON 的兼容字段保留，新模板优先使用 `background_box`。

如果用户让 AI 生成背景图、人物图、产品图、装饰图等独立图片资源，写入 `image_blocks` / `asset_blocks`，并明确每张图的 `file_path`、`box`、`start_ms/end_ms`、`opacity`。

生成 `layout_design.json` 后，先运行字号审计：

```bash
python <skill_dir>/scripts/audit_layout_design.py "<task_dir>/layout_design.json" --output "<task_dir>/layout_design_audit.json"
```

如果审计返回 `font_size_may_be_too_small`，不要直接调用 API；必须回看主参考图和 contact sheet，修正对应文字块的 `style.font_size_px` 后再生成草稿。视频帧更容易低估字号，尤其是底部多行正文。

详细 JSON 协议读 [references/layout-design-schema.md](references/layout-design-schema.md)。
视频节奏协议读 [references/rhythm-design-schema.md](references/rhythm-design-schema.md)。
模板提取产物说明读 [references/template-assets.md](references/template-assets.md)。
后续字体、贴纸、效果名称识别的升级待办读 [references/style-asset-matching-todo.md](references/style-asset-matching-todo.md)。

## 主流程

1. 读取 `agent_context_file`，确认 `paths.draft_output_dir` 存在，并找到 `local_api.template_designer_generate_url`。如果缺失，可使用 `local_api.generate_url` 并传 `mode: "template_designer"`。
2. 准备输入图片：图片直接标准化；视频先运行 `scripts/prepare_video_reference.py` 抽 3 到 5 帧并提取音频。
3. 使用多模态能力分析全部参考帧，选择最标准的一帧作为主参考图，生成 `<task_dir>\layout_design.json`。
4. 如果输入是视频，生成 `<task_dir>\rhythm_design.json`：第一版可以粗粒度拆分，必须记录不确定性；同时把原视频路径写入 `source_video_path`，把可直接复刻的 `media_segments`、有时间范围的 `text_blocks` 和 `image_blocks` / `asset_blocks` 写进 `layout_design.json`。
5. 可选生成 `<task_dir>\template_design.json`，引用 `layout_design.json`、`rhythm_design.json`、主参考帧和音频。
6. 按 `layout-design-schema.md` 自检：至少要有 `canvas` 和 1 个 `text_blocks`，坐标必须在 1080x1920 范围内。
7. 运行 `scripts/audit_layout_design.py`；如有字号过小警告，或发现 box 明显小于完整单帧里的视觉文字区域，修正 JSON 后再继续。确认 `background.file_path` 来自所选主帧或已通过视觉检查的清理背景。
8. 调用客户端本地 API 生成模板草稿。
9. 回复普通用户草稿名称，让用户打开剪映草稿箱继续编辑。

## API 调用

优先调用：

```http
POST {template_designer_generate_url}
Content-Type: application/json

{
  "mode": "template_designer",
  "request_id": "template-designer-...",
  "layout_design_file": "<task_dir>\\layout_design.json"
}
```

也可以调用统一入口：

```http
POST {generate_url}

{
  "mode": "template_designer",
  "layout_design_file": "<task_dir>\\layout_design.json"
}
```

成功后返回中的 `draft.draft_name` 是用户应该在剪映草稿箱搜索的名称。

## 完成回复

生成成功后只面向普通用户回复：

```md
# 剪映草稿已生成：<草稿名称>

请打开剪映草稿箱，搜索上面的草稿名称并打开继续编辑。
```

如果只是完成 `layout_design.json` 但客户端 API 不可用，说明缺少什么，不要把中间 JSON 当作最终结果。
