# 模板提取产物

模板设计 skill 的职责是从截图或视频中提取可复用模板资产，而不只是生成一次性的草稿。

## 输出文件

推荐任务目录结构：

```text
task_dir/
  frames/
  audio/
  layout_design.json
  rhythm_design.json
  template_design.json
  layout_design_audit.json
```

## layout_design.json

描述可组装视觉版式：

- 文字内容、位置、字号、颜色、描边、阴影。
- 文字背景、背景、AI 生成图片或视频背景。
- 静态模式下，通常包含 `background`、`text_blocks`，以及可选的 `image_blocks` / `asset_blocks`。
- 动态模式下，可以额外包含 `media_segments`、带时间字段的 `text_blocks`、`image_blocks` / `asset_blocks`，用于直接生成带时间线的模板草稿。
- 可直接交给 `template_designer` API 生成可编辑模板草稿。

## rhythm_design.json

描述视频节奏模板：

- 镜头分段和每段时长。
- 画面切换时间线 `media_segments`。
- 覆盖层时间线 `overlay_events`，包括文字、独立图片素材、贴纸候选和效果候选。
- 音频卡点、停顿、重音。
- 每段画面风格和素材检索关键词。

`rhythm_design.json` 是分析记录和后续爆款复刻资产；其中能直接组装的 `media_segments`、文字时间字段、独立图片素材字段，可以同步写入 `layout_design.json`。

## template_design.json

可选索引文件，用来把一次模板提取的结果串起来：

```json
{
  "version": "0.1",
  "source_type": "video",
  "source_path": "D:\\task\\reference.mp4",
  "layout_design_file": "D:\\task\\layout_design.json",
  "rhythm_design_file": "D:\\task\\rhythm_design.json",
  "main_reference_frame": "D:\\task\\frames\\frame_50.png",
  "audio_path": "D:\\task\\audio\\source.mp3",
  "mode": "dynamic_design",
  "notes": [
    "字体、贴纸、效果名称匹配尚未启用，当前只记录视觉候选"
  ]
}
```

`xycut-hot-remake-skill` 可以读取这些文件来做后续爆款复刻。
