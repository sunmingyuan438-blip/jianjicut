# rhythm_design.json 协议

`rhythm_design.json` 描述参考视频的节奏模板。它和 `layout_design.json` 同属于模板提取结果：

- `layout_design.json`：文字版式、文字背景、独立图片素材、背景、视觉样式。
- `rhythm_design.json`：镜头切分、段落时长、字幕/文字出现节奏、音频节奏、素材风格。

如果输入只是截图，可以不生成 `rhythm_design.json`。如果输入是视频，建议生成。

## 顶层字段

```json
{
  "version": "0.1",
  "source_video_path": "D:\\task\\reference.mp4",
  "duration_ms": 9103,
  "canvas": { "width": 1080, "height": 1920 },
  "audio_path": "D:\\task\\audio\\source.mp3",
  "media_segments": [],
  "overlay_events": [],
  "segments": [],
  "text_events": [],
  "audio_events": [],
  "media_style": {},
  "notes": []
}
```

字段说明：

- `duration_ms`：参考视频总时长。
- `media_segments`：画面切换时间线，按时间顺序排列。用于记录原视频/图片素材如何切段复刻。
- `overlay_events`：覆盖层时间线。用于记录文字、独立图片素材、贴纸候选、效果候选等对象的出现/消失时间。
- `segments`：高层语义段落摘要，可选。用于描述一段画面的内容和素材替换建议。
- `text_events`：旧字段兼容；新数据优先写 `overlay_events`，或者直接把 `start_ms/end_ms` 写到 `layout_design.text_blocks[]`。
- `audio_events`：明显卡点、重音、停顿、音乐段落。
- `media_style`：画面风格摘要，用于后续素材匹配。

## 两条时间线

视频模板设计必须把“画面怎么切”和“画面上覆盖了什么”分开记录：

- 画面切换写 `media_segments`。它只关心底层视频/图片素材从哪里开始、到哪里结束、放到目标时间轴哪里。
- 覆盖层写 `overlay_events`。它关心文字、独立图片素材、贴纸候选、效果候选的出现时间、位置和视觉描述。

如果只是 1:1 复刻参考视频，`media_segments` 可以复用同一个 `source_video_path`，通过不同的 `source_start_ms/source_end_ms` 切段。核心组装时会用同一个源视频素材生成多段。

## media_segments

```json
{
  "index": 1,
  "type": "video",
  "source_video_path": "D:\\task\\reference.mp4",
  "target_start_ms": 0,
  "target_end_ms": 1800,
  "source_start_ms": 0,
  "source_end_ms": 1800,
  "shot_type": "opening_title",
  "motion": "static_or_slow_zoom",
  "transition_in": "cut",
  "transition_out": "cut",
  "source_frame_path": "D:\\task\\frames\\frame_10.png",
  "visual_summary": "模糊商超背景，顶部标题区域出现三段文字",
  "suggested_material_query": "超市 人群 模糊 背景"
}
```

字段说明：

- `target_start_ms` / `target_end_ms`：该画面片段放到新草稿时间轴的位置。
- `source_start_ms` / `source_end_ms`：从参考视频中截取的源时间范围。
- `source_video_path` 可省略；省略时使用顶层 `source_video_path`。
- `transition_*` 第一版只记录观察值，核心暂不保证自动还原所有转场。

## overlay_events

```json
{
  "index": 1,
  "type": "text",
  "start_ms": 0,
  "end_ms": 5000,
  "text_block_index": 1,
  "text": "这是第一行标题",
  "box": { "x": 80, "y": 120, "w": 920, "h": 110 },
  "style": {
    "font_size_px": 64,
    "color": "#FFFFFF",
    "stroke_color": "#000000",
    "stroke_width_px": 5
  },
  "animation": "none",
  "visual_description": "白字黑描边，顶部居中"
}
```

支持的 `type`：

- `text` / `caption` / `subtitle` / `title`：文字覆盖层。可同步写入 `layout_design.text_blocks[]`。
- `image` / `asset` / `generated_image`：独立图片素材。可同步写入 `layout_design.image_blocks[]` 或 `layout_design.asset_blocks[]`。
- `shape` / `rect` / `bar`：旧版本兼容类型，不推荐新模板主动使用；文字底色应写入文字块的 `background_box`。
- `sticker_candidate`：贴纸候选。第一版只记录视觉描述、位置和时间，不写剪映资源名。
- `effect_candidate`：效果候选。第一版只记录效果描述、作用范围和时间，不写剪映资源名。

## segments

```json
{
  "index": 1,
  "start_ms": 0,
  "end_ms": 1800,
  "duration_ms": 1800,
  "source_frame_path": "D:\\task\\frames\\frame_10.png",
  "shot_type": "background_with_title",
  "visual_summary": "模糊超市场景，顶部三组标题文字",
  "motion": "static_or_slow_zoom",
  "transition_in": "cut",
  "transition_out": "cut",
  "suggested_material_query": "超市 人群 模糊 背景",
  "layout_refs": [1, 2, 3]
}
```

字段说明：

- `shot_type`：如 `title_card`、`broll_scene`、`talking_head`、`product_closeup`、`subtitle_focus`。
- `motion`：如 `static`、`slow_zoom`、`pan_left`、`fast_cut`。
- `layout_refs`：对应 `layout_design.text_blocks[].index`，表示该段使用哪些文字版式。
- `suggested_material_query`：给素材库检索用的人话关键词。

## text_events

```json
{
  "text_block_index": 1,
  "start_ms": 0,
  "end_ms": 5000,
  "animation": "none",
  "emphasis": "headline"
}
```

如果参考视频中所有文字一直显示，可把每个文字块的 `start_ms` 设为 0，`end_ms` 设为视频总时长。

新版本优先使用 `overlay_events` 或 `layout_design.text_blocks[].start_ms/end_ms`。`text_events` 只作为简化兼容字段保留。

## audio_events

```json
{
  "time_ms": 1200,
  "type": "beat",
  "strength": 0.8,
  "note": "明显鼓点"
}
```

第一版可以只粗略记录明显卡点和停顿。不要为了生成草稿而虚构精确节拍。

## 分析方法建议

视频节奏不要只靠多模态单帧判断。推荐组合：

1. 用 FFmpeg 抽帧。
2. 用画面相似度/直方图差异找镜头变化点。
3. 用音频能量找卡点、停顿和重音。
4. 用多模态总结每个片段画面内容、风格和可替换素材类型。

第一版如果还没有自动算法，可以让 Agent 根据 3 到 5 张参考帧和视频时长给出粗粒度 `segments`，但必须在 `notes` 中说明这是粗略节奏。
