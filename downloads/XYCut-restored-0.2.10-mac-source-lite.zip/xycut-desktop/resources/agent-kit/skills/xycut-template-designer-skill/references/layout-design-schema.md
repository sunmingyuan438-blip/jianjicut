# layout_design.json 协议

`layout_design.json` 是 Agent 和小圆 XYCut 客户端之间的中间协议。Agent 负责生成它，客户端核心代码负责把它组装成剪映草稿。

## 坐标标准

所有坐标都基于标准画布：

```json
{
  "canvas": {
    "width": 1080,
    "height": 1920
  }
}
```

- 原点在左上角。
- `x/y/w/h` 单位都是标准图像素。
- 图片或视频帧必须先标准化到 1080x1920，再分析位置、字号和描边。
- 视频 contact sheet 只用于选择主参考帧；不得直接从缩略图估算 `box` 或 `font_size_px`。坐标和字号必须来自完整 1080x1920 单帧。

## 顶层字段

```json
{
  "draft_name": "截图模板草稿_001",
  "duration_ms": 5000,
  "canvas": { "width": 1080, "height": 1920 },
  "source_image_path": "D:\\task\\frame_main.png",
  "cover_path": "D:\\task\\frame_main.png",
  "audio_path": "D:\\task\\source.mp3",
  "source_video_path": "D:\\task\\reference.mp4",
  "include_reference_video": true,
  "reference_video_visible": false,
  "media_segments": [],
  "image_blocks": [],
  "overlay_events": [],
  "background": {
    "type": "image",
    "file_path": "D:\\task\\background.png",
    "box": { "x": 0, "y": 0, "w": 1080, "h": 1920 }
  },
  "text_blocks": []
}
```

字段说明：

- `draft_name`：生成到剪映草稿箱的草稿名。
- `duration_ms`：静态模板草稿时长，默认 5000。
- `source_image_path`：用于追溯和封面，可选。
- `cover_path`：草稿封面，可选。
- `audio_path`：视频输入提取出来的参考音频，可选。
- `source_video_path`：视频输入的原始参考视频，可选。动态设计中 `media_segments` 省略素材路径时会使用它。
- `include_reference_video`：视频输入时默认 `true`。核心会把原视频加入一条“原视频参考（默认隐藏）”轨道，方便人工对比确认。
- `reference_video_visible`：原视频参考轨道是否默认可见，默认 `false`，避免遮挡模板草稿。
- `media_segments`：动态设计中的底层画面片段，可选。用于按时间戳复用原视频或图片素材。
- `image_blocks` / `asset_blocks`：独立图片素材，可选。用于记录 AI 生成的背景元素、人物图、产品图、装饰图等。
- `overlay_events`：动态设计中的覆盖层事件，可选。用于记录文字、图片资源、贴纸候选、效果候选的出现时间。
- `background`：整屏背景图/视频，可选。
- `backgrounds`：多个背景或装饰媒体，可选。
- `background.use_builtin` / `background.use_default`：可选。设为 `true` 时使用客户端内置默认背景图。
- `shape_blocks`：旧版本兼容字段，不推荐新模板主动使用。文字底色应写在文字块的 `background_box`。
- `text_blocks`：必须至少有 1 个文字块。

## 文字块

```json
{
  "role": "headline",
  "slot_name": "顶部主标题",
  "text": "这是第一行标题\n第二行自动替换",
  "start_ms": 0,
  "end_ms": 5000,
  "box": { "x": 80, "y": 130, "w": 920, "h": 180 },
  "style": {
    "font_size_px": 58,
    "color": "#FFFFFF",
    "align": "center",
    "stroke_color": "#000000",
    "stroke_width_px": 5,
    "background_box": {
      "color": "#FFE500",
      "padding": 16
    },
    "shadow": {
      "enabled": true,
      "color": "#000000",
      "offset_x_px": 2,
      "offset_y_px": 4,
      "blur_px": 6,
      "alpha": 0.65
    }
  }
}
```

字段说明：

- `role`：用于表达文字用途，建议值包括 `headline`、`subheadline`、`body`、`caption`、`badge_text`、`subtitle`。
- `text`：识别出的原文，保留视觉换行。
- `start_ms` / `end_ms` / `duration_ms`：可选。视频动态设计中控制文字出现时间；不写时默认全程显示。
- `box`：文字块外接矩形。尽量包住文字视觉范围，不要扩大到整行空白。
- `style.font_size_px`：标准图里的视觉字号估算，不是剪映最终字号。
- `style.color`：主文字颜色。
- `style.stroke_color` 和 `style.stroke_width_px`：识别不到描边时可省略。
- `style.shadow`：识别不到阴影时可省略。
- `style.align`：默认 `center`。
- `background_box`：可选。用于给当前文字块生成底色矩形，默认使用文字块 `box`，可设置 `color`、`opacity`、`padding` 或独立 `box`。
- `style.background_box`：同 `background_box`，推荐写在 `style` 内，便于把文本视觉样式聚合在一起。
- `style.line_spacing`：剪映行距值，范围建议 0 到 0.5。显式写入时核心会按该值组装，不再自行放大或缩小。

## 文字背景

黄底标题条、红底标题条、半透明底条这类视觉效果，本质上是文字块的背景属性。新模板不要主动生成独立色块层，应写在对应文字块的 `background_box` 或 `style.background_box`。

```json
{
  "role": "subtitle",
  "text": "这是黄底黑字标题",
  "box": { "x": 100, "y": 300, "w": 880, "h": 130 },
  "style": {
    "font_size_px": 48,
    "color": "#000000",
    "background_box": {
      "color": "#FFE500",
      "opacity": 1.0,
      "padding_x": 24,
      "padding_y": 12,
      "round_radius": 0
    }
  }
}
```

核心会优先使用剪映文本素材自己的 `background_*` 字段生成文字背景。这样文字和底色在剪映里更容易作为同一文字层继续编辑。

`shape_blocks` 仅作为历史兼容字段保留。除非旧数据已经存在，Agent 不应为了文字底色新建 `shape_blocks`。

对于需要独立摆放的 AI 生成图片、产品图、人物图、装饰图，不要用 `shape_blocks`，应使用 `image_blocks` / `asset_blocks`。

对于黄底标题条、红底标题条、半透明说明条等，必须显式写 `background_box` 或 `style.background_box`。不要依赖 `slot_name`、`role` 或文字颜色让核心自动猜背景。

## 独立图片素材

`image_blocks` / `asset_blocks` 用于 AI 生成图、局部装饰、人物图、产品图等独立素材。核心会把它们放到背景之上、文字之下的图片素材轨道。

```json
{
  "image_blocks": [
    {
      "role": "ai_generated_product",
      "file_path": "D:\\task\\assets\\product.png",
      "start_ms": 0,
      "end_ms": 5000,
      "box": { "x": 180, "y": 620, "w": 720, "h": 520 },
      "opacity": 1.0
    },
    {
      "role": "ai_generated_decoration",
      "file_path": "D:\\task\\assets\\spark.png",
      "start_ms": 1200,
      "end_ms": 3600,
      "box": { "x": 760, "y": 260, "w": 180, "h": 180 },
      "opacity": 0.92
    }
  ]
}
```

字段说明：

- `file_path`：本地图片路径，支持常见图片格式。
- `box`：图片在 1080x1920 标准画布中的目标位置和尺寸。
- `start_ms` / `end_ms` / `duration_ms`：出现时间；不写时默认全程显示。
- `opacity`：透明度，默认 `1.0`。
- `render_index` / `z_index`：可选。默认图片素材在文字下方；需要特殊层级时再显式写。

## 换行宽度

默认情况下核心会把文字素材导出为 `type: "text"`，并设置 `line_max_width: 1.0`，让剪映尊重 `text` 中已经存在的显式换行，避免再次自动换行。

只有确实希望剪映自动按宽度重排时，才在文字块 `style` 中写：

```json
{
  "auto_wrapping": true,
  "max_line_width": 0.82
}
```

`max_line_width` 是行宽占画布宽度的比例，范围为 0 到 1。

## 参数换算原则

Agent 不需要输出剪映内部参数，只输出标准图像素参数。客户端核心会做基础换算：

- `font_size_px` 会换算为剪映文字 style `size`。
- `stroke_width_px` 会换算为剪映描边宽度。
- `box` 中心点会换算为剪映 `clip.transform.x/y`。
- `box.w` 会换算为 `line_max_width`。

除必要的剪映单位换算和范围裁剪外，核心不应覆盖 Agent 明确写入的样式参数。后续如果换算表升级，旧的 `layout_design.json` 仍然可复用。

## 视频输入建议

如果源是视频，任务目录建议保留：

```text
frames/frame_10.png
frames/frame_30.png
frames/frame_50.png
frames/frame_70.png
frames/frame_90.png
audio/source.mp3
rhythm_design.json
layout_design.json
```

`source_image_path` 和 `cover_path` 指向最终选中的主参考帧。`background.file_path` 建议指向该主帧生成的整图模糊背景。`audio_path` 指向提取音频。`source_video_path` 指向原始参考视频，核心会默认把它写入一条隐藏参考轨道，供剪映里人工打开对比。

可用脚本准备这些文件：

```bash
python <skill_dir>/scripts/prepare_video_reference.py --video "<video_path>" --task-dir "<task_dir>" --frame-count 5
```

脚本生成的 `video_reference_manifest.json` 中，`audio_path` 不为空时，应复制到 `layout_design.json` 的 `source_audio_path` 或 `audio_path`；`source_video_path` 必须复制到 `layout_design.json`，用于生成原视频参考轨道。

选定主帧并生成 `layout_design.json` 后，可生成同帧模糊背景：

```bash
python <skill_dir>/scripts/make_clean_background.py "<task_dir>/layout_design.json" --output "<task_dir>/background_clean.png" --update-layout
```

如果额外生成 contact sheet，`source_image_path` 仍应指向最终选中的完整帧，例如 `frames/frame_10.png`，不要指向 contact sheet。

## 动态视频字段

当需要把原视频的画面节奏也做成草稿时，`layout_design.json` 可以直接包含 `media_segments`。核心会把这些片段放在底层视频轨道，独立图片素材和文字仍在上层。

```json
{
  "source_video_path": "D:\\task\\reference.mp4",
  "media_segments": [
    {
      "type": "video",
      "target_start_ms": 0,
      "target_end_ms": 1800,
      "source_start_ms": 0,
      "source_end_ms": 1800
    },
    {
      "type": "video",
      "target_start_ms": 1800,
      "target_end_ms": 4200,
      "source_start_ms": 1800,
      "source_end_ms": 4200
    }
  ]
}
```

`overlay_events` 可用于记录还没有完全落到剪映资源里的覆盖层：

```json
{
  "overlay_events": [
    {
      "type": "sticker_candidate",
      "start_ms": 1200,
      "end_ms": 2600,
      "box": { "x": 820, "y": 300, "w": 160, "h": 160 },
      "visual_description": "右上角白色手绘感感叹号贴纸",
      "asset_match": null
    }
  ]
}
```

第一版只自动组装 `overlay_events` 中可表达为文字或独立图片的对象。`sticker_candidate`、`effect_candidate` 先保留为分析记录，后续通过剪映资源参考图匹配后再组装。

## 最小示例

```json
{
  "draft_name": "截图模板草稿_001",
  "duration_ms": 5000,
  "canvas": { "width": 1080, "height": 1920 },
  "text_blocks": [
    {
      "role": "headline",
      "text": "这是第一行标题",
      "box": { "x": 120, "y": 160, "w": 840, "h": 96 },
      "style": {
        "font_size_px": 60,
        "color": "#FFFFFF",
        "stroke_color": "#000000",
        "stroke_width_px": 4,
        "align": "center"
      }
    }
  ]
}
```
