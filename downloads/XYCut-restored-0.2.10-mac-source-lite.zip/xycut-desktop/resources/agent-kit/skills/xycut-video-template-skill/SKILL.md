---
name: xycut-video-template-skill
description: 使用小圆 XYCut 的视频模板生成剪映草稿；支持 MP4+SRT、MP3+SRT、文案转豆包 TTS 配音、音视频 ASR 转字幕、本地素材库候选匹配、Pexels 网络补充和 AI 生成素材补充。遇到“小圆视频模板”“video_template”“template_config_file”“srt_file”“mp4_file”“mp3_file”“sucai_library”等请求时使用本 Skill。
metadata:
  version: 0.2.41
---

# 小圆视频模板 Skill

## 硬性停止条件

以下规则优先于后续所有流程说明：

- “生成草稿”“做一条视频”“帮我生成剪映草稿”只表示开始流程，不等于授权全自动生成成品。
- 对于 `MP4 + SRT`，如果用户没有明确提供素材覆盖范围、素材补充方式和素材匹配模式，必须停下来询问，不能导出素材、不能生成 `video_template_analysis.json`、不能调用客户端生成接口。
- 对于 `MP3 + SRT` 或文案 TTS 生成的音频，默认全部字幕都需要匹配画面，不要再询问覆盖率；如果用户没有明确提供素材补充方式和素材匹配模式，只询问素材来源和“快速/精细”，不能导出素材、不能生成 `video_template_analysis.json`、不能调用客户端生成接口。
- 只给文案时先做 TTS 配音，再对生成音频做 ASR/对齐生成 SRT 和 `speech\segments.json`；原始文案是字幕分句权威，ASR 只提供字词时间，不能直接采用 ASR 自己串出来的分句；AI 配音默认不删除气口，但仍要生成带 words 的默认不剪版 `edit\cut_plan.json` 和 `edit\line_timeline.json`。
- 只给 MP4 时默认视为原始真人口播：先 ASR 生成 SRT 和 `speech\segments.json`，然后必须停下来询问是否需要剪口播，不能直接进入标题、素材匹配或生成草稿。
- 只给 MP3 时先做 ASR 生成 SRT 和 `speech\segments.json`；默认不删除气口，但仍要生成带 words 的默认不剪版 `edit\cut_plan.json` 和 `edit\line_timeline.json`，后续按无主画面的全量素材匹配流程处理。
- 只要用户已经提供 SRT（`MP4 + SRT` 或 `MP3 + SRT`），默认完全尊重用户 SRT：不再 ASR、不自动拆合行、不提供逐字能力、不再气口剪辑，除非用户明确要求重识别或重新剪气口。
- 只有用户明确说“直接生成草稿成品”“无需确认直接生成”“不用预览，直接生成”或“跳过确认”时，才可以跳过预览确认。
- “直接生成草稿”“生成剪映草稿”“帮我做成草稿”不属于跳过确认授权。
- 除非用户明确说“标题你来定”“全流程自动”“不用确认标题”或使用跳过确认表达，否则必须先给 3 个标题方案并等待用户选择，不能继续生成分析文件。
- 缺少标题选择或素材策略时，把问题合并成一次简短询问；不要先问素材策略、再单独问标题。可以先读取输入文案/SRT/ASR 结果来拟定标题方案，但在用户回复前不要导出素材、不要生成分析文件、不要调用客户端生成接口。
- 如果缺少模板配置、素材库上下文或第三方 API 配置，必须先停下来说明缺什么。
- 读取 `agent_context_file` 后，必须先校验 `paths.draft_output_dir`。如果为空、缺失或目录不存在，必须停止生成，读取 `references/jianying-draft-dir-setup.md`，用图文教程告诉用户如何设置剪映草稿目录。
- 如果用户只给文案，必须先按 `tts-doubao-flow.md` 生成 MP3 和 SRT；如果用户只给 MP3 或 MP4，必须先按 `tts-doubao-flow.md` 生成 SRT。音视频 ASR 遇到 `ipcm` / 裸 PCM / 大小端异常音轨时，脚本会先自动做音频救援重试，仍失败后再要求用户补 SRT 或文案。
- 文案转配音需要 TTS 配置，音视频转字幕需要 ASR 配置；不要假装没有配置也能继续。
- 如果字幕策略目标需要 `03`，但实际 `style_level: "03"` 为 0 条，必须先修正字幕分层，不能打开预览或生成草稿。
- 如果 `agent_context_file.skills["xycut-video-template-skill"].version` 高于当前 Skill 版本，先使用 `install_dir` 指向的新版本 Skill，或提醒用户重新安装后再继续。

## 目标

把用户从小圆 XYCut 复制出来的视频模板提示词，转成一个可执行的视频模板剪辑流程。

Agent 负责理解输入、规划标题和字幕、确认素材使用策略、调用脚本生成主分析文件；最终剪映草稿组装必须交给小圆 XYCut 客户端。

最终主文件是 `<task_dir>\output\video_template_analysis.json`。客户端预览和生成都以这个文件为准。

## 核心边界

- Agent 不直接写剪映草稿，不手写或修补剪映内部 JSON 字段。
- Agent 不重新解析模板原始草稿来发现标题槽、字幕样式或素材槽；这些信息必须来自 `template_config_file`。
- `*.template.json` 和 `*.assembly.json` 都不写入用户机器的实际路径；`assembly_config_file` 只保存相对 `template_config_file` 所在目录的文件名，给客户端和 Python core 使用，Agent 默认不要展开。
- 素材库的扫描、抽帧、分析、向量化和入库归 `xycut-sucai-skill`；本 Skill 只调用已整理素材库做候选匹配。
- 有视频画面时在计划中写 `source_video.file_path`；只有 MP3 或文案 TTS 生成的音频时写 `source_audio.file_path`，不要为了通过校验伪造 `source_video`。音频-only 任务必须走全量素材匹配，由素材画面、模板包装和字幕组成最终草稿。
- 素材来源涉及联网、扣费、AI 生成或用户手动补素材时，要按用户选择执行，不要替用户默认扩展外部能力。
- GPT 自带图片生成由 Agent 按 `material-ai-generated.md` 执行；火山即梦/SeeDance 只按框架预留，未提供 API 文档和示例前不要自行编造调用代码。
- 统一工作台是客户端本地 API 托管的网页工具，源码位于 `xycut-agent-kit/tools/editing-workbench/public`；Agent 不启动 Node 服务，不要求用户安装 Node。
- 统一工作台固定包含 `口播剪辑 / 素材匹配 / 生成草稿` 三页。前期不做复杂跳转和隐藏逻辑：哪个页面有对应数据就展示，没有数据就显示空状态或不展示该模块。
- 需要用户查看、修改、预览或确认时，必须打开统一工作台或明确告诉用户去统一工作台操作；不要把 `video_template_analysis.json`、`video_template_plan.json`、`README_summary.md`、`material_plan.json`、`subtitle_plan.json` 等中间文件当成用户入口。
- 口播删改结果只以 `<task_dir>\edit\review_state.json`、`<task_dir>\edit\cut_plan.json`、`<task_dir>\edit\line_timeline.json` 为准。
- 所有输入类型都必须有上述 Tab1 定稿文件；不剪口播只是 `delete_ranges=[]`，不是另一套流程。
- 逐字能力只看是否有 ASR/TTS 对齐产生的 `speech\segments.json` words。ASR/TTS 输入必须把 `--segments-json "<task_dir>\speech\segments.json"` 传给 `prepare_video_template_plan.py`；只给 SRT 时不传该参数，默认只有行级能力。
- Tab2 素材匹配必须绑定 Tab1 的长句 `line_id`，也就是 `edit/line_timeline.json.lines[].line_id`；不要把素材挂到 Tab3 拆分后的短字幕 ID（如 `line_002_01`）。Tab3 短 ID 只用于屏幕字幕展示和预设匹配。
- `01/02/03` 分层、过长 `01/02` 字幕拆细和 `03` 字幕拆分必须由 Agent 或用户基于语义完成；`01/02` 单条字幕不能超过 15 个可见字；拆成短字幕时必须保留 `source_line_id`，有 ASR 字级信息时必须保留 `source_word_start_idx/source_word_end_idx`；`03` 短句允许 1 个文字槽，不能要求所有 `03` 都拆成 2 槽或 3 槽；`03` 每个文字槽最多 8 个可见字，超过就必须由 Agent 重新分段或拆成多条时间线字幕；`03` 字幕条目要写 `agent_locked_lines: true`。如果一条 `03` 过长，不能为了凑预设硬塞进 3 槽，应由 Agent 先拆成多条时间线字幕，再重新判断每条是 `01/02/03`。后续分析脚本只能校验和匹配预设，不能为了适配预设自动重拆 `lines` 或自动切分长句。
- 生成草稿前，除非用户明确使用硬性停止条件里列出的跳过确认表达，否则必须先在统一工作台的“生成草稿”页中等待用户确认。独立视频模板预览页只作为兼容和调试兜底，不作为主流程入口。

## 输入

用户从小圆 XYCut 复制出的提示词应是普通文本，不要求用户阅读或编辑 JSON。提示词至少包含：

```text
Agent 上下文文件：
xxx\com.xiaoyuan.jianji\agent-context.json

任务：视频模板
模板：template_slug
```

用户提示词下方可能提供 `MP4 + SRT`、`MP3 + SRT`，也可能提供了一篇文案或者之前我们生成了一篇文案要进行处理。

提示词中的 `Agent 上下文文件` 是唯一必须直接读取的用户本机路径。读取 `agent_context_file` 获取草稿目录、本地客户端 API、Skill 分发目录、视频模板根目录、素材库 Skill 目录、素材库 DB 路径和第三方 API 配置。不要把密钥写入回复。

解析模板时，先读取 `agent_context_file`，再按模板名称或 `模板标识` 定位模板参数文件：

- 在线视频模板优先查：`agent_context_file.paths.video_templates_dir\<template_slug>\<template_slug>.template.json`
- 本地视频模板再查：`agent_context_file.paths.local_video_templates_dir\<template_slug>\<template_slug>.template.json`
- 如果上下文里存在本地索引文件 `paths.local_video_template_index_file`，可以读取索引，用模板名称或 slug 反查实际 `template_config_file`。
- 找到模板参数文件后，不要期待模板 JSON 内包含实际路径；按 `agent_context_file.paths` 和本地索引确定模板目录，不要从提示词里猜测模板目录。

提示词里的“素材库：xxx”只是给用户看的轻量提示。需要使用素材库时，从 `agent_context_file.sucai` 读取 `db_path`、`library_id`、`library_name`、`library_root`、`collection_id` 和 `collection_name`。

AI 剪辑只强制依赖 `agent_context_file.paths.draft_output_dir`。`paths.preset_dir` 只用于普通预设同步到剪映个人预设；缺失时不阻塞视频模板生成。生成草稿时以客户端当前 `paths.draft_output_dir` 为准，不要让旧分析文件里的 `draft_output_dir` 覆盖用户最新设置。

如果 `paths.draft_output_dir` 为空、缺失或目录不存在，必须先停止后续流程，读取 [references/jianying-draft-dir-setup.md](references/jianying-draft-dir-setup.md)，把剪映草稿目录设置教程发给用户；不要创建任务目录、不要 ASR、不要素材匹配、不要生成草稿。

## 任务目录

每次独立生成任务先创建：

```text
<agent_workdir>\xycut-tasks\<task_id>
```

`task_id` 建议为 `YYYYMMDD_HHMMSS_<template_slug>`。

所有中间文件、摘要、候选素材、校验文件和客户端请求文件都必须写入 `<task_dir>`，不要散落在 Agent 工作目录根部。

## 路由

收到任务后，先用下面的简表判断入口；遇到边界情况再阅读 [references/input-routing.md](references/input-routing.md)。

| 输入      | 先补什么                               | 是否默认气口剪辑 | 后续主线                      |
| --------- | -------------------------------------- | ---------------- | ----------------------------- |
| 文案      | TTS 生成 MP3，ASR/对齐生成 SRT 和 `speech\segments.json` | 否，生成带 words 的默认不剪定稿层 | 全量素材匹配                  |
| 只给 MP4  | ASR 生成 SRT 和 `speech\segments.json` | 是               | 剪后时间线 + 素材策略         |
| 只给 MP3  | ASR 生成 SRT 和 `speech\segments.json` | 否，生成带 words 的默认不剪定稿层 | 全量素材匹配                  |
| MP4 + SRT | 不 ASR                                 | 否，生成默认不剪定稿层 | 素材策略：全覆盖或重点 B-roll |
| MP3 + SRT | 不 ASR                                 | 否，生成默认不剪定稿层 | 全量素材匹配                  |

统一工作台可以作为所有任务的任务页使用。所有任务都有 Tab1 定稿层；只有“只给 MP4”默认询问是否自动剪口播，其他输入默认不删，但用户仍可在 Tab1 手动删除句子、字词或波形区间。

然后按实际任务阅读对应参考：

- 模板参数、标题槽和字幕样式：读 [references/template-analysis.md](references/template-analysis.md)。
- SRT 拆分、标题创作、`01/02/03` 字幕规划和收藏预设匹配：读 [references/subtitle-planning.md](references/subtitle-planning.md)。
- 素材覆盖范围、素材来源和素材匹配模式选择：读 [references/material-strategy.md](references/material-strategy.md)。
- 使用本地素材库 DB 检索候选：读 [references/material-local-library.md](references/material-local-library.md)。
- 用户选择网络素材补充时：读 [references/material-network-fallback.md](references/material-network-fallback.md)。
- 用户选择 GPT/ChatGPT 自带图片生成补素材时：读 [references/material-ai-generated.md](references/material-ai-generated.md)。
- 用户选择火山引擎即梦图片或 SeeDance 视频时：读 [references/material-volcengine-ai.md](references/material-volcengine-ai.md)。
- 用户只给文案、只给 MP3 或只给 MP4 时：读 [references/tts-doubao-flow.md](references/tts-doubao-flow.md)。
- 只给 MP4，或用户明确要求重新剪口播/删气口时：读 [references/editing-workbench.md](references/editing-workbench.md)。
- 脚本命令和产物格式：读 [references/script-usage.md](references/script-usage.md)。
- 预览和生成客户端草稿：读 [references/preview-and-generate.md](references/preview-and-generate.md)。

只读取当前任务需要的参考文件。

## 主流程

### 一次询问格式

当标题选择和素材策略至少有一项缺失时，只发一次问题，并保持很短。不要解释完整流程，不要列大段规则。

有 MP4 主画面时，优先使用下面格式：

```text
先选一下，我再生成预览：

标题：1《...》  2《...》  3《...》
素材：A 快速重点覆盖35%  B 精细重点覆盖35%  C 全覆盖

直接回：1A / 2B / 3C，也可以补一句要求。
```

只有 MP3、或文案 TTS 生成 MP3 时，没有主画面，素材默认全覆盖，不要给“重点覆盖 35% / 50%”选项。使用下面格式：

```text
先选一下，我再生成预览：

标题：1《...》  2《...》  3《...》
素材：A 快速全覆盖  B 精细全覆盖

直接回：1A / 2B，也可以补一句要求。
```

如果用户已经明确给了标题，但缺素材策略，只问素材一行；如果用户已经明确给了素材策略，但缺标题，只给标题 3 选 1。用户回复后，按其选择继续，不再重复确认同一问题。

1. 解析用户提示词中的 `Agent 上下文文件` 路径、模板名称/模板标识和后续输入内容，读取 `agent_context_file`，先检查当前 Skill 版本是否低于客户端分发版本，并根据上下文中的视频模板目录或索引定位 `template_config_file`。
2. 按 `input-routing.md` 判断输入类型。
3. 创建 `<task_dir>`，后续所有 TTS、ASR、字幕、素材候选和分析文件都放在这里。
4. 如果只给文案，按 `tts-doubao-flow.md` 生成 MP3 和 SRT；如果只给 MP3 或 MP4，按 `tts-doubao-flow.md` 生成 SRT。只给 MP4 时还必须生成 `speech\segments.json`。
5. 所有任务在 `prepare_video_template_plan.py` 后都会有默认不剪版 `edit\review_state.json`、`edit\cut_plan.json`、`edit\line_timeline.json`。只有只给 MP4，或用户明确要求重新剪口播/删气口时，才按 `editing-workbench.md` 进入删除流程。只给 MP4 的 ASR 完成后，必须先发一次简短询问：

```text
MP4 已识别完成，需要剪口播吗（自动删除口播的重复及错误）？
A 是的，需要
B 不需要，我手动改
C 跳过，不需要
```

用户选 A 时，先自动生成一版口播删改建议并写入同一套 `edit` 文件，再打开统一工作台让用户预览确认。用户选 B 时，只打开统一工作台让用户手动改，并等待保存。用户选 C 时，保留默认不剪版 `edit` 文件继续后续流程。其他输入默认不删除气口，但仍使用默认不剪版 `edit\line_timeline.json` 作为后续源头。
6. 按 `template-analysis.md` 检查模板参数，并基于文案/SRT/剪后时间线生成 3 个标题方案。
7. 同时检查标题选择和素材策略是否齐全；缺任意一项时，按“一次询问格式”合并提问并停止。用户回复后继续，不再拆成两轮问题。
8. 按 `script-usage.md` 检查运行环境并生成初始 `video_template_plan.json`。如果存在 `edit/line_timeline.json`，后续字幕、素材和生成都优先使用剪辑后的时间线。
9. 按 `subtitle-planning.md` 由 Agent 补齐已确认标题、字幕分层、过长 `01/02` 语义拆细、`03` 分类和换行。
10. 按 `material-strategy.md` 落实素材覆盖范围、素材来源和素材匹配模式；有 MP4 主画面时，如果用户选择 A，默认 `partial_broll + 0.35 + local_only + fast`；选择 B，默认 `partial_broll + 0.35 + local_only + refined`；选择 C，默认 `full_cover + local_only + fast`。只有 MP3 或文案 TTS 生成 MP3 时，如果用户选择 A，默认 `full_cover + 1.0 + local_only + fast`；选择 B，默认 `full_cover + 1.0 + local_only + refined`，不要询问或写入 `partial_broll`。
11. 如果用户在一次询问中要求网络补充、AI 生成补充或其他特殊素材策略，再按对应 reference 继续；没有明确要求时不要默认扩展外部素材来源。
12. 如果使用本地素材库，先按 `material-local-library.md` 摸底素材库，再用批量脚本自动生成 query、准备向量、导出候选并选择素材；快速模式只看脚本摘要，精细模式只把 Top5 轻量摘要交给 Agent 复核。
13. 如果用户选择网络补充，按 `material-network-fallback.md` 只补本地不足的部分。
14. 如果用户选择 AI 生成素材补充，按 `material-ai-generated.md` 或 `material-volcengine-ai.md` 只补缺口。
15. 写入或更新 `video_template_plan.json` 中的 `material_plan`。
16. 运行脚本生成唯一主文件 `video_template_analysis.json`。
17. 运行校验脚本；如果 `03` 数量为 0、收藏复合预设匹配失败或素材计划无效，先修正计划，不能继续生成。
18. 按 `preview-and-generate.md` 在统一工作台的“生成草稿”页检查效果；用户确认后调用客户端生成草稿。独立视频模板预览页只在工作台预览暂不可用时兜底使用。

## `material_plan` 目标格式

业务素材选择结果写入 `video_template_analysis.json` 或生成前计划中的 `material_plan`：

```json
{
  "mode": "sucai_library",
  "scope": "partial_broll",
  "match_ratio": 0.35,
  "source_mode": "local_only",
  "match_mode": "fast",
  "asset_type": "video",
  "source_trim": {
    "video_head_ms": 500,
    "apply_to": "matched_broll_video"
  },
  "items": [
    {
      "line_id": "line_001",
      "query": "湖边旅行开场画面",
      "selected_material_id": "mat_0001",
      "file_path": "D:\\素材库\\001\\mat_0001.mp4",
      "source": "sucai_library",
      "provider": "local",
      "asset_type": "video",
      "target_start_ms": 0,
      "target_end_ms": 3200
    }
  ]
}
```

`material_plan.items[].line_id` 必须是 Tab1 长句 ID，来自 `edit/line_timeline.json` 或生成计划里的 `line_timeline.lines[].line_id`。如果 Tab3 把 `line_002` 拆成 `line_002_01 / line_002_02`，素材仍然绑定 `line_002`，不要绑定子字幕 ID。

有 `MP4 + SRT` 时，`scope` 可以是 `partial_broll` 或 `full_cover`。有 `MP3 + SRT` 或文案 TTS 生成 MP3 时，默认 `scope` 为 `full_cover`、`match_ratio` 为 `1.0`，只让用户选择 `match_mode: fast/refined` 和素材来源，不再询问覆盖率。

`scope` 只决定哪些 Tab1 长句要匹配素材：`full_cover` 选择全部长句，`partial_broll` 只选择重点长句。被选中的素材统一使用连续显示时间，也就是当前句真实开始到下一句真实开始；真实发声时间可记录在 `speech_start_ms/speech_end_ms`，素材覆盖时间写入 `target_start_ms/target_end_ms`。不要因为 `partial_broll` 就把被选中素材缩回真实发声结尾；也不要因为 `scope=full_cover` 就跨未匹配长句强行拉长少量素材。

`target_start_ms` / `target_end_ms` 表示素材在成片时间线上的位置。只有确实要裁素材内部片段时，才写 `source_start` / `source_end` 或 `source_start_ms` / `source_end_ms`；不要把成片时间写成源素材裁剪时间。

`source_trim.video_head_ms` 来自 `agent_context_file.video_editing_settings.source_trim.video_head_ms`，默认 500，表示组装草稿时自动跳过匹配到的 B-roll 视频素材开头。用户说“素材开头跳过改成 3 秒”时写 3000；用户说“不跳过”时写 0。这个设置只作用于 `material_plan.items` 匹配到的视频素材，不作用于主视频、口播 A-roll、音频或图片；素材剩余时长不够时客户端会自动不裁。

## 完成回复

如果只是进入预览/确认阶段，告诉用户已打开剪辑工作台，并让用户在工作台检查 `口播剪辑 / 素材匹配 / 生成草稿`，不要让用户打开中间 JSON、Markdown 或任务目录文件。

生成成功后，最终回复只面向普通用户：

```md
# 剪映草稿已生成：<草稿名称>

请打开剪映草稿箱，搜索上面的草稿名称并打开继续编辑。
```

不要把 `video_template_analysis.json`、`video_template_plan.json`、`client_request.json`、`README_summary.md`、SRT、ASR JSON、素材候选 JSON 等中间文件列为结果。只有用户明确要求排查或调试时，才补充任务目录或中间文件路径。
