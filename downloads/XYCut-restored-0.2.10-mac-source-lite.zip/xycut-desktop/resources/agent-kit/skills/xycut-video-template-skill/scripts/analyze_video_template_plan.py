from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any


if hasattr(os.sys.stdout, "reconfigure"):
    os.sys.stdout.reconfigure(encoding="utf-8")
if hasattr(os.sys.stderr, "reconfigure"):
    os.sys.stderr.reconfigure(encoding="utf-8")


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def reject_workspace_root_files(paths: list[Path]) -> list[str]:
    cwd = Path.cwd().resolve()
    errors: list[str] = []
    for path in paths:
        parent = path.parent.resolve()
        if parent == cwd:
            errors.append(
                f"计划/输出文件不能位于 Agent 工作目录根部: {path}. "
                "请使用 <agent_workdir>\\xycut-tasks\\<task_id> 下的文件路径。"
            )
    return errors


def task_dir_from_plan_path(plan_path: Path) -> Path:
    parent = plan_path.parent
    return parent.parent if parent.name.lower() == "output" else parent


def load_authoritative_line_timeline(plan: dict[str, Any], plan_path: Path) -> dict[str, Any] | None:
    candidates: list[Path] = []
    edit_files = plan.get("edit_files") if isinstance(plan.get("edit_files"), dict) else {}
    raw = str(edit_files.get("line_timeline_file") or "").strip()
    if raw:
        candidates.append(Path(raw))
    candidates.append(task_dir_from_plan_path(plan_path) / "edit" / "line_timeline.json")

    for candidate in candidates:
        try:
            if candidate.is_file():
                timeline = read_json(candidate)
        except Exception:
            continue
        if isinstance(timeline, dict) and isinstance(timeline.get("lines"), list):
            return timeline
    return None


def apply_authoritative_line_timeline(plan: dict[str, Any], plan_path: Path) -> None:
    timeline = load_authoritative_line_timeline(plan, plan_path)
    if timeline:
        plan["line_timeline"] = timeline


def local_app_data_dir() -> Path:
    local_appdata = os.environ.get("LOCALAPPDATA", "").strip()
    if local_appdata:
        return Path(local_appdata)
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support"
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))


def default_favorite_index_file() -> Path:
    root = local_app_data_dir() / "com.xiaoyuan.jianji" / "subtitle-presets"
    subtitle_index = root / "subtitle-preset-index.json"
    return subtitle_index if subtitle_index.is_file() else root / "index.json"


def default_preset_cache_root() -> Path:
    return local_app_data_dir() / "com.xiaoyuan.jianji" / "presets"


def to_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def clamp_int(value: Any, minimum: int, maximum: int, default: int) -> int:
    number = to_int(value, default)
    return max(minimum, min(maximum, number))


def normalize_style(value: Any) -> str:
    raw = str(value or "").strip()
    if raw in {"1", "01", "普通", "普通字幕", "普通默认", "默认"}:
        return "01"
    if raw in {"2", "02", "重点", "轻重点", "重点字幕", "普通强调", "强调"}:
        return "02"
    if raw in {"3", "03", "强重点", "关键词", "重点预设"}:
        return "03"
    return raw or "01"


def choose_variant(groups: dict[str, Any], level: str, chars: int) -> dict[str, Any] | None:
    variants = groups.get(level, {}).get("variants", [])
    if not variants:
        return None
    return min(variants, key=lambda item: abs(to_int(item.get("sample_chars")) - chars))


def visible_chars(text: str) -> int:
    units = 0
    has_visible = False
    for char in str(text or ""):
        if char.isspace():
            continue
        has_visible = True
        units += 1 if ord(char) < 128 else 2
    count = units // 2
    return max(1, count) if has_visible else 0


def list_highlight_terms(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [part.strip() for part in re.split(r"[,，、\s]+", value) if part.strip()]
    if isinstance(value, list):
        terms: list[str] = []
        for item in value:
            terms.extend(list_highlight_terms(item))
        return terms
    if isinstance(value, dict):
        terms: list[str] = []
        for key in ("text", "word", "term", "value", "keyword"):
            if value.get(key):
                terms.extend(list_highlight_terms(value.get(key)))
        return terms
    return []


def normalize_highlight_terms(item: dict[str, Any], text: str, level: str) -> list[str]:
    if level == "03":
        return []
    terms: list[str] = []
    for term in list_highlight_terms(item.get("highlight_terms") or item.get("keywords")):
        term = term.strip()
        if not term or term == text or term not in text:
            continue
        if term not in terms:
            terms.append(term)
    if not terms and isinstance(item.get("highlight_ranges"), list):
        for raw in item.get("highlight_ranges") or []:
            if not isinstance(raw, dict):
                continue
            try:
                start = int(raw.get("start", 0))
                end = int(raw.get("end", 0))
            except (TypeError, ValueError):
                continue
            start = max(0, min(start, len(text)))
            end = max(start, min(end, len(text)))
            term = str(raw.get("text") or text[start:end] or "").strip()
            if term and term != text and term in text and term not in terms:
                terms.append(term)
    return terms[:3]


def highlight_ranges_from_terms(terms: list[str], text: str) -> list[dict[str, Any]]:
    ranges: list[dict[str, Any]] = []
    seen: set[tuple[int, int]] = set()
    for term in terms:
        start = text.find(term)
        if start < 0:
            continue
        end = start + len(term)
        key = (start, end)
        if key in seen:
            continue
        seen.add(key)
        ranges.append({"field": "main", "start": start, "end": end, "text": term})
    return ranges


MAX_03_SLOT_CHARS = 8


def target_strong_emphasis_count(total: int, emphasis_ratio: int) -> int:
    if total <= 0:
        return 0
    return max(1, int(total * emphasis_ratio / 100 + 0.5))


def resolve_existing_preset_path(preset: dict[str, Any] | None, cache_root: Path) -> tuple[str, bool, str]:
    if not preset:
        return "", False, ""
    raw_path = str(preset.get("preset_path") or "").strip()
    if raw_path and Path(raw_path).is_dir():
        return raw_path, True, "preset_path"
    name = str(preset.get("name") or "").strip()
    if name and cache_root.is_dir():
        for candidate in cache_root.rglob(name):
            if candidate.is_dir():
                return str(candidate), True, "cache_lookup"
    return raw_path, False, "missing"


def embedded_draft(data: Any) -> dict[str, Any] | None:
    if not isinstance(data, dict):
        return None
    materials = data.get("materials") if isinstance(data.get("materials"), dict) else {}
    drafts = materials.get("drafts") if isinstance(materials.get("drafts"), list) else []
    for draft in drafts:
        if isinstance(draft, dict) and isinstance(draft.get("draft"), dict):
            nested = draft["draft"]
            if isinstance(nested.get("tracks"), list):
                return nested
    if isinstance(data.get("tracks"), list):
        return data
    return None


def load_preset_draft(preset_path: str) -> dict[str, Any] | None:
    root = Path(preset_path)
    for name in ("draft_content.json", "template-2.tmp", "template.tmp"):
        path = root / "preset_draft" / name
        if not path.is_file():
            continue
        try:
            draft = embedded_draft(read_json(path))
        except Exception:
            draft = None
        if draft:
            return draft
    return None


def text_material_value(material: dict[str, Any]) -> str:
    content = material.get("content")
    if isinstance(content, str):
        try:
            parsed = json.loads(content)
            if isinstance(parsed, dict) and isinstance(parsed.get("text"), str):
                return parsed["text"]
        except Exception:
            pass
        return content
    for key in ("translate_original_text", "name"):
        value = material.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def preset_text_slot_stats(preset_path: str) -> tuple[list[str], list[int]]:
    draft = load_preset_draft(preset_path)
    if not draft:
        return [], []
    materials = draft.get("materials") if isinstance(draft.get("materials"), dict) else {}
    texts = materials.get("texts") if isinstance(materials.get("texts"), list) else []
    text_map = {
        str(item.get("id")): item
        for item in texts
        if isinstance(item, dict) and item.get("id")
    }
    sample_texts: list[str] = []
    tracks = draft.get("tracks") if isinstance(draft.get("tracks"), list) else []
    for track in tracks:
        if not isinstance(track, dict) or str(track.get("type") or "").lower() != "text":
            continue
        segments = track.get("segments") if isinstance(track.get("segments"), list) else []
        for segment in segments:
            if not isinstance(segment, dict):
                continue
            material = text_map.get(str(segment.get("material_id") or ""))
            if not isinstance(material, dict):
                continue
            text = text_material_value(material).strip()
            if text:
                sample_texts.append(text)
    if not sample_texts:
        sample_texts = [
            text_material_value(item).strip()
            for item in texts
            if isinstance(item, dict) and text_material_value(item).strip()
        ]
    sample_lengths = [max(1, visible_chars(text)) for text in sample_texts]
    return sample_texts, sample_lengths


def favorite_candidates(favorite_index: dict[str, Any], cache_root: Path) -> list[dict[str, Any]]:
    group_id = str(favorite_index.get("default_group_id") or "").strip()
    presets = favorite_index.get("presets") if isinstance(favorite_index.get("presets"), list) else []
    candidates: list[dict[str, Any]] = []
    for preset in presets:
        if not isinstance(preset, dict):
            continue
        groups = preset.get("favorite_group_ids") if isinstance(preset.get("favorite_group_ids"), list) else []
        if group_id and group_id not in groups:
            continue
        path, exists, source = resolve_existing_preset_path(preset, cache_root)
        sample_texts, computed_slot_limits = preset_text_slot_stats(path) if exists else ([], [])
        raw_slot_limits = preset.get("slot_max_chars") if isinstance(preset.get("slot_max_chars"), list) else []
        slot_limits = computed_slot_limits or [to_int(value) for value in raw_slot_limits if to_int(value) > 0]
        slot_count = len(computed_slot_limits) if computed_slot_limits else to_int(preset.get("slot_count"))
        candidates.append(
            {
                **preset,
                "preset_path": path,
                "preset_path_exists": exists,
                "preset_path_source": source,
                "sample_texts": sample_texts,
                "sample_lengths": computed_slot_limits,
                "slot_max_chars": slot_limits,
                "text_slot_count": slot_count,
            }
        )
    return candidates


def candidate_ref(candidate: dict[str, Any] | None) -> str:
    if not isinstance(candidate, dict):
        return ""
    return str(candidate.get("preset_id") or candidate.get("name") or candidate.get("preset_path") or "").strip()


def requested_preset_ref(match: Any) -> str:
    if not isinstance(match, dict):
        return ""
    preset = match.get("preset") if isinstance(match.get("preset"), dict) else {}
    return str(
        match.get("preset_id")
        or match.get("name")
        or match.get("preset_path")
        or preset.get("preset_id")
        or preset.get("name")
        or preset.get("preset_path")
        or ""
    ).strip()


def find_candidate(candidates: list[dict[str, Any]], ref: str) -> dict[str, Any] | None:
    clean = str(ref or "").strip()
    if not clean:
        return None
    for candidate in candidates:
        values = {
            str(candidate.get("preset_id") or "").strip(),
            str(candidate.get("name") or "").strip(),
            str(candidate.get("preset_path") or "").strip(),
        }
        if clean in values:
            return candidate
    return None


def normalize_lines(item: dict[str, Any], text: str, level: str) -> list[str]:
    raw = item.get("lines")
    if isinstance(raw, list):
        lines = [str(line or "").strip() for line in raw if str(line or "").strip()]
    else:
        lines = []
    if lines:
        return lines[:3] if level == "03" else [lines[0]]
    return [text] if text else []


def line_overflow(lines: list[str], limits: list[int]) -> int:
    if not limits:
        return 0
    overflow = 0
    for index, line in enumerate(lines):
        limit = limits[min(index, len(limits) - 1)]
        if limit > 0:
            overflow += max(0, visible_chars(line) - limit)
    return overflow


def candidate_slot_limits(candidate: dict[str, Any]) -> list[int]:
    raw = candidate.get("slot_max_chars") if isinstance(candidate.get("slot_max_chars"), list) else []
    return [to_int(value) for value in raw if to_int(value) > 0]


def candidate_slot_count(candidate: dict[str, Any]) -> int:
    return to_int(candidate.get("text_slot_count") or candidate.get("slot_count"))


def same_slot_available(candidates: list[dict[str, Any]], slot_count: int) -> bool:
    return any(
        item.get("preset_path_exists") and candidate_slot_count(item) == slot_count
        for item in candidates
    )


def long_03_slot_details(lines: list[str]) -> list[dict[str, int]]:
    output: list[dict[str, int]] = []
    for index, line in enumerate(lines, start=1):
        count = visible_chars(line)
        if count > MAX_03_SLOT_CHARS:
            output.append({"slot_index": index, "chars": count, "max_chars": MAX_03_SLOT_CHARS})
    return output


def candidate_duration_ms(candidate: dict[str, Any]) -> int:
    raw = to_int(
        candidate.get("suggest_duration_ms")
        or candidate.get("duration_ms")
        or candidate.get("duration")
        or candidate.get("duration_us")
    )
    if raw <= 0:
        return 0
    return int(raw / 1000) if raw > 60_000 else raw


def subtitle_duration_ms_for_item(item: dict[str, Any]) -> int:
    duration = to_int(item.get("duration_ms"))
    if duration > 0:
        return duration
    start = to_int(item.get("start_ms"))
    end = to_int(item.get("end_ms"))
    return max(0, end - start)


def timeline_line_time_ms(line: dict[str, Any], ms_key: str, seconds_key: str) -> int:
    try:
        value = line.get(ms_key)
        if value is not None:
            return int(round(float(value)))
    except (TypeError, ValueError):
        pass
    try:
        return int(round(float(line.get(seconds_key) or 0) * 1000))
    except (TypeError, ValueError):
        return 0


def seconds_value(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number / 1000.0 if abs(number) >= 1000 else number


def source_to_target_seconds(line: dict[str, Any], source_time: float) -> float | None:
    segments = line.get("talking_segments") if isinstance(line.get("talking_segments"), list) else []
    for segment in segments:
        if not isinstance(segment, dict):
            continue
        source_start = seconds_value(segment.get("source_start"))
        source_end = seconds_value(segment.get("source_end"), source_start)
        if source_end <= source_start:
            continue
        if source_time + 0.0005 < source_start or source_time - 0.0005 > source_end:
            continue
        target_start = seconds_value(segment.get("target_start"))
        speed = max(0.1, seconds_value(segment.get("speed"), 1.0))
        return target_start + max(0.0, source_time - source_start) / speed

    source_start = seconds_value(line.get("source_start"))
    source_end = seconds_value(line.get("source_end"), source_start)
    target_start = seconds_value(line.get("target_start", line.get("start")), source_start)
    target_end = seconds_value(line.get("target_end", line.get("end")), target_start)
    if source_end > source_start and target_end > target_start:
        ratio = max(0.0, min(1.0, (source_time - source_start) / (source_end - source_start)))
        return target_start + (target_end - target_start) * ratio
    return None


def word_idx(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def subtitle_word_range_ms(item: dict[str, Any], line: dict[str, Any]) -> tuple[int, int] | None:
    return subtitle_word_range_ms_for_lines(item, [line])


def subtitle_word_range_ms_for_lines(item: dict[str, Any], lines: list[dict[str, Any]]) -> tuple[int, int] | None:
    start_idx = word_idx(item.get("source_word_start_idx"))
    end_idx = word_idx(item.get("source_word_end_idx"))
    if start_idx is None or end_idx is None or end_idx < start_idx:
        return None
    starts: list[int] = []
    ends: list[int] = []
    for line in lines:
        if not isinstance(line, dict):
            continue
        words = line.get("words") if isinstance(line.get("words"), list) else []
        for word in words:
            if not isinstance(word, dict):
                continue
            current_idx = word_idx(word.get("idx"))
            if current_idx is None or current_idx < start_idx or current_idx > end_idx:
                continue
            source_start = seconds_value(word.get("start", word.get("start_ms")))
            source_end = seconds_value(word.get("end", word.get("end_ms")), source_start)
            target_start = source_to_target_seconds(line, source_start)
            target_end = source_to_target_seconds(line, source_end)
            if target_start is None or target_end is None or target_end <= target_start:
                continue
            starts.append(int(round(target_start * 1000)))
            ends.append(int(round(target_end * 1000)))
    if not starts or not ends:
        return None
    start_ms = min(starts)
    end_ms = max(ends)
    if end_ms <= start_ms:
        return None
    return start_ms, end_ms


def parent_line_ids_for_subtitle(item: dict[str, Any]) -> list[str]:
    ids: list[str] = []
    source_line_ids = item.get("source_line_ids")
    if isinstance(source_line_ids, list):
        for value in source_line_ids:
            line_id = str(value or "").strip()
            if line_id and line_id not in ids:
                ids.append(line_id)
    for value in (item.get("source_line_id"), item.get("line_id"), item.get("id")):
        line_id = str(value or "").strip()
        if line_id and line_id not in ids:
            ids.append(line_id)
    return ids


def parent_line_id_for_subtitle(item: dict[str, Any]) -> str:
    ids = parent_line_ids_for_subtitle(item)
    return ids[0] if ids else ""


def retime_subtitles_to_line_timeline(subtitles: list[dict[str, Any]], line_timeline: dict[str, Any]) -> list[dict[str, Any]]:
    lines = line_timeline.get("lines") if isinstance(line_timeline.get("lines"), list) else []
    if not subtitles or not lines:
        return subtitles
    parent_times: dict[str, tuple[int, int]] = {}
    lines_by_id: dict[str, dict[str, Any]] = {}
    for index, line in enumerate(lines, start=1):
        if not isinstance(line, dict):
            continue
        line_id = str(line.get("line_id") or line.get("id") or f"line_{index:03d}").strip()
        lines_by_id[line_id] = line
        start_ms = timeline_line_time_ms(line, "start_ms", "start")
        end_ms = timeline_line_time_ms(line, "end_ms", "end")
        if line_id and end_ms > start_ms:
            parent_times[line_id] = (start_ms, end_ms)
    if not parent_times:
        return subtitles

    output = [dict(item) for item in subtitles]
    word_timed_indices: set[int] = set()
    for index, item in enumerate(output):
        parent_ids = parent_line_ids_for_subtitle(item)
        parent_lines = [lines_by_id[parent_id] for parent_id in parent_ids if parent_id in lines_by_id]
        if not parent_lines:
            continue
        word_range = subtitle_word_range_ms_for_lines(item, parent_lines)
        if not word_range:
            continue
        start_ms, end_ms = word_range
        item["start_ms"] = start_ms
        item["end_ms"] = end_ms
        item["duration_ms"] = end_ms - start_ms
        if parent_ids:
            item["source_line_id"] = item.get("source_line_id") or parent_ids[0]
            if len(parent_ids) > 1:
                item["source_line_ids"] = parent_ids
        item["timing_source"] = "source_word_range"
        word_timed_indices.add(index)

    groups: dict[str, list[int]] = {}
    for index, item in enumerate(subtitles):
        if index in word_timed_indices:
            continue
        parent_ids = [parent_id for parent_id in parent_line_ids_for_subtitle(item) if parent_id in parent_times]
        if len(parent_ids) > 1:
            starts = [parent_times[parent_id][0] for parent_id in parent_ids]
            ends = [parent_times[parent_id][1] for parent_id in parent_ids]
            output[index]["start_ms"] = min(starts)
            output[index]["end_ms"] = max(ends)
            output[index]["duration_ms"] = max(1, output[index]["end_ms"] - output[index]["start_ms"])
            output[index]["source_line_id"] = output[index].get("source_line_id") or parent_ids[0]
            output[index]["source_line_ids"] = parent_ids
            output[index]["timing_source"] = "parent_multi_range_fallback"
            continue
        parent_id = parent_line_id_for_subtitle(item)
        if parent_id in parent_times:
            groups.setdefault(parent_id, []).append(index)
    if not groups:
        return output

    for parent_id, indices in groups.items():
        parent_start, parent_end = parent_times[parent_id]
        parent_duration = max(1, parent_end - parent_start)
        weights: list[int] = []
        for index in indices:
            item = output[index]
            duration = to_int(item.get("duration_ms"))
            if duration <= 0:
                duration = max(1, to_int(item.get("end_ms")) - to_int(item.get("start_ms")))
            weights.append(max(1, duration))
        weight_total = sum(weights) or len(indices)
        cursor = parent_start
        elapsed_weight = 0
        for position, index in enumerate(indices):
            elapsed_weight += weights[position]
            next_end = parent_end if position == len(indices) - 1 else int(round(parent_start + parent_duration * elapsed_weight / weight_total))
            output[index]["start_ms"] = int(cursor)
            output[index]["end_ms"] = max(int(cursor) + 1, int(next_end))
            output[index]["duration_ms"] = output[index]["end_ms"] - output[index]["start_ms"]
            output[index]["source_line_id"] = output[index].get("source_line_id") or parent_id
            output[index]["timing_source"] = "parent_duration_weighted_fallback"
            cursor = output[index]["end_ms"]
    return output


def line_timeline_duration_ms(line_timeline: dict[str, Any], subtitles: list[dict[str, Any]]) -> int:
    for key in ("timeline_duration_ms", "duration_ms", "total_duration_ms"):
        value = to_int(line_timeline.get(key))
        if value > 0:
            return value
    lines = line_timeline.get("lines") if isinstance(line_timeline.get("lines"), list) else []
    line_end = max((timeline_line_time_ms(line, "end_ms", "end") for line in lines if isinstance(line, dict)), default=0)
    subtitle_end = max((to_int(item.get("end_ms")) for item in subtitles if isinstance(item, dict)), default=0)
    return max(line_end, subtitle_end)


def normalize_subtitle_display_timeline(subtitles: list[dict[str, Any]], timeline_duration_ms: int = 0) -> list[dict[str, Any]]:
    if not subtitles:
        return subtitles
    output = [dict(item) for item in subtitles]
    ordered: list[tuple[int, int, dict[str, Any]]] = []
    for index, item in enumerate(output):
        start = to_int(item.get("start_ms"))
        end = to_int(item.get("end_ms"))
        if end <= start:
            end = start + max(1, to_int(item.get("duration_ms")))
        ordered.append((start, index, item))
    ordered.sort(key=lambda entry: (entry[0], entry[1]))
    filled_gap_count = 0
    filled_gap_ms = 0
    for position, (start, _index, item) in enumerate(ordered):
        current_end = to_int(item.get("end_ms"))
        if current_end <= start:
            current_end = start + max(1, to_int(item.get("duration_ms")))
        target_end = current_end
        if position + 1 < len(ordered):
            next_start = max(start + 1, ordered[position + 1][0])
            if next_start > current_end:
                filled_gap_count += 1
                filled_gap_ms += next_start - current_end
            target_end = max(start + 1, next_start)
        elif timeline_duration_ms > current_end:
            filled_gap_count += 1
            filled_gap_ms += timeline_duration_ms - current_end
            target_end = max(start + 1, timeline_duration_ms)
        item["end_ms"] = int(target_end)
        item["duration_ms"] = max(1, int(target_end) - int(start))
        if target_end != current_end:
            item["display_timing_source"] = "continuous_subtitle_display"
    if filled_gap_count:
        for item in output:
            item["display_gap_fill"] = {
                "mode": "continuous_to_next_subtitle",
                "filled_gap_count": filled_gap_count,
                "filled_gap_ms": filled_gap_ms,
            }
    return output


def normalize_category_id(value: Any) -> str:
    raw = str(value or "").strip()
    return raw or "default"


def candidate_category_ids(candidate: dict[str, Any]) -> list[str]:
    raw = candidate.get("category_ids") if isinstance(candidate.get("category_ids"), list) else []
    values = [normalize_category_id(item) for item in raw if normalize_category_id(item)]
    return values or ["default"]


def candidate_matches_category(candidate: dict[str, Any], category_id: str) -> bool:
    target = normalize_category_id(category_id)
    if target == "default":
        return True
    return target in candidate_category_ids(candidate)


def candidate_score(
    candidate: dict[str, Any],
    lines: list[str],
    category_id: str,
    subtitle_duration_ms: int = 0,
    previous_ref: str = "",
    used_refs: dict[str, int] | None = None,
) -> tuple[int, int, int, int, int, int, int, int, str]:
    target_slot_count = max(1, len(lines) or 1)
    slot_count = candidate_slot_count(candidate)
    overflow = line_overflow(lines, candidate_slot_limits(candidate))
    ref = candidate_ref(candidate)
    used_count = (used_refs or {}).get(ref, 0)
    preset_duration_ms = candidate_duration_ms(candidate)
    duration_delta = abs(preset_duration_ms - subtitle_duration_ms) if preset_duration_ms > 0 and subtitle_duration_ms > 0 else 999_999_999
    return (
        0 if slot_count == target_slot_count else 1,
        0 if overflow <= 0 else 1,
        0 if candidate.get("ai_editing_ready") else 1,
        duration_delta,
        0 if candidate_matches_category(candidate, category_id) else 1,
        overflow,
        used_count,
        1 if previous_ref and ref == previous_ref else 0,
        str(candidate.get("name") or candidate.get("preset_id") or ""),
    )


def select_favorite_for_03(
    candidates: list[dict[str, Any]],
    lines: list[str],
    category_id: str = "default",
    subtitle_duration_ms: int = 0,
    previous_ref: str = "",
    used_refs: dict[str, int] | None = None,
) -> dict[str, Any] | None:
    readable = [item for item in candidates if item.get("preset_path_exists")]
    if not readable:
        return None
    target_slot_count = max(1, len(lines) or 1)
    pool = readable
    category_pool = [item for item in pool if candidate_matches_category(item, category_id)]
    exact_category_pool = [
        item
        for item in category_pool
        if candidate_slot_count(item) == target_slot_count
    ]
    exact_pool = [
        item
        for item in pool
        if candidate_slot_count(item) == target_slot_count
    ]
    ranked_pool = exact_category_pool or exact_pool or category_pool or pool
    non_overflow = [item for item in ranked_pool if line_overflow(lines, candidate_slot_limits(item)) <= 0]
    ranked_pool = non_overflow or ranked_pool
    ranked = sorted(
        ranked_pool,
        key=lambda item: candidate_score(item, lines, category_id, subtitle_duration_ms, previous_ref, used_refs),
    )
    if len(ranked) > 1 and previous_ref and candidate_ref(ranked[0]) == previous_ref:
        same_slot_alternative = next(
            (
                item
                for item in ranked[1:]
                if candidate_slot_count(item) == candidate_slot_count(ranked[0])
                and line_overflow(lines, candidate_slot_limits(item)) == line_overflow(lines, candidate_slot_limits(ranked[0]))
            ),
            None,
        )
        if same_slot_alternative:
            return same_slot_alternative
    return ranked[0]


def title_from_plan(plan: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    existing = plan.get("title") if isinstance(plan.get("title"), dict) else {}
    items = existing.get("items") if isinstance(existing.get("items"), list) else []
    slots = config.get("title_slots") if isinstance(config.get("title_slots"), list) else []
    if items and slots:
        items = items[: len(slots)]
    if not items and str(existing.get("text") or "").strip():
        items = [{"slot_index": 1, "text": str(existing.get("text") or "").strip()}]
    lines = [str(item.get("text") or "") for item in items if isinstance(item, dict)]
    return {
        "text": str(existing.get("text") or (items[0].get("text") if items else lines[0] if lines else "")),
        "lines": lines,
        "items": items,
        "line_chars": [visible_chars(line) for line in lines],
        "preset_match": {"source": "template_title_slots", "slots": slots[: len(items)]},
        "agent_note": "agent_decision" if items else "missing_agent_title",
    }


def analyze_plan(
    plan: dict[str, Any],
    template_config: dict[str, Any],
    favorite_index: dict[str, Any],
    cache_root: Path,
    emphasis_ratio: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    updated = json.loads(json.dumps(plan, ensure_ascii=False))
    groups = {
        group.get("style_level"): group
        for group in template_config.get("subtitle_style_groups", [])
        if isinstance(group, dict)
    }
    candidates = favorite_candidates(favorite_index, cache_root)

    raw_subtitles = updated.get("subtitles") if isinstance(updated.get("subtitles"), list) else []
    source_subtitles = [item for item in raw_subtitles if isinstance(item, dict)]
    analyzed_subtitles: list[dict[str, Any]] = []
    previous_03_ref = ""
    used_03_refs: dict[str, int] = {}
    warnings: list[str] = []
    selected_by_subtitle: list[dict[str, Any]] = []
    previous_level = ""
    for item in source_subtitles:
        if not isinstance(item, dict):
            continue
        text = str(item.get("text") or "").replace("\n", "")
        index = to_int(item.get("index"))
        raw_style_level = item.get("style_level") or item.get("style_id")
        level = normalize_style(raw_style_level or "01")
        lines = normalize_lines(item, text, level)
        highlight_terms = normalize_highlight_terms(item, text, level)
        highlight_ranges = highlight_ranges_from_terms(highlight_terms, text)
        secondary_text = str(item.get("secondary_text") or item.get("text_2") or "").strip()
        item["style_level"] = level
        item["lines"] = lines
        item["line_chars"] = [visible_chars(line) for line in lines]
        item["category_id"] = normalize_category_id(item.get("category_id") or item.get("category"))
        item["agent_note"] = str(
            item.get("agent_note") or ("agent_decision" if raw_style_level else "fallback_normal_subtitle")
        )
        if level == "03" and previous_level == "03":
            warnings.append(f"第 {index} 句与上一句连续使用 03，请让 Agent 复核是否应改一条为 02。")
        if level == "03":
            existing_match = item.get("preset_match") if isinstance(item.get("preset_match"), dict) else {}
            requested = find_candidate(candidates, requested_preset_ref(existing_match))
            if requested and not requested.get("preset_path_exists"):
                warnings.append(f"第 {index} 句 03 指定预设不存在本地文件，已改为自动匹配可用收藏预设。")
                requested = None
            duration_ms = subtitle_duration_ms_for_item(item)
            selected_03 = requested or select_favorite_for_03(
                candidates,
                lines,
                item["category_id"],
                duration_ms,
                previous_03_ref,
                used_03_refs,
            )
            slot_count = max(1, to_int((selected_03 or {}).get("text_slot_count"), len(lines) or 1))
            slot_limits = candidate_slot_limits(selected_03 or {})
            item["lines"] = lines
            item["line_chars"] = [visible_chars(line) for line in lines]
            item["agent_locked_lines"] = True
            selected_ref = candidate_ref(selected_03)
            overflow_chars = line_overflow(lines, slot_limits)
            target_slot_count = max(1, len(lines) or 1)
            matched_slot_count = slot_count == target_slot_count
            missing_same_slot = not same_slot_available(candidates, target_slot_count)
            long_slot_details = long_03_slot_details(lines)
            needs_agent_revision = bool(long_slot_details)
            revision_reasons: list[str] = []
            if long_slot_details:
                detail = "、".join(
                    f"第{entry['slot_index']}槽{entry['chars']}字"
                    for entry in long_slot_details
                )
                revision_reasons.append(
                    f"03 每个文字槽最多 {MAX_03_SLOT_CHARS} 字，{detail} 已超出；"
                    "请按语义重新分段，必要时拆成多条时间线字幕。"
                )
            if not selected_03:
                warnings.append(f"第 {index} 句 03 未匹配到本地可用收藏预设。")
            elif not matched_slot_count:
                warnings.append(f"第 {index} 句 03 拆分段数 {len(lines)} 与选中预设文字槽 {slot_count} 不一致，请在工作台调整。")
            if long_slot_details:
                warnings.append(f"第 {index} 句 03 每槽超过 {MAX_03_SLOT_CHARS} 字限制，请让 Agent 重新分段。")
            if overflow_chars > 0:
                warnings.append(f"第 {index} 句 03 文字超出预设槽位 {overflow_chars} 字，请在工作台改短或换预设。")
            if selected_ref and previous_03_ref and selected_ref == previous_03_ref:
                warnings.append(f"第 {index} 句 03 与上一条 03 使用相同预设: {selected_03.get('name') if selected_03 else selected_ref}")
            if selected_ref:
                previous_03_ref = selected_ref
                used_03_refs[selected_ref] = used_03_refs.get(selected_ref, 0) + 1
            item["preset_match"] = {
                "source": str(existing_match.get("source") or "user_selected") if requested else "fallback_by_lines",
                "style_level": "03",
                "category_id": item["category_id"],
                "favorite_group_id": favorite_index.get("default_group_id"),
                "preset": selected_03,
                "slot_count": slot_count,
                "slot_max_chars": slot_limits,
                "input_lengths": [visible_chars(line) for line in lines],
                "overflow_chars": overflow_chars,
                "same_slot_matched": bool(selected_03 and matched_slot_count),
                "preset_match_missing_same_slot": missing_same_slot,
                "needs_agent_revision": needs_agent_revision,
                "revision_reason": "；".join(revision_reasons),
                "long_slot_details": long_slot_details,
                "warnings": [
                    message
                    for message in [
                        "当前 03 分段存在超过 8 字的文字槽，需要 Agent 重新分段。" if long_slot_details else "",
                        f"文字超出预设槽位 {overflow_chars} 字，请在工作台改短或换预设。" if overflow_chars > 0 else "",
                        "没有找到同槽数的可用 03 收藏预设，当前预设库不足。" if missing_same_slot else "",
                        "选中预设文字槽数量与 Agent 分段数量不一致，请在工作台调整。" if selected_03 and not matched_slot_count else "",
                    ]
                    if message
                ],
            }
            selected_by_subtitle.append(
                {
                    "index": index,
                    "text": text,
                    "lines": lines,
                    "category_id": item["category_id"],
                    "preset": selected_03,
                    "source": item["preset_match"]["source"],
                }
            )
        else:
            item["preset_match"] = {
                "source": "template_subtitle_style_groups",
                "style_level": level,
                "variant": choose_variant(groups, level, len(text)),
            }
        analyzed_subtitles.append(
            {
                "index": index,
                "line_id": item.get("line_id") or item.get("id") or f"line_{index:03d}",
                "source_index": item.get("source_index"),
                "source_line_id": item.get("source_line_id"),
                "source_line_ids": item.get("source_line_ids"),
                "source_word_start_idx": item.get("source_word_start_idx"),
                "source_word_end_idx": item.get("source_word_end_idx"),
                "source_text_start": item.get("source_text_start"),
                "source_text_end": item.get("source_text_end"),
                "start_ms": item.get("start_ms"),
                "end_ms": item.get("end_ms"),
                "duration_ms": item.get("duration_ms"),
                "text": text,
                "secondary_text": secondary_text,
                "highlight_terms": highlight_terms,
                "highlight_ranges": highlight_ranges,
                "style_level": level,
                "lines": lines,
                "line_chars": item["line_chars"],
                "category_id": item["category_id"],
                "agent_note": item["agent_note"],
                "agent_locked_lines": bool(item.get("agent_locked_lines")),
                "preset_match": item["preset_match"],
            }
        )
        previous_level = level

    updated["title"] = title_from_plan(updated, template_config)
    if not updated["title"].get("items"):
        warnings.append("标题为空：请让 Agent 根据 SRT 和模板 title_slots 补齐 title.items。")
    updated["subtitle_strategy"] = {
        "approach": "agent_decides_title_subtitle_levels_03_category_and_lines; code_selects_03_presets_by_category_slots_and_chars",
        "emphasis_ratio": emphasis_ratio,
        "emphasis_ratio_scope": "03_only",
        "target_03_count": target_strong_emphasis_count(len(source_subtitles), emphasis_ratio),
        "strong_emphasis_indices": [
            item["index"] for item in analyzed_subtitles if item.get("style_level") == "03"
        ],
        "light_emphasis_indices": [
            item["index"] for item in analyzed_subtitles if item.get("style_level") == "02"
        ],
        "normal_indices": [item["index"] for item in analyzed_subtitles if item.get("style_level") == "01"],
        "warnings": warnings,
    }
    updated["subtitles"] = analyzed_subtitles
    timeline = updated.get("line_timeline") if isinstance(updated.get("line_timeline"), dict) else {}
    analyzed_subtitles = retime_subtitles_to_line_timeline(analyzed_subtitles, timeline)
    subtitle_timeline_duration_ms = max(
        line_timeline_duration_ms(timeline, analyzed_subtitles),
        to_int(updated.get("timeline_duration_ms")),
    )
    analyzed_subtitles = normalize_subtitle_display_timeline(analyzed_subtitles, subtitle_timeline_duration_ms)
    updated["subtitles"] = analyzed_subtitles
    actual_03_count = len(updated["subtitle_strategy"]["strong_emphasis_indices"])
    target_03_count = updated["subtitle_strategy"]["target_03_count"]
    if actual_03_count < target_03_count:
        warnings.append(f"03 数量低于目标：当前 {actual_03_count} 条，目标约 {target_03_count} 条；请让 Agent 复核字幕分层。")
    analysis = {
        "schema_version": 2,
        "mode": "video_template",
        "draft_name": updated.get("draft_name"),
        "template_slug": updated.get("template_slug"),
        "template_dir": updated.get("template_dir"),
        "template_config_file": updated.get("template_config_file"),
        "draft_output_dir": updated.get("draft_output_dir"),
        "source_video": updated.get("source_video"),
        "source_audio": updated.get("source_audio"),
        "source_srt": updated.get("source_srt"),
        "line_timeline": updated.get("line_timeline"),
        "timeline_duration_ms": updated.get("timeline_duration_ms"),
        "title": updated["title"],
        "subtitles": analyzed_subtitles,
        "favorite_selection": {
            "default_group_id": favorite_index.get("default_group_id"),
            "default_group_preset_count": len(candidates),
            "candidates": candidates,
            "selected_by_subtitle": selected_by_subtitle,
            "selected_for_03": (selected_by_subtitle[0].get("preset") if selected_by_subtitle else None),
            "selected_text_slot_count": (
                to_int((selected_by_subtitle[0].get("preset") or {}).get("text_slot_count"))
                if selected_by_subtitle
                else 0
            ),
            "selected_has_local_preset_path": bool(
                selected_by_subtitle and (selected_by_subtitle[0].get("preset") or {}).get("preset_path_exists")
            ),
        },
        "subtitle_strategy": updated["subtitle_strategy"],
        "generation_plan": updated,
    }
    return updated, analysis


def write_summary(path: Path, analysis: dict[str, Any]) -> None:
    lines: list[str] = ["# Video Template Agent Analysis", "", "## Favorite Candidates"]
    for candidate in analysis["favorite_selection"].get("candidates", []):
        lines.append(
            f"- {candidate.get('name')}: slots={candidate.get('text_slot_count')}, "
            f"ai_ready={bool(candidate.get('ai_editing_ready'))}, "
            f"categories={candidate.get('category_ids') or ['default']}, "
            f"path_exists={candidate.get('preset_path_exists')}, source={candidate.get('preset_path_source')}"
        )
    lines.extend(["", "## Selected 03"])
    selected_items = analysis["favorite_selection"].get("selected_by_subtitle") or []
    if selected_items:
        for selected_item in selected_items:
            preset = selected_item.get("preset") or {}
            lines.append(
                f"- subtitle #{selected_item.get('index')}: {preset.get('name')} "
                f"category={selected_item.get('category_id') or 'default'} "
                f"slots={preset.get('text_slot_count')} source={selected_item.get('source')} "
                f"lines=[" + " / ".join(selected_item.get("lines") or []) + "]"
            )
    else:
        lines.append("- none")
    lines.extend(["", "## Title"])
    for item in analysis["title"].get("items", []):
        lines.append(f"- slot {item.get('slot_index')}: {item.get('text')}")
    lines.extend(["", "## Subtitles"])
    for subtitle in analysis.get("subtitles", []):
        preset = subtitle.get("preset_match", {}).get("preset") or {}
        preset_text = f" preset={preset.get('name')}" if preset else ""
        split_text = ""
        if len(subtitle.get("lines") or []) > 1:
            split_text = " lines=[" + " / ".join(subtitle["lines"]) + "]"
        lines.append(
            f"- #{subtitle.get('index')} {subtitle.get('start_ms')}-{subtitle.get('end_ms')}ms "
            f"level={subtitle.get('style_level')} category={subtitle.get('category_id') or 'default'}{preset_text}: "
            f"{subtitle.get('text')}{split_text}"
        )
    write_json(path.with_suffix(".json"), {"lines": lines})
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyze a video-template plan and produce Agent-owned data.")
    parser.add_argument("--plan", required=True)
    parser.add_argument("--template-config-file", required=True)
    parser.add_argument("--favorite-index", default=str(default_favorite_index_file()))
    parser.add_argument("--preset-cache-root", default=str(default_preset_cache_root()))
    parser.add_argument("--output-plan", default="", help="Defaults to overwriting --plan with normalized 03/title data.")
    parser.add_argument("--analysis-output", required=True)
    parser.add_argument("--client-body-output", default="")
    parser.add_argument("--summary-output", default="")
    parser.add_argument("--target-03-slots", type=int, default=0, help="Deprecated. 03 段数由每条字幕 lines 决定。")
    parser.add_argument("--emphasis-ratio", type=int, default=30)
    args = parser.parse_args()

    try:
        output_plan_path = Path(args.output_plan) if args.output_plan else Path(args.plan)
        guarded_paths = [Path(args.plan), Path(args.analysis_output), output_plan_path]
        if args.client_body_output:
            guarded_paths.append(Path(args.client_body_output))
        if args.summary_output:
            guarded_paths.append(Path(args.summary_output))
        root_errors = reject_workspace_root_files(guarded_paths)
        if root_errors:
            print(json.dumps({"ok": False, "errors": root_errors}, ensure_ascii=False, indent=2))
            return 2

        plan_path = Path(args.plan)
        plan = read_json(plan_path)
        apply_authoritative_line_timeline(plan, plan_path)
        template_config = read_json(Path(args.template_config_file))
        favorite_index = read_json(Path(args.favorite_index)) if Path(args.favorite_index).is_file() else {}
        emphasis_ratio = clamp_int(args.emphasis_ratio, 30, 60, 30)
        updated, analysis = analyze_plan(
            plan,
            template_config,
            favorite_index,
            Path(args.preset_cache_root),
            emphasis_ratio,
        )
        client_body = {
            "mode": "video_template",
            "template_slug": updated.get("template_slug"),
            "template_dir": updated.get("template_dir"),
            "template_config_file": updated.get("template_config_file"),
            "draft_output_dir": updated.get("draft_output_dir"),
            "generation_plan": updated,
        }
        write_json(Path(args.analysis_output), analysis)
        write_json(output_plan_path, updated)
        if args.client_body_output:
            write_json(Path(args.client_body_output), client_body)
        if args.summary_output:
            write_summary(Path(args.summary_output), analysis)
        print(
            json.dumps(
                {
                    "ok": True,
                    "output_plan": str(output_plan_path),
                    "analysis_output": args.analysis_output,
                    "client_body_output": args.client_body_output,
                    "selected_03": (analysis["favorite_selection"].get("selected_for_03") or {}).get("name"),
                    "selected_03_slots": analysis["favorite_selection"].get("selected_text_slot_count"),
                    "emphasis_ratio": analysis["subtitle_strategy"].get("emphasis_ratio"),
                    "target_03_count": analysis["subtitle_strategy"].get("target_03_count"),
                    "actual_03_count": len(analysis["subtitle_strategy"].get("strong_emphasis_indices") or []),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
