from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


VIDEO_EXTS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".flv", ".m4v", ".3gp"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}
CACHE_NAME = "material-analysis-cache.json"


def read_json(path: Path) -> Any:
    if not path.is_file():
        return {}
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def media_type(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in VIDEO_EXTS:
        return "video"
    if ext in IMAGE_EXTS:
        return "image"
    return ""


def file_id(root: Path, path: Path, size: int, mtime: int) -> str:
    rel = path.relative_to(root).as_posix()
    seed = f"{rel}\n{size}\n{mtime}".encode("utf-8", errors="ignore")
    return "m_" + hashlib.sha1(seed).hexdigest()[:16]


def probe_media(path: Path, kind: str) -> dict[str, Any]:
    if kind != "video":
        return {}
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return {"warnings": ["未找到 ffprobe，已跳过视频尺寸和时长检查。"]}
    command = [
        ffprobe,
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=width,height,duration:format=duration",
        "-of",
        "json",
        str(path),
    ]
    try:
        completed = subprocess.run(command, check=True, capture_output=True, text=True, timeout=10)
        data = json.loads(completed.stdout or "{}")
    except Exception as exc:
        return {"warnings": [f"视频探测失败: {exc}"]}
    stream = (data.get("streams") or [{}])[0]
    duration_seconds = stream.get("duration") or data.get("format", {}).get("duration") or 0
    try:
        duration_ms = int(float(duration_seconds) * 1000)
    except (TypeError, ValueError):
        duration_ms = 0
    width = int(stream.get("width") or 0)
    height = int(stream.get("height") or 0)
    return {
        "duration_ms": duration_ms,
        "width": width,
        "height": height,
        "orientation": "portrait" if height >= width else "landscape" if width and height else "",
    }


def scan_materials(material_dir: Path) -> dict[str, Any]:
    cache_path = material_dir / CACHE_NAME
    existing = read_json(cache_path)
    existing_items = {
        str(item.get("signature") or ""): item
        for item in existing.get("materials", [])
        if isinstance(item, dict)
    }
    materials: list[dict[str, Any]] = []
    pending: list[dict[str, Any]] = []

    for path in sorted(material_dir.rglob("*")):
        if not path.is_file() or path.name == CACHE_NAME:
            continue
        kind = media_type(path)
        if not kind:
            continue
        stat = path.stat()
        mtime = int(stat.st_mtime)
        signature = f"{path.relative_to(material_dir).as_posix()}:{stat.st_size}:{mtime}"
        old = existing_items.get(signature)
        item = {
            "id": file_id(material_dir, path, stat.st_size, mtime),
            "name": path.name,
            "relative_path": path.relative_to(material_dir).as_posix(),
            "source_path": str(path),
            "type": kind,
            "size": stat.st_size,
            "mtime": mtime,
            "signature": signature,
            "folder_tags": [part for part in path.relative_to(material_dir).parts[:-1]],
        }
        item.update(probe_media(path, kind))
        if old and isinstance(old.get("analysis"), dict):
            item["analysis"] = old["analysis"]
        else:
            item["analysis"] = {}
            pending.append(
                {
                    "id": item["id"],
                    "name": item["name"],
                    "source_path": item["source_path"],
                    "type": item["type"],
                    "folder_tags": item["folder_tags"],
                }
            )
        materials.append(item)

    data = {
        "schema_version": 1,
        "material_dir": str(material_dir),
        "cache_file": str(cache_path),
        "materials": materials,
    }
    write_json(cache_path, data)
    return {
        "ok": True,
        "material_dir": str(material_dir),
        "cache_file": str(cache_path),
        "total": len(materials),
        "pending_count": len(pending),
        "pending_materials": pending,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Sync a local material directory into a lightweight Agent index.")
    parser.add_argument("material_dir")
    args = parser.parse_args()
    material_dir = Path(args.material_dir).expanduser().resolve()
    if not material_dir.is_dir():
        print(json.dumps({"ok": False, "error": f"素材目录不存在: {material_dir}"}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps(scan_materials(material_dir), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
