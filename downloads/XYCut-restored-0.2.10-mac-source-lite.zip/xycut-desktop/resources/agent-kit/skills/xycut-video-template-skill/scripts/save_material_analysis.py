from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


CACHE_NAME = "material-analysis-cache.json"


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def parse_analysis(value: str) -> dict[str, Any]:
    path = Path(value)
    if path.is_file():
        data = read_json(path)
    else:
        data = json.loads(value)
    if not isinstance(data, dict):
        raise ValueError("analysis 必须是 JSON object")
    summary = str(data.get("summary") or "").strip()
    keywords = data.get("keywords") if isinstance(data.get("keywords"), list) else []
    return {
        "summary": summary,
        "keywords": [str(item).strip() for item in keywords if str(item).strip()][:12],
    }


def save(material_dir: Path, material_id: str, analysis: dict[str, Any]) -> dict[str, Any]:
    cache_path = material_dir / CACHE_NAME
    cache = read_json(cache_path)
    materials = cache.get("materials") if isinstance(cache.get("materials"), list) else []
    for item in materials:
        if isinstance(item, dict) and str(item.get("id") or "") == material_id:
            item["analysis"] = analysis
            write_json(cache_path, cache)
            return {"ok": True, "material_id": material_id, "cache_file": str(cache_path)}
    return {"ok": False, "error": f"未在素材索引中找到素材: {material_id}", "cache_file": str(cache_path)}


def main() -> int:
    parser = argparse.ArgumentParser(description="Save Agent analysis for one indexed material.")
    parser.add_argument("material_dir")
    parser.add_argument("material_id")
    parser.add_argument("analysis_json_or_file")
    args = parser.parse_args()

    try:
        material_dir = Path(args.material_dir).expanduser().resolve()
        if not material_dir.is_dir():
            raise FileNotFoundError(f"素材目录不存在: {material_dir}")
        result = save(material_dir, args.material_id, parse_analysis(args.analysis_json_or_file))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("ok") else 2
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
