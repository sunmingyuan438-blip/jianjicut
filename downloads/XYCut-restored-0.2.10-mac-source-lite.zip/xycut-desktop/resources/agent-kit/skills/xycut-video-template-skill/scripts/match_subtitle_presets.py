from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def to_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def visible_chars(value: Any) -> int:
    units = 0
    has_visible = False
    for char in str(value or ""):
        if char.isspace():
            continue
        has_visible = True
        units += 1 if ord(char) < 128 else 2
    count = units // 2
    return max(1, count) if has_visible else 0


def normalize_style(value: Any) -> str:
    raw = str(value or "").strip()
    if raw in {"1", "01", "普通", "普通字幕"}:
        return "01"
    if raw in {"2", "02", "重点", "轻重点", "重点字幕"}:
        return "02"
    if raw in {"3", "03", "强重点", "关键词", "重点预设"}:
        return "03"
    return raw or "01"


def line_chars(item: dict[str, Any]) -> list[int]:
    raw = item.get("line_chars")
    if isinstance(raw, list):
        values = [to_int(value) for value in raw]
        return [value for value in values if value > 0]
    lines = item.get("lines")
    if isinstance(lines, list) and lines:
        return [visible_chars(line) for line in lines if str(line or "").strip()]
    return [visible_chars(item.get("text"))]


def score_preset(subtitle: dict[str, Any], preset: dict[str, Any], group_id: str) -> tuple[int, dict[str, Any]]:
    reasons: list[str] = []
    score = 0

    preset_groups = preset.get("favorite_group_ids") if isinstance(preset.get("favorite_group_ids"), list) else []
    if group_id and group_id not in preset_groups:
        score += 10000
        reasons.append("不在默认收藏组")

    expected_style = normalize_style(subtitle.get("style_level") or subtitle.get("style_id"))
    preset_style = normalize_style(preset.get("style_level") or preset.get("style_id"))
    if expected_style and preset_style and expected_style != preset_style:
        score += 200
        reasons.append(f"样式不一致: {preset_style}")

    chars = line_chars(subtitle)
    limits = preset.get("slot_max_chars") if isinstance(preset.get("slot_max_chars"), list) else []
    limits = [to_int(value) for value in limits if to_int(value) > 0]
    if limits:
        if len(limits) != len(chars):
            score += abs(len(limits) - len(chars)) * 80
            reasons.append("行数不一致")
        for index, char_count in enumerate(chars):
            limit = limits[min(index, len(limits) - 1)]
            overflow = max(0, char_count - limit)
            score += overflow * 50
            score += max(0, limit - char_count)
            if overflow:
                reasons.append(f"第 {index + 1} 行超 {overflow} 字")
    else:
        score += 500
        reasons.append("缺少字数索引")

    subtitle_duration = to_int(subtitle.get("duration_ms"))
    preset_duration = to_int(preset.get("duration_ms") or preset.get("suggest_duration_ms"))
    if subtitle_duration > 0 and preset_duration > 0:
        score += min(300, abs(subtitle_duration - preset_duration) // 100)

    detail = {
        "preset_id": preset.get("preset_id"),
        "name": preset.get("name"),
        "preset_path": preset.get("preset_path"),
        "score": score,
        "reasons": reasons,
    }
    return score, detail


def match_plan(plan: dict[str, Any], favorite_index: dict[str, Any], top_k: int) -> dict[str, Any]:
    group_id = str(favorite_index.get("default_group_id") or "").strip()
    presets = favorite_index.get("presets") if isinstance(favorite_index.get("presets"), list) else []
    updated = json.loads(json.dumps(plan, ensure_ascii=False))
    subtitles = updated.get("subtitles") if isinstance(updated.get("subtitles"), list) else []
    matches: list[dict[str, Any]] = []
    for subtitle in subtitles:
        if not isinstance(subtitle, dict):
            continue
        candidates = [score_preset(subtitle, preset, group_id)[1] for preset in presets if isinstance(preset, dict)]
        candidates.sort(key=lambda item: item["score"])
        selected = candidates[0] if candidates else None
        subtitle["preset_match"] = selected
        subtitle["preset_candidates"] = candidates[:top_k]
        matches.append(
            {
                "index": subtitle.get("index"),
                "text": subtitle.get("text"),
                "style_level": normalize_style(subtitle.get("style_level") or subtitle.get("style_id")),
                "selected": selected,
                "candidate_count": len(candidates),
            }
        )
    return {
        "ok": True,
        "default_group_id": group_id,
        "subtitle_count": len(matches),
        "matches": matches,
        "plan": updated,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Match video-template subtitles to favorite subtitle presets.")
    parser.add_argument("--plan", required=True)
    parser.add_argument("--favorite-index", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()

    try:
        plan = read_json(Path(args.plan))
        favorite_index = read_json(Path(args.favorite_index))
        result = match_plan(plan, favorite_index, max(1, args.top_k))
        write_json(Path(args.output), result["plan"])
        print(json.dumps({key: value for key, value in result.items() if key != "plan"}, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
