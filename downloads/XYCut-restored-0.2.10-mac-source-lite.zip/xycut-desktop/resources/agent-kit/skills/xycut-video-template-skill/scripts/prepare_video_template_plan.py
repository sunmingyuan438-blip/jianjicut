from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


SRT_TIME_RE = re.compile(
    r"(?P<start>\d{2}:\d{2}:\d{2}[,.]\d{3})\s*-->\s*(?P<end>\d{2}:\d{2}:\d{2}[,.]\d{3})"
)
VIDEO_EXTS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".flv", ".m4v", ".3gp"}
AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus"}
DEFAULT_SRT_GAP_FILL_MS = 0
DEFAULT_CUT_OPTIONS = {
    "merge_gap": 0.15,
    "snap_to_silence": True,
    "look_back": 0.14,
    "pause_threshold": 0.3,
    "manual_silence_keys": [],
    "protected_silence_keys": [],
    "pad_start": 0.08,
    "pad_end": 0,
}


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def reject_workspace_root_outputs(paths: list[Path]) -> list[str]:
    cwd = Path.cwd().resolve()
    errors: list[str] = []
    for path in paths:
        parent = path.parent.resolve()
        if parent == cwd:
            errors.append(
                f"输出文件不能写到 Agent 工作目录根部: {path}. "
                "请先创建 <agent_workdir>\\xycut-tasks\\<task_id>，并把输出写入该任务目录。"
            )
    return errors


def default_draft_name() -> str:
    return "xycut_" + datetime.now().strftime("%m%d%H%M%S")


def time_to_ms(value: str) -> int:
    hour, minute, rest = value.replace(",", ".").split(":")
    second, millis = rest.split(".")
    return (
        int(hour) * 60 * 60 * 1000
        + int(minute) * 60 * 1000
        + int(second) * 1000
        + int(millis)
    )


def parse_srt(path: Path) -> list[dict[str, Any]]:
    raw = path.read_text(encoding="utf-8-sig")
    blocks = re.split(r"\r?\n\r?\n+", raw.strip())
    items: list[dict[str, Any]] = []
    for block in blocks:
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        time_line_index = next((i for i, line in enumerate(lines) if "-->" in line), -1)
        if time_line_index < 0:
            continue
        match = SRT_TIME_RE.search(lines[time_line_index])
        if not match:
            continue
        text = "\n".join(lines[time_line_index + 1 :]).strip()
        if not text:
            continue
        start_ms = time_to_ms(match.group("start"))
        end_ms = time_to_ms(match.group("end"))
        items.append(
            {
                "index": len(items) + 1,
                "source_index": lines[0] if time_line_index > 0 else str(len(items) + 1),
                "start_ms": start_ms,
                "end_ms": end_ms,
                "duration_ms": max(0, end_ms - start_ms),
                "text": text,
                "chars": len(text.replace("\n", "")),
            }
        )
    return items


def value_to_seconds(value: Any) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 0.0
    return number / 1000.0 if abs(number) > 1000 else number


def normalize_word(raw: dict[str, Any], fallback_idx: int) -> dict[str, Any] | None:
    text = str(raw.get("word") or raw.get("text") or "").strip()
    if not text:
        return None
    start = value_to_seconds(raw.get("start", raw.get("start_time", 0)))
    end = value_to_seconds(raw.get("end", raw.get("end_time", start)))
    if end < start:
        return None
    idx_raw = raw.get("idx", raw.get("index", fallback_idx))
    try:
        idx = int(idx_raw)
    except (TypeError, ValueError):
        idx = fallback_idx
    return {
        "idx": idx,
        "word": text,
        "text": str(raw.get("text") or text),
        "start": round(max(0.0, start), 3),
        "end": round(max(0.0, end), 3),
    }


def load_segments_json(path: Path | None) -> list[dict[str, Any]]:
    if not path:
        return []
    data = read_json(path)
    raw_segments = data.get("segments") if isinstance(data, dict) and isinstance(data.get("segments"), list) else []
    output: list[dict[str, Any]] = []
    fallback_idx = 0
    for index, raw in enumerate(raw_segments, start=1):
        if not isinstance(raw, dict):
            continue
        words = []
        for raw_word in raw.get("words") or []:
            if not isinstance(raw_word, dict):
                continue
            word = normalize_word(raw_word, fallback_idx)
            if not word:
                continue
            words.append(word)
            fallback_idx = max(fallback_idx, int(word["idx"]) + 1)
        start = value_to_seconds(raw.get("start", raw.get("start_time", words[0]["start"] if words else 0)))
        end = value_to_seconds(raw.get("end", raw.get("end_time", words[-1]["end"] if words else start)))
        if words:
            start = min(start, words[0]["start"])
            end = max(end, words[-1]["end"])
        output.append(
            {
                "index": int(raw.get("index") or index),
                "text": str(raw.get("text") or "").strip(),
                "start_ms": int(round(max(0.0, start) * 1000)),
                "end_ms": int(round(max(start, end) * 1000)),
                "words": words,
                "word_indices": [int(word["idx"]) for word in words],
            }
        )
    return output


def attach_segment_words(items: list[dict[str, Any]], segments: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not segments:
        return items
    output: list[dict[str, Any]] = []
    for index, item in enumerate(items):
        next_item = dict(item)
        segment = segments[index] if index < len(segments) else None
        if segment and segment.get("words"):
            words = [dict(word) for word in segment.get("words") or [] if isinstance(word, dict)]
            next_item["words"] = words
            next_item["word_indices"] = [int(word["idx"]) for word in words if word.get("idx") is not None]
            if next_item["word_indices"]:
                next_item["source_word_start_idx"] = min(next_item["word_indices"])
                next_item["source_word_end_idx"] = max(next_item["word_indices"])
        output.append(next_item)
    return output


def normalize_subtitle_timeline(items: list[dict[str, Any]], fill_gap_ms: int = DEFAULT_SRT_GAP_FILL_MS) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not items:
        return items, {"enabled": False, "shift_ms": 0, "filled_gap_count": 0, "filled_gap_ms": 0}

    normalized = [dict(item) for item in items]
    for item in normalized:
        item["duration_ms"] = max(0, int(item.get("end_ms") or 0) - int(item.get("start_ms") or 0))

    return normalized, {
        "enabled": False,
        "reason": "preserve_srt_timing; material gaps are filled in material_plan only",
        "shift_ms": 0,
        "fill_gap_threshold_ms": fill_gap_ms,
        "fill_gap_mode": "disabled",
        "filled_gap_count": 0,
        "filled_gap_ms": 0,
    }


def build_line_timeline(items: list[dict[str, Any]]) -> dict[str, Any]:
    lines: list[dict[str, Any]] = []
    for index, item in enumerate(items, start=1):
        line_id = str(item.get("line_id") or f"line_{index:03d}")
        start_ms = int(item.get("start_ms") or 0)
        end_ms = int(item.get("end_ms") or start_ms)
        words = [dict(word) for word in item.get("words") or [] if isinstance(word, dict)]
        word_indices = [int(word["idx"]) for word in words if word.get("idx") is not None]
        lines.append(
            {
                "index": index,
                "line_id": line_id,
                "text": str(item.get("text") or ""),
                "start": round(start_ms / 1000.0, 3),
                "end": round(end_ms / 1000.0, 3),
                "target_start": round(start_ms / 1000.0, 3),
                "target_end": round(end_ms / 1000.0, 3),
                "source_start": round(start_ms / 1000.0, 3),
                "source_end": round(end_ms / 1000.0, 3),
                "text_source_start": round(start_ms / 1000.0, 3),
                "text_source_end": round(end_ms / 1000.0, 3),
                "start_ms": start_ms,
                "end_ms": end_ms,
                "duration_ms": max(0, end_ms - start_ms),
                "duration": round(max(0, end_ms - start_ms) / 1000.0, 3),
                "talking_segments": [
                    {
                        "source_start": round(start_ms / 1000.0, 3),
                        "source_end": round(end_ms / 1000.0, 3),
                        "source_duration": round(max(0, end_ms - start_ms) / 1000.0, 3),
                        "target_start": round(start_ms / 1000.0, 3),
                        "target_end": round(end_ms / 1000.0, 3),
                        "duration": round(max(0, end_ms - start_ms) / 1000.0, 3),
                        "speed": 1.0,
                    }
                ],
                "words": words,
                "word_indices": word_indices,
                "source_index": item.get("source_index"),
            }
        )
    return {
        "schema_version": 1,
        "source": "normalized_srt_parent_lines",
        "gap_fill_mode": "preserve_source_timing",
        "lines": lines,
    }


def media_duration_ms(video_info: dict[str, Any], audio_info: dict[str, Any], subtitles: list[dict[str, Any]]) -> int:
    for info in (video_info, audio_info):
        try:
            value = int(info.get("duration_ms") or 0)
        except (TypeError, ValueError):
            value = 0
        if value > 0:
            return value
    return max((int(item.get("end_ms") or 0) for item in subtitles), default=0)


def build_default_cut_plan(source_path: Path, duration_ms: int) -> dict[str, Any]:
    duration_seconds = max(0, duration_ms) / 1000.0
    return {
        "schema_version": 1,
        "source": "prepare_video_template_plan:no_cut",
        "source_path": str(source_path),
        "cut_options": DEFAULT_CUT_OPTIONS,
        "delete_ranges": [],
        "keep_ranges": [
            {
                "source_start": 0.0,
                "source_end": round(duration_seconds, 3),
                "duration": round(duration_seconds, 3),
            }
        ] if duration_seconds > 0 else [],
        "manual_time_ranges": [],
        "protected_ranges": [],
        "total_keep_duration": round(duration_seconds, 3),
    }


def build_default_review_state(line_timeline: dict[str, Any]) -> dict[str, Any]:
    review_lines = []
    for line in line_timeline.get("lines", []) if isinstance(line_timeline.get("lines"), list) else []:
        if not isinstance(line, dict):
            continue
        words = [dict(word) for word in line.get("words") or [] if isinstance(word, dict)]
        word_indices = [int(word["idx"]) for word in words if word.get("idx") is not None]
        review_lines.append(
            {
                "line_id": line.get("line_id"),
                "index": line.get("index"),
                "text": line.get("text"),
                "text_authority": "words" if words else "literal",
                "start": line.get("start"),
                "end": line.get("end"),
                "words": words,
                "word_indices": word_indices,
            }
        )
    return {
        "schema_version": 1,
        "source": "prepare_video_template_plan:no_cut",
        "deleted_line_ids": [],
        "deleted_word_indices": [],
        "ai_selected_word_indices": [],
        "manual_time_ranges": [],
        "protected_ranges": [],
        "word_text_overrides": {},
        "cut_options": DEFAULT_CUT_OPTIONS,
        "review_lines_user_edited": True,
        "review_lines": review_lines,
    }


def write_default_edit_state(output: Path, source_path: Path, duration_ms: int, line_timeline: dict[str, Any]) -> dict[str, str]:
    task_dir = output.parent.parent
    edit_dir = task_dir / "edit"
    cut_plan = build_default_cut_plan(source_path, duration_ms)
    review_state = build_default_review_state(line_timeline)
    write_json(edit_dir / "cut_plan.json", cut_plan)
    write_json(edit_dir / "line_timeline.json", line_timeline)
    write_json(edit_dir / "review_state.json", review_state)
    return {
        "cut_plan_file": str(edit_dir / "cut_plan.json"),
        "line_timeline_file": str(edit_dir / "line_timeline.json"),
        "review_state_file": str(edit_dir / "review_state.json"),
    }


def probe_video(path: Path) -> dict[str, Any]:
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return {"warnings": ["未找到 ffprobe，已跳过视频尺寸和时长检查。"]}
    command = [
        ffprobe,
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=width,height,duration:format=duration",
        "-of",
        "json",
        str(path),
    ]
    try:
        completed = subprocess.run(command, check=True, capture_output=True, text=True, timeout=10)
        data = json.loads(completed.stdout or "{}")
    except Exception as exc:
        return {"warnings": [f"视频探测失败，已跳过尺寸和时长检查: {exc}"]}
    stream = (data.get("streams") or [{}])[0]
    duration_seconds = stream.get("duration") or data.get("format", {}).get("duration") or 0
    try:
        duration_ms = int(float(duration_seconds) * 1000)
    except (TypeError, ValueError):
        duration_ms = 0
    width = int(stream.get("width") or 0)
    height = int(stream.get("height") or 0)
    return {
        "duration_ms": duration_ms,
        "width": width,
        "height": height,
        "orientation": "portrait" if height >= width else "landscape" if width and height else "",
        "warnings": [],
    }


def probe_audio(path: Path) -> dict[str, Any]:
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return {"duration_ms": 0, "warnings": ["未找到 ffprobe，已跳过音频时长检查。"]}
    command = [
        ffprobe,
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "json",
        str(path),
    ]
    try:
        completed = subprocess.run(command, check=True, capture_output=True, text=True, timeout=10)
        data = json.loads(completed.stdout or "{}")
    except Exception as exc:
        return {"duration_ms": 0, "warnings": [f"音频探测失败，已跳过时长检查: {exc}"]}
    duration_seconds = data.get("format", {}).get("duration") or 0
    try:
        duration_ms = int(float(duration_seconds) * 1000)
    except (TypeError, ValueError):
        duration_ms = 0
    return {"duration_ms": duration_ms, "warnings": []}


def build_initial_plan(
    template_dir: Path,
    template_config_file: Path,
    draft_output_dir: Path,
    mp4_file: Path | None,
    audio_file: Path | None,
    srt_file: Path,
    segments_json_file: Path | None,
    draft_name: str,
) -> dict[str, Any]:
    config = read_json(template_config_file)
    raw_subtitles = parse_srt(srt_file)
    subtitles, subtitle_normalization = normalize_subtitle_timeline(raw_subtitles)
    segments = load_segments_json(segments_json_file)
    subtitles = attach_segment_words(subtitles, segments)
    line_timeline = build_line_timeline(subtitles)
    video_info = probe_video(mp4_file) if mp4_file else {}
    audio_info = probe_audio(audio_file) if audio_file else {}
    duration_ms = media_duration_ms(video_info, audio_info, subtitles)
    slug = config.get("slug") or config.get("template_slug") or template_dir.name
    name = draft_name.strip() or default_draft_name()

    plan = {
        "schema_version": 1,
        "mode": "video_template",
        "input_mode": "video" if mp4_file else "audio",
        "draft_name": name,
        "template_slug": slug,
        "template_dir": str(template_dir),
        "template_config_file": str(template_config_file),
        "draft_output_dir": str(draft_output_dir),
        "source_srt": {
            "file_path": str(srt_file),
            "subtitle_count": len(subtitles),
            "raw_subtitle_count": len(raw_subtitles),
            "timeline_normalization": subtitle_normalization,
            "segments_json_file": str(segments_json_file) if segments_json_file else "",
            "word_timing_available": any(item.get("words") for item in subtitles),
        },
        "line_timeline": line_timeline,
        "timeline_duration_ms": duration_ms,
        "subtitles": [
            {
                **item,
                "line_id": item.get("line_id") or f"line_{int(item.get('index') or 0):03d}",
                "style_level": "",
                "lines": [],
                "line_chars": [],
                "word_indices": item.get("word_indices", []),
                "source_word_start_idx": item.get("source_word_start_idx"),
                "source_word_end_idx": item.get("source_word_end_idx"),
                "preset_match": None,
                "agent_note": "请由 Agent 判断 01/02/03；01/02 可写 highlight_terms；模板支持副字幕时可写 secondary_text；过长 01/02 要按语义拆成多条字幕；03 要做语义分段并写 agent_locked_lines=true；脚本只校验和匹配预设，不能替 Agent 硬切文字。",
            }
            for item in subtitles
        ],
        "title": {
            "text": "",
            "preset_match": None,
        },
        "material_plan": {
            "mode": "source_video_only" if mp4_file else "audio_only",
            "items": [],
        },
    }
    if mp4_file:
        plan["source_video"] = {
            "file_path": str(mp4_file),
            **video_info,
        }
    if audio_file:
        plan["source_audio"] = {
            "file_path": str(audio_file),
            **audio_info,
        }
    return plan


def validate_inputs(
    template_dir: Path,
    template_config_file: Path,
    draft_output_dir: Path,
    mp4_file: Path | None,
    audio_file: Path | None,
    srt_file: Path,
    segments_json_file: Path | None,
) -> list[str]:
    errors: list[str] = []
    if not template_dir.is_dir():
        errors.append(f"模板目录不存在: {template_dir}")
    if not template_config_file.is_file():
        errors.append(f"模板参数文件不存在: {template_config_file}")
    if not draft_output_dir.exists():
        errors.append(f"剪映草稿输出目录不存在: {draft_output_dir}")
    if not mp4_file and not audio_file:
        errors.append("必须提供口播视频 --mp4-file 或口播音频 --audio-file。")
    if mp4_file:
        if not mp4_file.is_file():
            errors.append(f"口播视频不存在: {mp4_file}")
        elif mp4_file.suffix.lower() not in VIDEO_EXTS:
            errors.append(f"口播视频格式不支持: {mp4_file.suffix}")
    if audio_file:
        if not audio_file.is_file():
            errors.append(f"口播音频不存在: {audio_file}")
        elif audio_file.suffix.lower() not in AUDIO_EXTS:
            errors.append(f"口播音频格式不支持: {audio_file.suffix}")
    if not srt_file.is_file():
        errors.append(f"SRT 字幕不存在: {srt_file}")
    if segments_json_file and not segments_json_file.is_file():
        errors.append(f"ASR 分段文件不存在: {segments_json_file}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Prepare a Xiaoying video-template generation plan.")
    parser.add_argument("--template-dir", required=True)
    parser.add_argument("--template-config-file", required=True)
    parser.add_argument("--draft-output-dir", required=True)
    parser.add_argument("--mp4-file", default="")
    parser.add_argument("--audio-file", default="")
    parser.add_argument("--srt-file", required=True)
    parser.add_argument("--segments-json", default="", help="Optional speech/segments.json with ASR word timestamps.")
    parser.add_argument("--draft-name", default="")
    parser.add_argument("--output", required=True, help="Path to write video_template_plan.json.")
    args = parser.parse_args()

    template_dir = Path(args.template_dir)
    template_config_file = Path(args.template_config_file)
    draft_output_dir = Path(args.draft_output_dir)
    mp4_file = Path(args.mp4_file) if str(args.mp4_file or "").strip() else None
    audio_file = Path(args.audio_file) if str(args.audio_file or "").strip() else None
    srt_file = Path(args.srt_file)
    segments_json_file = Path(args.segments_json) if str(args.segments_json or "").strip() else None
    output = Path(args.output)

    errors = reject_workspace_root_outputs([output])
    errors.extend(validate_inputs(template_dir, template_config_file, draft_output_dir, mp4_file, audio_file, srt_file, segments_json_file))
    if errors:
        print(json.dumps({"ok": False, "errors": errors}, ensure_ascii=False, indent=2))
        return 2

    plan = build_initial_plan(
        template_dir,
        template_config_file,
        draft_output_dir,
        mp4_file,
        audio_file,
        srt_file,
        segments_json_file,
        args.draft_name,
    )
    source_path = mp4_file or audio_file
    edit_files = write_default_edit_state(output, source_path, int(plan.get("timeline_duration_ms") or 0), plan["line_timeline"]) if source_path else {}
    if edit_files:
        plan["edit_files"] = edit_files
    write_json(output, plan)
    result = {
        "ok": True,
        "message": "视频模板初始计划已生成。请由 Agent 补充 style_level、过长 01/02 语义拆细、03 分类和拆行后，再由脚本匹配 03 预设。",
        "plan_file": str(output),
        **edit_files,
        "subtitle_count": len(plan["subtitles"]),
        "next_step": "Agent 补齐标题、01/02/03 分层、过长 01/02 语义拆细、03 category_id 和 lines 后，运行 analyze_video_template_plan.py 生成 video_template_analysis.json。",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
