from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import venv
from pathlib import Path
from typing import Any, Optional


def skill_root() -> Path:
    return Path(__file__).resolve().parents[1]


def runtime_root() -> Path:
    configured = os.environ.get("XYCUT_VIDEO_TEMPLATE_RUNTIME_DIR", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    common_root = os.environ.get("XYCUT_AGENT_RUNTIME_DIR", "").strip()
    if common_root:
        return Path(common_root).expanduser().resolve()
    return (Path.cwd() / ".xycut-agent-runtime").resolve()


def python_bin(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def client_runtime_python() -> Optional[Path]:
    explicit_python = os.environ.get("XYCUT_CLIENT_PYTHON", "").strip()
    if explicit_python:
        path = Path(explicit_python).expanduser()
        if path.is_file():
            return path.resolve()

    runtime_dir = os.environ.get("XYCUT_PYTHON_RUNTIME_DIR", "").strip()
    candidates: list[Path] = []
    if runtime_dir:
        candidates.append(Path(runtime_dir).expanduser())
    if os.name == "nt":
        local_app_data = os.environ.get("LOCALAPPDATA", "").strip()
        if local_app_data:
            candidates.append(Path(local_app_data) / "com.xiaoyuan.jianji" / "runtime" / "python39")

    for root in candidates:
        python = root / ("python.exe" if os.name == "nt" else "bin/python3")
        if python.is_file():
            return python.resolve()
    return None


def run(cmd: list[str]) -> dict[str, Any]:
    completed = subprocess.run(cmd, text=True, capture_output=True)
    return {
        "cmd": cmd,
        "returncode": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def setup(install: bool) -> dict[str, Any]:
    root = skill_root()
    runtime = runtime_root()
    venv_dir = runtime / ".venv"
    requirements = root / "requirements.txt"

    created = False
    setup_error = ""
    fallback_python = client_runtime_python()
    if not python_bin(venv_dir).is_file():
        try:
            runtime.mkdir(parents=True, exist_ok=True)
            venv.EnvBuilder(with_pip=True, clear=False, symlinks=False).create(venv_dir)
            created = True
        except Exception as exc:
            setup_error = str(exc)

    venv_python = python_bin(venv_dir)
    using_fallback = not venv_python.is_file()
    py = fallback_python if using_fallback and fallback_python else venv_python
    result: dict[str, Any] = {
        "ok": py.is_file(),
        "skill_root": str(root),
        "runtime_root": str(runtime),
        "venv": str(venv_dir),
        "venv_python": str(venv_python),
        "fallback_python": str(fallback_python) if fallback_python else None,
        "python": str(py),
        "mode": "client_runtime" if using_fallback and fallback_python else "venv",
        "created": created,
        "requirements": str(requirements),
        "install": install,
        "install_skipped": bool(using_fallback),
        "setup_error": setup_error,
        "commands": [],
    }
    if not result["ok"]:
        result["message"] = "未找到可用 Python。请先在小圆 XYCut 设置中安装 AI 运行环境。"
        return result

    version_result = run([str(py), "--version"])
    result["commands"].append(version_result)
    if version_result["returncode"] != 0:
        result["ok"] = False
        return result

    if install and requirements.is_file() and not using_fallback:
        install_result = run([str(py), "-m", "pip", "install", "-r", str(requirements)])
        result["commands"].append(install_result)
        if install_result["returncode"] != 0:
            result["ok"] = False

    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Prepare Xiaoying video template Agent runtime.")
    parser.add_argument("--install", action="store_true", help="Install requirements into the local virtual environment.")
    args = parser.parse_args()
    result = setup(args.install)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
