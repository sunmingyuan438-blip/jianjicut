# 脚本使用

## 环境检查

先用 Agent 当前可用的 Python 运行环境检查；如果能创建 venv，脚本会使用 `<agent_workdir>\.xycut-agent-runtime\.venv`，如果创建失败，会自动回退到小圆 XYCut 客户端已安装的 `runtime\python39\python.exe`：

```powershell
python <installed_skill_dir>\scripts\check_runtime.py
```

然后创建或复用 Skill 运行环境：

```powershell
python <installed_skill_dir>\scripts\setup_runtime.py --install
```

读取 `setup_runtime.py` 输出 JSON 中的 `python` 字段，作为后续命令里的 `<venv_python>`。这个字段可能是 venv Python，也可能是客户端 runtime Python；不要手写固定路径。

Windows 默认 venv 路径：

```text
<agent_workdir>\.xycut-agent-runtime\.venv\Scripts\python.exe
```

Windows 客户端 runtime 兜底路径：

```text
%LOCALAPPDATA%\com.xiaoyuan.jianji\runtime\python39\python.exe
```

如果 `setup_runtime.py` 返回 `ok: false`，提示用户先到小圆 XYCut ：`设置 -> 启动 AI 剪辑 -> 安装运行环境`。

## 初始计划

```powershell
<venv_python> <installed_skill_dir>\scripts\prepare_video_template_plan.py --template-dir "<template_dir>" --template-config-file "<template_config_file>" --draft-output-dir "<draft_output_dir>" --mp4-file "<mp4_file>" --srt-file "<srt_file>" --output "<task_dir>\output\video_template_plan.json"
```

如果 SRT 来自本轮 MP4 ASR，必须额外传入 ASR 分段文件，解锁逐字能力：

```powershell
<venv_python> <installed_skill_dir>\scripts\prepare_video_template_plan.py --template-dir "<template_dir>" --template-config-file "<template_config_file>" --draft-output-dir "<draft_output_dir>" --mp4-file "<mp4_file>" --srt-file "<task_dir>\output\voice.srt" --segments-json "<task_dir>\speech\segments.json" --output "<task_dir>\output\video_template_plan.json"
```

如果输入是 MP3 + SRT，使用 `--audio-file`，不要伪造 `--mp4-file`。如果 SRT 来自本轮 ASR/TTS 对齐，必须同时传 `--segments-json`；如果是用户直接提供的 SRT，不传 `--segments-json`，默认只有行级能力：

```powershell
<venv_python> <installed_skill_dir>\scripts\prepare_video_template_plan.py --template-dir "<template_dir>" --template-config-file "<template_config_file>" --draft-output-dir "<draft_output_dir>" --audio-file "<mp3_file>" --srt-file "<srt_file>" --segments-json "<task_dir>\speech\segments.json" --output "<task_dir>\output\video_template_plan.json"
```

该脚本除了写入 `output\video_template_plan.json`，还会写入默认不剪版 Tab1 定稿层：

```text
<task_dir>\edit\review_state.json
<task_dir>\edit\cut_plan.json
<task_dir>\edit\line_timeline.json
```

默认不剪版表示 `delete_ranges=[]`，主音频/主视频保持原始长度；SRT 字幕时间不平移、不填缝。素材间隙由后续 `material_plan` 补齐。只要传入 `--segments-json`，`line_timeline.json` 和 `review_state.json` 会带上 words，工作台默认具备逐字删除能力；未传入时按用户 SRT 生成行级时间线。

## 文案生成配音和字幕

当用户只给文案时，先把文案保存为：

```text
<task_dir>\input\script.txt
```

然后调用豆包 TTS 2.0 生成 MP3 和 TTS 时间戳：

```powershell
<venv_python> <installed_skill_dir>\scripts\generate_doubao_tts.py --agent-context-file "<agent_context_file>" --text-file "<task_dir>\input\script.txt" --output-audio "<task_dir>\input\source.mp3" --output-timestamps "<task_dir>\speech\tts.raw.json"
```

如果用户明确指定音色：

```powershell
<venv_python> <installed_skill_dir>\scripts\generate_doubao_tts.py --agent-context-file "<agent_context_file>" --text-file "<task_dir>\input\script.txt" --output-audio "<task_dir>\input\source.mp3" --output-timestamps "<task_dir>\speech\tts.raw.json" --voice-id "<voice_id>"
```

生成 MP3 后，再调用 ASR 生成按原文分行对齐的 SRT：

```powershell
<venv_python> <installed_skill_dir>\scripts\transcribe_volcengine_asr.py --agent-context-file "<agent_context_file>" --input-media "<task_dir>\input\source.mp3" --source-text-file "<task_dir>\input\script.txt" --output-json "<task_dir>\speech\asr.raw.json" --output-srt "<task_dir>\output\voice.srt" --output-segments-json "<task_dir>\speech\segments.json"
```

后续把 `<task_dir>\input\source.mp3`、`<task_dir>\output\voice.srt` 和 `<task_dir>\speech\segments.json` 当作 ASR/TTS 对齐后的 MP3 + SRT 输入继续处理。文案 TTS 不能只用文案估算时间，必须以生成音频的 ASR/对齐结果为时间戳来源；但字幕分句和显示文本以 `<task_dir>\input\script.txt` 为权威，ASR 只提供 words 时间。脚本会在未显式传 `--source-text-file` 但发现同任务目录存在 `input\script.txt` 时自动启用原文约束，避免 Agent 漏传参数导致后段串句。

## 音视频转字幕

当用户只给 MP3 或 MP4，没有 SRT 时，调用 ASR 生成字幕：

```powershell
<venv_python> <installed_skill_dir>\scripts\transcribe_volcengine_asr.py --agent-context-file "<agent_context_file>" --input-media "<input_media>" --output-json "<task_dir>\speech\asr.raw.json" --output-srt "<task_dir>\output\voice.srt" --output-segments-json "<task_dir>\speech\segments.json"
```

如果输入是 MP4，脚本会读取 `agent_context_file.tools.ffmpeg_path`，先提取临时音频再转写。

如果已经有 TTS 或 ASR 的词级时间戳 JSON，也可以单独生成 SRT：

```powershell
<venv_python> <installed_skill_dir>\scripts\build_srt_from_timestamps.py --timestamps-json "<timestamps_json>" --source-text-file "<task_dir>\input\script.txt" --output-srt "<task_dir>\output\voice.srt" --output-json "<task_dir>\speech\segments.json"
```

## 打开统一工作台

统一工作台固定包含 `口播剪辑 / 素材匹配 / 生成草稿` 三页。前期哪个页面有对应数据就展示，缺少数据时显示空状态或不展示该模块。

需要用户查看、修改、预览或确认时，统一工作台是唯一面向用户的入口。不要让用户打开 `<task_dir>` 下的 JSON、Markdown、SRT 或素材候选文件；这些文件只是 Agent、脚本和客户端之间的中间数据。

如果本轮是只给 MP4，或用户明确要求重新剪口播/删气口，生成 `<task_dir>\speech\segments.json` 后，优先调用客户端打开接口：

```powershell
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:17651/ai-editing/workbench/open" -ContentType "application/json; charset=utf-8" -Body '{"task_dir":"<task_dir>"}'
```

返回的 `url` 用于打开 Agent 内置浏览器。缺少打开接口时，再直接拼接：

```text
http://127.0.0.1:17651/xycut/<task_id>
```

地址优先读取 `agent_context_file.local_api.editing_workbench_open_url`；缺失时从 `agent_context_file.local_api.base_url` 拼接 `/ai-editing/workbench/open`。

需要口播剪辑时，工作台保存后会写入：

```text
<task_dir>\edit\review_state.json
<task_dir>\edit\cut_plan.json
<task_dir>\edit\line_timeline.json
```

后续素材匹配和生成草稿优先使用 `line_timeline.json`。

如果本轮不需要口播剪辑，仍然使用 prepare 脚本生成的默认不剪版 `edit` 文件；可以打开同一个工作台展示素材匹配和生成草稿页面，但不要等待用户保存口播剪辑结果。

打开成功后的回复保持简短：

```text
我已经打开剪辑工作台，请在工作台里检查口播剪辑、素材匹配和生成草稿页。
```

不要把 `edit\line_timeline.json`、`output\video_template_plan.json`、`output\video_template_analysis.json` 或其他中间文件路径作为用户操作入口。

## 生成主分析文件

## 本地素材批量匹配

生成初始计划并补齐标题、字幕分层后，优先用批量脚本写入 `material_plan`，不要让 Agent 手工循环导出每句候选。

快速匹配：

```powershell
<venv_python> <installed_skill_dir>\scripts\build_material_plan.py --plan "<task_dir>\output\video_template_plan.json" --agent-context-file "<agent_context_file>" --db "<db_path>" --library-id "<library_id>" --scope "partial_broll" --match-ratio 0.35 --source-mode "local_only" --match-mode "fast" --summary-output "<task_dir>\materials\material_match_summary.json"
```

精细匹配：

```powershell
<venv_python> <installed_skill_dir>\scripts\build_material_plan.py --plan "<task_dir>\output\video_template_plan.json" --agent-context-file "<agent_context_file>" --db "<db_path>" --library-id "<library_id>" --scope "partial_broll" --match-ratio 0.35 --source-mode "local_only" --match-mode "refined" --summary-output "<task_dir>\materials\material_match_summary.json"
```

传入 `--agent-context-file` 后，脚本会自动决定向量来源：用户填了豆包大模型 Key 就用用户 Key；否则调用小圆 XYCut 客户端本地接口。向量缓存默认写到：

```text
<task_dir>\materials\query_embeddings.json
```

脚本会把完整候选保存到：

```text
<task_dir>\materials\candidates\<line_id>.json
```

同时把最终选择写回 `video_template_plan.json` 的：

```text
material_strategy
material_plan
```

`fast` 模式下，Agent 只看脚本终端摘要即可。`refined` 模式下，Agent 只读取 `material_match_summary.json` 的 Top 5 轻量候选，不读取完整候选全集。

Agent 补齐 `video_template_plan.json` 后运行：

```powershell
<venv_python> <installed_skill_dir>\scripts\analyze_video_template_plan.py --plan "<task_dir>\output\video_template_plan.json" --template-config-file "<template_config_file>" --favorite-index "%LOCALAPPDATA%\com.xiaoyuan.jianji\subtitle-presets\subtitle-preset-index.json" --analysis-output "<task_dir>\output\video_template_analysis.json" --summary-output "<task_dir>\output\README_summary.md" --emphasis-ratio 30
```

生成主分析文件时会保留 `video_template_plan.json` 中已有的 `material_plan`，并放入 `video_template_analysis.json` 的 `generation_plan.material_plan`。

## 网络素材补充

当 `material_strategy.source_mode` 或 `material_plan.source_mode` 为 `local_plus_network`，且本地素材库候选不足、分数过低或用户明确要求网络补充时，先只为缺素材的字幕生成 query，然后运行：

```powershell
<venv_python> <installed_skill_dir>\scripts\download_network_materials.py --plan "<task_dir>\output\video_template_plan.json" --agent-context-file "<agent_context_file>" --line-query-file "<task_dir>\network_queries.json" --output "<task_dir>\output\video_template_plan.json"
```

如果本地素材匹配已经写入了 `video_template_analysis.json`，也可以直接传分析文件：

```powershell
<venv_python> <installed_skill_dir>\scripts\download_network_materials.py --plan "<task_dir>\output\video_template_analysis.json" --agent-context-file "<agent_context_file>" --line-query-file "<task_dir>\network_queries.json" --output "<task_dir>\output\video_template_analysis.json"
```

默认复用旧项目里的 Pexels 下载器：

```text
D:\DOC\APP\shipin-zhushou-4.0\app\utils\pexels_downloader.py
```

如果旧项目根目录不同，传入：

```powershell
--legacy-app-root "D:\DOC\APP\shipin-zhushou-4.0\app"
```

Pexels API Key 的读取顺序：

1. `--pexels-api-key`
2. `agent_context_file.pexels.api_key` 或 `agent_context_file.pexels_api_key`
3. 环境变量 `PEXELS_API_KEY`
4. `agent_context_file.third_party_apis` 中名称包含 `pexels` 的配置；客户端发送给 Agent 的基础上下文默认使用这一项。

下载文件保存到当前任务目录：

```text
<task_dir>\materials\network\<line_id>\*.mp4
```

脚本会把选中的网络素材追加到同一个 `material_plan.items`，并写入：

```json
{
  "source": "network",
  "provider": "pexels",
  "file_path": "<task_dir>\\materials\\network\\line_001\\line_001_pexels_xxx.mp4"
}
```

后续 `analyze_video_template_plan.py` 和客户端生成逻辑继续只消费 `material_plan.items`，不用区分素材来自本地库还是网络。传入分析文件时，脚本会同步更新 `generation_plan.material_plan`，确保客户端生成草稿时能读到新增的网络素材。

## GPT 图片素材补充

当 `material_strategy.source_mode` 或 `material_plan.source_mode` 为 `local_plus_gpt_image`，按 `material-ai-generated.md` 生成图片并保存到任务目录：

```text
<task_dir>\materials\ai\<line_id>\image_001.png
```

生成后把图片路径追加到同一个 `material_plan.items`。当前不需要专门脚本；Agent 使用 GPT 自带图片生成能力完成图片文件，再写入计划。

```json
{
  "source": "ai_generated",
  "provider": "gpt_image",
  "asset_type": "image",
  "file_path": "<task_dir>\\materials\\ai\\line_001\\image_001.png"
}
```

客户端生成逻辑支持把图片后缀或 `asset_type=image` 的素材作为 B-roll 图片片段插入时间线。

## 火山 AI 生成素材

当 `material_strategy.source_mode` 或 `material_plan.source_mode` 为 `local_plus_volcengine_ai`，先阅读 `material-volcengine-ai.md`。

当前只保留流程框架。未提供即梦图片、SeeDance 视频的官方文档和示例代码前，不要自行编造 API 调用。

后续脚本建议命名：

```text
scripts\generate_volcengine_materials.py
```

脚本职责只做三件事：

1. 读取 `agent_context_file.third_party_apis` 中的火山配置。
2. 生成图片或视频文件到 `<task_dir>\materials\ai\<line_id>\`。
3. 更新同一个 `material_plan.items`。

## 校验

```powershell
<venv_python> <installed_skill_dir>\scripts\validate_video_template_plan.py --plan "<task_dir>\output\video_template_analysis.json" --output "<task_dir>\output\video_template_validation.json" --require-03-compound
```

校验文件只用于调试，不是新的主文件。

如果校验失败，必须先修正 `output\video_template_analysis.json` 或回到 `output\video_template_plan.json` 重新生成分析文件，不能继续打开预览或生成草稿。尤其是目标需要 `03` 但实际 `03` 为 0 条时，说明 Agent 把强重点误写成了 `02`，要先修正字幕分层。
