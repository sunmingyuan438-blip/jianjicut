# 火山 AI 生成素材框架

只有用户选择“本地素材库不够时，用火山 AI 生成素材补充”或明确指定即梦、SeeDance、火山 AI 图片/视频时才进入本流程。

## 当前状态

本文件只定义流程框架。未提供官方 API 文档和示例代码前，不要自行编造请求参数、接口地址或鉴权方式。

## 支持方向

- 即梦图片：`provider = volcengine_jimeng_image`，`asset_type = image`
- 即梦视频或 SeeDance 视频：`provider = volcengine_seedance_video`，`asset_type = video`

## 执行规则

1. 先确认用户要生成图片还是视频；如果用户已明确说明，直接使用。
2. 如果没有说明比例，优先用模板方向：竖屏 `9:16`，横屏 `16:9`；模板方向不明确时先询问用户。
3. 从 `agent_context_file.third_party_apis` 中读取火山相关配置；不要在回复中暴露密钥。
4. 如果缺少 API 配置、官方文档或项目内脚本，停下来说明需要用户补充，不要伪造素材。
5. 生成结果保存到当前任务目录，不保存进素材库 DB。
6. 写入同一个 `material_plan.items`，让客户端生成草稿时统一处理。

## 保存位置

图片：

```text
<task_dir>\materials\ai\<line_id>\image_001.png
```

视频：

```text
<task_dir>\materials\ai\<line_id>\video_001.mp4
```

## 计划字段

图片：

```json
{
  "line_id": "line_001",
  "query": "潮汕古城夜景旅行画面",
  "file_path": "<task_dir>\\materials\\ai\\line_001\\image_001.png",
  "source": "ai_generated",
  "provider": "volcengine_jimeng_image",
  "asset_type": "image",
  "start": 0,
  "end": 3.2
}
```

视频：

```json
{
  "line_id": "line_001",
  "query": "潮汕古城夜景旅行镜头",
  "file_path": "<task_dir>\\materials\\ai\\line_001\\video_001.mp4",
  "source": "ai_generated",
  "provider": "volcengine_seedance_video",
  "asset_type": "video",
  "start": 0,
  "end": 3.2
}
```

## 后续接代码

等用户提供豆包 2.0 TTS、即梦图片、SeeDance 视频的官方文档和示例代码后，再新增对应脚本。脚本只负责生成文件并更新 `material_plan.items`，最终剪映草稿仍由客户端生成器处理。
