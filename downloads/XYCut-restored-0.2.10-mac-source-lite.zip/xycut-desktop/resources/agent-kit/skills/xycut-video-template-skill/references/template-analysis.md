# 模板分析

模板结构只来自 `template_config_file`。

## 必须检查

- `template_config_file` 是否存在。
- `template_type` 是否为 `video_template`。
- 模板目录是否已由 `agent-context.json` 的模板根目录或本地模板索引定位；不要要求 `template_config_file` 或 `assembly_config_file` 内写入用户机器的实际路径。
- `title_slots` 是否存在。
- `subtitle_style_groups` 是否存在。

## 文件分工

- `*.template.json`：Agent 读取，用于理解模板名称、标题槽、字幕样式组、建议字数。
- `*.assembly.json`：客户端和 Python core 使用，包含底层组装索引。Agent 默认不要读取。

`assembly_config_file` 只保存相对 `template_config_file` 所在目录的文件名，例如 `xycut_kb_010.assembly.json`。真实模板目录由 Agent 从 `agent-context.json` 的 `paths.video_templates_dir`、`paths.local_video_templates_dir` 或 `paths.local_video_template_index_file` 推导，最终通过脚本参数传入。

`title_template_duration_mode` 是客户端组装字段，Agent 只保留和传递，不要在生成计划时改写。`native` 表示标题/包装模板按自身时长展示，超过成片则裁尾；`full_video` 表示生成草稿时由 Python core 把图片、贴纸、文字等静态包装延长到成片结束，原始视频素材不拉长。

## 标题槽

标题创作必须根据 `title_slots` 的数量、顺序、`suggest_chars` 和 `sample_chars` 生成。

每个 `title_slots` 条目都代表一个真实可替换文字槽，Agent 生成 `title.items` 时必须逐槽对应：

- `slot_index` 按 `title_slots.index` 或顺序填写，不能把多个槽合成一条。
- 每个槽的文字长度优先落在 `suggest_chars` 范围内；没有 `suggest_chars` 时参考 `sample_chars`。
- 如果 `sample_text` 本身包含换行，说明该槽支持或期待多行展示；生成时应保留相近的换行结构，把 `\n` 写进该槽 `text`，不要压成一行。
- 多行槽每一行都要语义完整，不能把地名、时间、数字、品牌名或固定短语拆坏。
- 如果用户确认的是一个完整标题，写入 `title.items` 时也要按槽位拆成多条；`title.text` 保留完整标题。

短标题槽优先写核心钩子；长标题槽可以写痛点、利益点或行动引导。

如果模板应有标题但 `title_slots` 为空，说明模板索引不完整，应提示用户回到客户端重新生成或修复索引。

## 标题确认

标题是用户主观偏好最强的部分。除非用户明确说“标题你来定”“全流程自动”“不用确认标题”“直接生成草稿成品”“无需确认直接生成”“不用预览，直接生成”或“跳过确认”，否则必须先生成 3 个标题方案并停止等待用户选择。

回复格式保持简洁：

```text
我先给你 3 个标题方案，确认一个后再继续生成草稿：

1. ...
2. ...
3. ...
```

用户选择后，把确认的标题写入 `title.text` 和 `title.items`。如果模板有多个标题槽，`title.items` 按 `title_slots` 顺序拆分；`title.text` 使用完整主标题，不要留空。

`sample_text` 只作为字数、节奏和风格参考，不是必须照抄的固定文案。像“素材源于网络 侵联删”这类内容，如果模板没有明确标记为固定元素，不要写进标题。

## 固定元素

锁定轨道、锁定片段、背景、装饰元素、音乐和模板自带素材都只保留，不作为 Agent 可替换槽位。
