# 网络素材补充

只有用户选择“本地素材库不够时，用网络素材补充”时才启用。

## 触发条件

- 本地素材库没有合适候选。
- 或候选数量不足以覆盖用户选择的素材覆盖范围。
- 或用户明确要求使用网络素材。

## 执行规则

1. 只为缺素材的字幕或素材位生成搜索词。
2. 从 `agent_context_file.third_party_apis` 或客户端配置中读取可用平台信息。
3. 如果没有可用 API Key，停下来提示用户配置，不要伪造素材。
4. 下载或生成的候选素材也写入同一个 `material_plan.items`。

网络素材检索词必须使用英文名词短语，按“场景 + 主体 + 镜头/氛围”组合。中文原句只保留给 Agent 理解，不直接作为 Pexels 查询词。

如果中文内容包含很具体的地名、品牌名或本地文化词，先改写成可替代的通用英文场景词。例如“潮汕牛肉火锅”可改成 `hot pot restaurant food close up`，不要直接用 `Chaozhou beef hot pot` 作为唯一检索词。

## 计划字段

```json
{
  "line_id": "line_001",
  "query": "lake travel b-roll sunny mountain boat",
  "file_path": "<task_dir>\\materials\\line_001\\pexels_xxx.mp4",
  "source": "network",
  "provider": "pexels",
  "start": 0,
  "end": 3.2
}
```

网络素材只做补充，不替换已经匹配到且用户满意的本地素材。
