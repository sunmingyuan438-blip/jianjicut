# 统一工作台

统一工作台用于让用户在 Agent 内置浏览器中查看当前视频模板任务。前期固定保留三个页面：

```text
口播剪辑 / 素材匹配 / 生成草稿
```

哪个页面有对应数据就展示，缺少数据时显示空状态或不展示该模块，不做复杂跳转和隐藏规则。

其中“口播剪辑”页对所有任务展示 Tab1 定稿层；只有需要处理原始真人口播或用户明确要求时，才承担删气口、删废话、删重说的职责。

它不是独立 Skill，也不由 Agent 启动 Node 服务；页面由小圆 XYCut 客户端本地 API 托管。

## 何时打开

以下情况需要处理口播剪辑：

- 用户只给 MP4，没有提供 SRT。此时默认视为原始真人口播，ASR 后必须先询问是否需要剪口播。
- 用户明确要求剪口播、删气口、删废话、检查口误、重新处理口播或人工确认口播删改。

只给 MP4 且 ASR 完成后，必须先发送下面的简短询问，并等待用户选择：

```text
MP4 已识别完成，需要剪口播吗（自动删除口播的重复及错误）？
A 是的，需要
B 不需要，我手动改
C 跳过，不需要
```

- 选 A：先自动生成一版口播删改建议，写入 `edit\review_state.json`、`edit\cut_plan.json`、`edit\line_timeline.json`，再打开统一工作台让用户预览确认。
- 选 B：不自动删改，直接打开统一工作台让用户手动改，并等待保存。
- 选 C：不打开口播剪辑确认流程，保留默认不剪版 `edit` 文件进入标题和素材策略。

以下情况默认不要求用户做气口剪辑：

- 只给文案：AI 配音默认不删除气口。
- 只给 MP3：ASR 出 SRT 后默认不删除气口。
- `MP4 + SRT`：用户已经给了字幕，默认节奏已经处理好。
- `MP3 + SRT`：用户已经给了字幕，不再 ASR、不自动删除气口。

这些情况仍然生成默认不剪版 `edit\cut_plan.json` 和 `edit\line_timeline.json`。工作台可以作为任务页使用，但不强制用户保存删改。

## 打开方式

优先调用 `agent_context_file.local_api.editing_workbench_open_url`：

```powershell
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:17651/ai-editing/workbench/open" -ContentType "application/json; charset=utf-8" -Body '{"task_dir":"<task_dir>"}'
```

返回的 `url` 就是 Agent 内置浏览器要打开的统一工作台地址。

如果没有 `editing_workbench_open_url`，再从 `agent_context_file.local_api.base_url` 拼接 `/ai-editing/workbench/open`。

缺失时使用默认地址：

```text
http://127.0.0.1:17651/ai-editing/workbench
```

拼接任务目录：

```text
http://127.0.0.1:17651/xycut/<task_id>
```

需要口播剪辑时，打开前必须确保任务目录中至少存在：

```text
<task_dir>\speech\segments.json
<task_dir>\input\source.mp4
```

如果只是展示统一工作台，则按已有文件展示。可读取的数据包括：

```text
<task_dir>\input\source.mp3
<task_dir>\input\source.mp4
<task_dir>\speech\segments.json
<task_dir>\output\video_template_plan.json
<task_dir>\output\video_template_analysis.json
<task_dir>\material\material_plan.json
<task_dir>\edit\cut_plan.json
<task_dir>\edit\line_timeline.json
```

工作台会优先按 `video_template_plan.json` 的字幕行展示，逐字时间戳只用于播放定位。

## 工作台读写文件

读取：

```text
<task_dir>\speech\segments.json
<task_dir>\speech\peaks.json
<task_dir>\speech\silence_periods.json
<task_dir>\edit\review_state.json
<task_dir>\edit\line_timeline.json
<task_dir>\material\material_plan.json
<task_dir>\output\video_template_plan.json
```

保存：

```text
<task_dir>\edit\review_state.json
<task_dir>\edit\cut_plan.json
<task_dir>\edit\line_timeline.json
<task_dir>\edit\review_log.json
```

如果 `peaks.json` 或 `silence_periods.json` 不存在，工作台会通过客户端本地 API 自动调用已安装的 FFmpeg 生成：

```text
POST http://127.0.0.1:17651/ai-editing/workbench/api/media-analysis?task_id=<task_id>
```

`peaks.json` 用于真实波形展示，`silence_periods.json` 用于删除段贴近静音点，`review_log.json` 用于记录 AI 建议和用户最终删改之间的差异。

口播切点规则：

- 连续删除相邻两行字幕时，两行之间的空白/换气间隙默认一起删除，不依赖“切点贴近静音”开关；如果用户通过框选/字级删除把一整句所有字都删掉，也应视为整句删除。
- “切点贴近静音”只负责把删除段边界吸附到附近静音边界，避免剪断发音；它不是删除静音的总开关。
- 贴近静音点应保持保守，搜索范围不要过大；右边界吸附要比左边界更克制，左右边界为 0 帧时不额外扩边，负帧表示往内收窄红区。
- 字幕文字只受整句删除、字级删除和用户改单字影响；静音切点、吸附和红区扩边不能裁剪或改写字幕文字。

## 用户确认

只有本轮需要口播剪辑时，打开工作台后 Agent 必须停下来等待用户确认保存。

如果用户在 ASR 后选择 A 或 B，必须等用户回复“确认”“保存好了”“继续”“可以生成”等明确继续信号后，再读取剪辑结果并进入标题、素材策略和生成草稿流程。如果用户选择 C，则不要等待口播剪辑保存，直接继续后续流程。

用户在工作台中可以：

- 双击文字从该处播放。
- 框选文字后标记删除。
- 删除整句。
- 右键文字进行拆分、合并到上一行、修改文字。
- 查看底部波形，并点击波形定位播放。
- 在底部波形拖选时间段，标记删除红区、标记保留保护区，或试听选区。
- 调整贴近静音点、合并间隔和前后留白。
- 保存审核结果。

用户回复“确认”“保存好了”“继续”“可以生成”后，Agent 再读取：

```text
<task_dir>\edit\cut_plan.json
<task_dir>\edit\line_timeline.json
```

后续素材匹配和生成草稿应优先使用 `line_timeline.json` 中的剪辑后字幕行。生成草稿时必须把 `cut_plan.json` 交给客户端生成接口或写入生成请求，确保被删除内容不会进入最终成片。

`review_state.json` 中的 `manual_time_ranges` 表示用户在波形上手动画出的删除红区，`protected_ranges` 表示用户明确保护不剪的时间段。生成 `cut_plan.json` 时必须先合并字级/句级/静音/手动红区，再扣掉保护区，保证工作台预览和最终剪映草稿一致。

`review_log.json` 只用于后续 Agent 复盘和学习用户剪辑习惯，不参与生成剪映草稿。

素材匹配页支持用户预览已匹配素材，并从 `<task_dir>\materials\candidates\<line_id>.json` 中选择候选素材替换当前行素材；也支持用户在工作台内粘贴本地完整路径添加素材。用户替换或添加后应保存回 `video_template_analysis.json` 的 `material_plan.items`。

如果本轮不需要口播剪辑，不要等待用户在口播剪辑页保存；后续流程直接使用默认不剪版 `edit\line_timeline.json`。素材可以补齐字幕间隙，但不能因此平移字幕或删除音频/视频气口。
# Workbench URL

Agent 不要直接拼接 `task_dir` 长链接。需要打开剪辑工作台时，先调用：

```text
POST http://127.0.0.1:17651/ai-editing/workbench/open
Body: {"task_dir":"<task_dir>"}
```

然后把接口返回的 `url` 打开或回复给用户。返回地址格式为：

```text
http://127.0.0.1:17651/xycut/<task_id>
```
