# 素材策略

素材策略必须在生成最终素材计划前确认。除非用户已经明确说明，否则先停下来问。

如果缺少必要选择，本文件是流程闸门：不能创建任务目录、不能导出候选、不能调用网络或 AI 生成、不能生成 `video_template_analysis.json`、不能调用客户端生成接口。

必要选择包括：

- 素材覆盖范围：`scope` / `match_ratio`。只有 MP4 主画面时才需要问；MP3 或文案 TTS 音频-only 任务固定为 `full_cover + 1.0`。
- 素材来源：`source_mode`
- 素材匹配模式：`match_mode`

## 覆盖范围

### MP3 + SRT

没有主画面，默认全部字幕都需要匹配画面：

```json
{
  "scope": "full_cover",
  "match_ratio": 1.0
}
```

不要再询问“全部覆盖 / 重点覆盖 / 覆盖率”。但仍然必须确认素材补充方式和匹配模式。用户没有提供 `source_mode` 或 `match_mode` 时，停下来只问缺失项：

```text
素材默认全覆盖。匹配方式选一下：
A 快速全覆盖
B 精细全覆盖
```

如果还缺素材来源，默认合并成一句：

```text
素材默认全覆盖。选一下：A 本地快速  B 本地精细
```

### MP4 + SRT

已有主视频/A-roll，必须先询问用户：

```text
你想怎么添加画面素材？
1. 全部字幕都匹配素材
2. 只给重点内容补素材，约 35%
3. 只给重点内容补素材，约 50%
```

如果用户没有明确给出 `full_cover`、`partial_broll 0.35` 或 `partial_broll 0.5`，必须停在这里等待用户选择。

选 1 时：

```json
{
  "scope": "full_cover",
  "match_ratio": 1.0
}
```

选 2 或 3 时：

```json
{
  "scope": "partial_broll",
  "match_ratio": 0.35
}
```

或：

```json
{
  "scope": "partial_broll",
  "match_ratio": 0.5
}
```

## 素材来源

继续询问。用户没有明确给出 `source_mode` 时，必须停在这里等待用户选择：

```text
这次素材怎么补？
1. 只用本地素材库
2. 先用本地素材库，不够再用 Pexels 网络素材补充
3. 先用本地素材库，不够再用 GPT 生成图片补充
4. 先用本地素材库，不够再用火山 AI 生成素材补充
5. 本地素材库不够时，停下来让我自己补素材
6. 不用本地素材库，我自己提供素材
```

如果用户选择 GPT 生成图片且没有说明比例，先根据模板方向判断；模板方向不明确时再问画面比例。竖屏视频默认 `9:16`，横屏视频默认 `16:9`。

如果用户选择火山 AI 生成素材，先确认是“图片”还是“视频”。当前只预留框架，未提供即梦/SeeDance API 文档和示例前不要自行实现调用。

## 素材匹配模式

继续询问。用户没有明确给出 `match_mode` 时，必须停在这里等待用户选择：

```text
这次素材怎么匹配？
1. 快速匹配素材
2. 精细匹配素材
```

### 快速匹配素材

写入：

```json
{
  "match_mode": "fast"
}
```

本地脚本可以为每个素材位检索 Top 10 到 Top 20 候选，但候选全集只落盘，不进入 Agent 上下文。

脚本从高分 Top 3 中自动选择 1 条。选择时仍然考虑：

- 匹配分和质量分。
- 竖屏模板优先竖屏素材。
- 素材时长要够。
- 避免连续或过度重复同一素材。

Agent 只查看最终摘要和异常项，不逐条分析全部候选。

### 精细匹配素材

写入：

```json
{
  "match_mode": "refined"
}
```

本地脚本仍然保存完整候选，但只给 Agent 输出每个素材位 Top 5 的轻量摘要。Agent 根据语义贴合度、上下句节奏、重复使用、横竖屏和时长做最终选择或调整。

## 策略字段

写入计划时使用：

```json
{
  "material_strategy": {
    "scope": "partial_broll",
    "match_ratio": 0.35,
    "source_mode": "local_only",
    "match_mode": "fast",
    "asset_type": "video"
  }
}
```

`source_mode` 可选：

- `local_only`
- `local_plus_network`
- `local_plus_gpt_image`
- `local_plus_volcengine_ai`
- `local_then_user`
- `user_provided`

`asset_type` 可选：

- `video`
- `image`

AI 生成素材的具体生成结果也写入 `material_plan.items`，不要另起一套最终计划格式。

## 部分 B-roll 选择规则

当 `scope = partial_broll` 时，优先给这些字幕匹配素材：

- 地点、产品、场景、动作明确的句子。
- 抽象概念需要画面解释的句子。
- 视频节奏需要切换画面的句子。
- `03` 重点字幕附近的句子。

不要机械地按行号平均选。
