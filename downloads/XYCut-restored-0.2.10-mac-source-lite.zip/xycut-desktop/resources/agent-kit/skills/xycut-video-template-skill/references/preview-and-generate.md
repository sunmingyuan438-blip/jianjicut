# 预览和生成

## 统一任务工作台

视频模板任务优先使用统一工作台作为用户入口：

```text
POST http://127.0.0.1:17651/ai-editing/workbench/open
Body: {"task_dir":"<task_dir>"}

打开接口返回的 url：
http://127.0.0.1:17651/xycut/<task_id>
```

统一工作台固定包含：

```text
口播剪辑 / 素材匹配 / 生成草稿
```

统一工作台是面向用户的主界面。需要用户查看、修改、预览或确认时，Agent 必须打开工作台，或明确告诉用户去工作台操作；不要让用户打开 `video_template_analysis.json`、`video_template_plan.json`、`material_plan.json`、`subtitle_plan.json`、`README_summary.md` 等中间文件。

前期不做复杂页面隐藏：哪个页面有对应数据就展示，没有数据就显示空状态或不展示该模块。

所有视频模板任务都必须生成统一的 Tab1 定稿层。即使本轮不剪口播，也要先有默认不剪版：

```text
<task_dir>\edit\cut_plan.json
<task_dir>\edit\line_timeline.json
```

默认不剪版的 `cut_plan.delete_ranges=[]`，`keep_ranges` 覆盖完整主音频/主视频；`line_timeline.json` 保留原始 SRT/ASR 时间。用户如果在 Tab1 删除句子、字词或波形区间，客户端会更新同一套文件，后续字幕规划、素材匹配和生成草稿都读取更新后的时间线。

## 工作台数据文件（sidecar）与素材 line_id 绑定

工作台每层只读固定文件，缺少就显示空状态，不做旧结构兜底：

- Tab1 口播定稿层：`<task_dir>\edit\line_timeline.json`
- Tab2 素材匹配层：`<task_dir>\output\material_plan.json`
- Tab3 字幕规划层：`<task_dir>\output\subtitle_plan.json`
- 最终生成层：`<task_dir>\output\video_template_analysis.json`

只写 `output\video_template_analysis.json` 时，Tab2/Tab3 会全空。生成分析文件后必须补两个 sidecar：

```json
// output\material_plan.json
{ "schema_version": 1, "kind": "material_plan", "items": [], "scope": "full_cover", "match_ratio": 1.0, "source_mode": "local_only", "match_mode": "fast" }

// output\subtitle_plan.json
{ "schema_version": 1, "kind": "subtitle_plan", "subtitles": [], "subtitle_strategy": {}, "favorite_selection": {} }
```

快速自检（比翻前端代码快）：

```text
GET http://127.0.0.1:17651/ai-editing/workbench/api/task?task_id=<task_id>
```

看 `material_plan.missing` / `subtitle_plan.missing` 是否为 `null`，以及 `items` / `subtitles` 条数。

**素材 `line_id` 必须绑 Tab1 的行 ID**。工作台 `remapMaterialItemsToWorkbenchLines()` 先按 `line_id` 命中 Tab1 行，再按 `subtitle_text` 精确匹配整行文本，两者都不中就被整条丢弃，并按 Tab1 行去重（一行只留一条素材）。

- Tab1 行统一来自 `edit\line_timeline.json`，行 ID 是 `line_001`…。
- 纯音频 / 纯文案任务也必须有 `edit\line_timeline.json`；不要回落到 `speech\segments.json` 或只读 `video_template_plan.json`。

所以只要 Agent 做过 `01/02` 长句拆细（子行 `line_008_01`），素材就会失配。写 sidecar 前必须把素材**回并到父行**：`line_id` 改父行 ID，时间窗改用父行首尾区间，同一父行只保留一条素材。自检：`material_plan.items[].line_id` 必须 100% 命中 Tab1 行 ID。

时间线分层规则：

- Tab1/Tab2 使用父级长句时间线 `line_timeline`。`line_timeline` 不平移字幕、不压缩气口；需要避免全覆盖素材中间露黑时，只在 `material_plan.items[].target_end_ms` 上补画面间隙。
- Tab3 使用 `subtitle_plan` / `analysis.subtitles` 的短字幕。Agent 可以继续按语义把长句拆成多个短字幕用于屏幕展示和预设匹配。
- Tab3 的短字幕拆分不能反向改写 Tab2 素材时间窗；素材 `target_start_ms/target_end_ms` 以父级 `line_timeline` 为准。
- 不剪任务中，补间隙只补 B-roll 素材时长，不平移字幕、不压缩主音频/主视频。
- 剪口播任务中，主音频/主视频按 `cut_plan.keep_ranges` 切段，字幕和素材按剪后 `line_timeline` 走。
- 只有 MP3 或文案 TTS 生成 MP3 时，素材必须 `full_cover` 且按父级时间线连续铺满。MP4 全覆盖同样按父级时间线铺满。
- MP4 重点覆盖必须使用 `scope=partial_broll`，只覆盖选中的重点句；未匹配区间应保留主画面/A-roll，Agent 和生成端都不能把它强制铺满。

## 生成草稿 Tab 预览

生成 `video_template_analysis.json` 后，必须优先回到统一工作台的“生成草稿”页展示模板预览：

```text
POST http://127.0.0.1:17651/ai-editing/workbench/open
Body: {"task_dir":"<task_dir>"}

打开接口返回的 url：
http://127.0.0.1:17651/xycut/<task_id>
```

工作台后端会自动查找：

```text
<task_dir>\output\video_template_analysis.json
<task_dir>\video_template_analysis.json
```

并在“生成草稿”页承接原视频模板预览和生成按钮。

工作台“生成草稿”页优先使用原生组件渲染标题、模板预览、字幕分层、`03` 重点预设和素材状态。数据从客户端 JSON 接口读取：

```text
GET /ai-editing/video-template/analysis?analysis_file=<video_template_analysis.json 的完整路径>
```

该接口复用独立预览页的 `enrich_analysis` 逻辑，会补充模板预览图/视频和 `03` 候选预览媒体。保存仍然共用：

```text
POST /ai-editing/video-template/save-analysis
```

`03` 重点预设在工作台中使用 V8 同类交互：

- 字幕列表只显示完整正文，不把 `lines[]` 用 `｜` 直接摊开展示。
- `style_level="03"` 的字幕行显示“重点设置”按钮；按钮会提示当前分段字数或超字警告。
- 点击后打开重点预设弹窗，左侧编辑最多 3 段字幕分段，每段对应收藏复合预设里的一个文字槽。
- 弹窗左侧固定保留 3 个输入槽，空槽不折叠；回车从当前光标处拆分到下一段，段首退格或 Tab 可把当前段合并到上一段。
- 弹窗右侧只默认展示与当前非空分段数一致的候选预设；例如左侧 2 段时只列 2 槽预设。
- 候选预设按字数适配度排序：不超字且余量更小的排前，超字的排后，明显字数偏少的排更后。
- 候选卡默认展示竖版封面图，点击候选卡后再播放对应预览视频。
- 字数是否超限主要展示在每个候选预设卡片下方，左侧分段只保留当前输入字数和已选预设上限提示。
- 保存会写回当前 `video_template_analysis.json` 中该字幕的 `lines`、`line_chars`、`preset_match.preset`、`slot_count`、`slot_max_chars`、`input_lengths` 和 `overflow_chars`。
- 生成剪映草稿时，以保存后的 `lines[]` 和 `preset_match.preset.preset_path` 为准；不要把主列表里的展示文本当成 03 真实分段。

如果统一工作台暂未接入完整预览能力，才兼容打开客户端独立预览页：

```text
http://127.0.0.1:17651/ai-editing/video-template/preview?analysis_file=<video_template_analysis.json 的完整路径>
```

独立预览地址优先从 `agent_context_file.local_api.video_template_preview_url` 读取，缺失时才使用默认地址。

## 预览页用途

用户可以检查：

- 标题文案
- 字幕分层
- `03` 重点字幕预设
- B-roll 素材安排
- 素材候选是否贴合文案

## 生成规则

默认必须等待用户确认。

“生成草稿”“做一条草稿”“帮我生成剪映草稿”不等于“无需确认直接生成”。

只有用户提前明确包含以下表达之一时，Agent 才能跳过预览确认：

- 直接生成草稿成品
- 无需确认直接生成
- 不用预览，直接生成
- 跳过确认

其他情况下，只能打开统一工作台的“生成草稿”页并等待用户确认，不能继续调用生成接口。

用户在预览后回复“确认”“可以”“OK”“没问题”“继续”“往下走”“生成吧”，才算确认生成。单独说“生成草稿”“做一条视频”“帮我生成剪映草稿”只是发起流程，不算跳过预览确认。

## 调用客户端生成

生成接口优先读取 `agent_context_file.local_api.generate_url`。

```powershell
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:17651/ai-editing/generate" -ContentType "application/json; charset=utf-8" -Body '{"analysis_file":"<task_dir>\\video_template_analysis.json"}'
```

客户端负责登录态、会员/积分权益、模板固定元素保留、字幕样式复制、素材插入和最终剪映草稿写入。

如果存在 `<task_dir>\edit\cut_plan.json`，生成请求必须带上：

```json
{
  "analysis_file": "<task_dir>\\output\\video_template_analysis.json",
  "cut_plan_file": "<task_dir>\\edit\\cut_plan.json",
  "line_timeline_file": "<task_dir>\\edit\\line_timeline.json"
}
```

这样客户端生成草稿时才能按同一套 Tab1 时间线组装主媒体、字幕和素材。`delete_ranges` 为空时主媒体完整保留；`delete_ranges` 不为空时主视频或主音频都必须按 `keep_ranges` 切段。

生成成功后只告诉用户剪映草稿名称和去剪映草稿箱打开的方式。

## 最终回复格式

生成成功后的回复必须以剪映草稿名称为核心，使用醒目的大标题：

```md
# 剪映草稿已生成：<草稿名称>

请打开剪映草稿箱，搜索上面的草稿名称并打开继续编辑。
```

不要默认列出任务目录、中间 JSON、Markdown、SRT、ASR 原始结果、素材候选文件或客户端请求文件。只有用户明确要求排查、复盘或调试时，才补充这些路径。
