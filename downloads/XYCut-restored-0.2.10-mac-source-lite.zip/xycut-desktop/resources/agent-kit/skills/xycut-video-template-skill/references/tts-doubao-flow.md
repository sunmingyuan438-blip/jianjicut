# 配音与字幕生成

本流程只负责把文案、MP3 或 MP4 转成后续视频模板流程需要的 `mp3_file` / `mp4_file` 和 `srt_file`。

## 两种入口

### 只有文案

1. 把用户文案保存为 `<task_dir>\input\script.txt`。
2. 如果用户没有提供音色 ID，先从 `agent_context_file.speech.tts.default_voice_id` 读取默认音色。
3. 调用豆包 TTS 2.0 生成 `<task_dir>\input\source.mp3` 和 `<task_dir>\speech\tts.raw.json`。
4. 再对生成的 MP3 调用 ASR 或时间戳对齐流程，生成 `<task_dir>\speech\asr.raw.json`、`<task_dir>\speech\segments.json` 和 `<task_dir>\output\voice.srt`。不能只按文案估算时间戳。
5. 生成 SRT 时，原始文案是字幕分句权威，ASR 只提供字词时间。脚本会按原文标点拆句，并用单调模糊对齐把 ASR words 贴回原文句子，避免 ASR 把下一句开头字串到上一句结尾。
6. 得到 `MP3 + SRT` 后，回到 `input-routing.md` 的 MP3 + SRT 分支。
7. AI 配音默认不删除气口，但后续 `prepare_video_template_plan.py` 必须传入 `--segments-json "<task_dir>\speech\segments.json"`，生成带 words 的默认不剪版 Tab1 定稿层。

### 只有 MP3 或 MP4

1. 调用 ASR 识别用户提供的音频或视频。
2. 如果输入是 MP4，脚本会先用 FFmpeg 提取音频，再提交 ASR；遇到 `ipcm` / 裸 PCM / 大小端异常音轨时，脚本会生成 PCM 包重封装和 byteswap 备用音频，自动重试后再判断是否真的无法识别。
3. 生成 `<task_dir>\speech\asr.raw.json`、`<task_dir>\speech\segments.json` 和 `<task_dir>\output\voice.srt`。
4. MP4 输入继续走“只给 MP4”分支：ASR 完成后先询问用户是否需要剪口播，再按用户选择自动剪一版、手动打开工作台或跳过口播剪辑。
5. MP3 输入继续走 `MP3 + SRT` 分支：默认不删除气口，但必须把 `speech\segments.json` 传给 prepare，生成带 words 的默认不剪版 Tab1 定稿层，再全量配画面。

## SRT 对齐规则

- 用户提供了逐行文案时，逐行文案是字幕分组依据；ASR 只提供每个字或词的时间。
- 文案 TTS 的 ASR 对齐必须保留原文顺序和标点拆句；允许 ASR 出现少量同音字或错字，例如“艘/梭”“开河/开合”，但不能因此改写原文文本或跨句移动边界。
- 用户没有逐行文案时，使用 ASR 返回的 `utterances`、标点和词时间戳自动拆分。
- SRT 时间戳必须保留原始 ASR/TTS 对齐结果；不要把第一条字幕平移到 `00:00:00,000`。
- 任意两条字幕之间出现空隙时，不延长字幕、不删除音频；后续由 `material_plan` 把 B-roll 素材延长到下一句开始，避免素材轨道中间断开。
- SRT 展示文本使用用户原文或 ASR 带标点文本，不使用无标点的原始词串做最终字幕。
- `speech\segments.json` 中的 words 是工作台逐字删除、删词和气口处理的能力来源；只给用户 SRT 时没有这份 words，默认就是行级能力。

## 配置读取

从 `agent_context_file` 读取：

- `speech.tts`：豆包 TTS 端点、默认音色、resource_id。
- `speech.asr`：火山 ASR 端点、resource_id。
- `third_party_apis`：客户端保存的 API Key 和可选音色参数。
- `tools.ffmpeg_path`：MP4 转音频时使用。

不要在回复中展示 API Key。

## 当前边界

- 只有原始 MP4 默认需要询问是否剪口播；不要先渲染中间成品视频。所有输入后续都使用 `edit\cut_plan.json` 和 `edit\line_timeline.json`；用户选择跳过或默认不剪时，`delete_ranges=[]`，主媒体保持原始长度。
- ASR 空结果不要立刻要求用户补 SRT；先确认脚本已经尝试普通抽音频、PCM 包重封装和 byteswap 备用音频。全部失败后，再提示用户补 SRT、文案或换清晰人声音频。
- 声音复刻可通过用户提供的音色 ID 使用；声音复刻训练流程后续单独接入。
