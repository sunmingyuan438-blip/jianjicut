# 本地素材库匹配

本流程只使用已经整理完成的素材库 DB。不要扫描、抽帧、分析或向量化素材，这些归 `xycut-sucai-skill`。

## 输入

优先使用用户提示词中的：

```json
{
  "sucai_library": {
    "library_id": "lib_001",
    "library_root": "D:\\素材库\\素材库名称"
  }
}
```

`db_path` 默认从 `agent_context_file.sucai.db_path` 读取。提示词中不需要重复写入。

如果没有 `sucai_library`，但用户选择了本地素材库，先让用户回到客户端选择素材库并重新复制提示词。

## 素材库摸底

正式逐条检索前，先摸底当前素材库，避免素材明显不足时白跑大量候选导出。

需要确认：

- `materials` 总数。
- `analysis_status = completed` 的已分析素材数。
- `embedding_status = completed` 的可智能匹配素材数。
- 素材摘要和标签是否大致贴合当前视频主题。

如果已分析素材数或可智能匹配素材数明显少于需要匹配的素材位，先在摘要中说明“本地素材库不足”，再按用户选择的补充方式处理。不要对每条字幕反复检索同一个很小的素材库。

可用 SQLite 直接查看：

```powershell
<venv_python> -c "import sqlite3, json; db=r'<db_path>'; lib=r'<library_id>'; conn=sqlite3.connect(db); conn.row_factory=sqlite3.Row; print(json.dumps(dict(conn.execute('SELECT COUNT(*) material_count, SUM(analysis_status=''completed'') analyzed_count, SUM(embedding_status=''completed'') embedding_count FROM materials WHERE library_id=?', (lib,)).fetchone()), ensure_ascii=False))"
```

## Query 生成

不要把整个素材库发给 AI。

批量脚本会基于字幕文本自动生成 query。只有用户明确要求精细控制某些素材位时，Agent 才需要手工改写 query。

```json
[
  {
    "id": "line_001",
    "text": "湖边旅行开场画面，晴天，轻松"
  }
]
```

`MP3 + SRT` 通常每条字幕或每个语义段都生成 query。`MP4 + SRT` 的部分 B-roll 只给选中的重点句生成 query。

## Query 向量

默认由批量脚本自动处理，不要让 Agent 手工逐条请求向量。

脚本会读取 `agent_context_file.ai_services.doubao_llm.mode`：

- `user_key`：优先使用用户自己的豆包大模型 Key 生成 query embedding，不请求小圆 XYCut 客户端，不扣小圆 XYCut 积分。
- `xiaoyuan_service` 或未配置：调用客户端本地接口生成 query embedding。客户端会转发到小圆 XYCut 服务端，并按 100 条文本 1 积分扣除。

正常情况下，直接在批量匹配命令里传 `--agent-context-file`：

```powershell
<venv_python> <installed_skill_dir>\scripts\build_material_plan.py --plan "<task_dir>\output\video_template_plan.json" --agent-context-file "<agent_context_file>" --db "<db_path>" --library-id "<library_id>" --scope "partial_broll" --match-ratio 0.35 --source-mode "local_only" --match-mode "fast" --summary-output "<task_dir>\materials\material_match_summary.json"
```

脚本会自动把 query 向量缓存到：

```text
<task_dir>\materials\query_embeddings.json
```

需要调试用户 Key 向量生成时，才单独运行：

```powershell
<venv_python> <installed_skill_dir>\scripts\generate_query_embeddings.py --agent-context-file "<agent_context_file>" --items-file "<task_dir>\materials\query_items.json" --output "<task_dir>\materials\query_embeddings.json"
```

需要调试客户端接口时，才单独调用：

```powershell
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:17651/sucai/embeddings" -ContentType "application/json; charset=utf-8" -Body '{"request_id":"video-template-query-唯一ID","purpose":"script_query","items":[{"id":"line_001","text":"湖边旅行开场画面，晴天，轻松"}]}'
```

如果用户 Key 和客户端向量接口都不可用，退回关键词检索。

中文场景下，退回关键词检索时不要只传一整句 `--query`。应从字幕里提取 3 到 6 个短关键词，同时传 `--keywords`，例如“海边,日出,旅行,远景”。整句中文更适合向量查询，不适合直接做关键词 LIKE。

## 批量匹配素材

优先使用本 Skill 的批量脚本生成素材计划，避免 Agent 手工循环每句字幕：

```powershell
<venv_python> <installed_skill_dir>\scripts\build_material_plan.py --plan "<task_dir>\output\video_template_plan.json" --agent-context-file "<agent_context_file>" --db "<db_path>" --library-id "<library_id>" --scope "partial_broll" --match-ratio 0.35 --source-mode "local_only" --match-mode "fast" --summary-output "<task_dir>\materials\material_match_summary.json"
```

如果前面已经手工生成 `<task_dir>\materials\query_embeddings.json`，也可以追加 `--query-embeddings-file "<task_dir>\materials\query_embeddings.json"`。

`--match-mode fast` 时：

- 脚本保存完整候选到 `<task_dir>\materials\candidates\`。
- 脚本从高分 Top 3 中自动选择 1 条。
- 终端只输出简短统计，Agent 不读取候选全集。

`--match-mode refined` 时：

- 脚本同样保存完整候选到磁盘。
- `summary-output` 写入每个素材位 Top 5 轻量摘要。
- Agent 只读取摘要文件，复核或调整 `material_plan.items`，不要读取完整候选全集。

## 单条导出候选

使用 `xycut-sucai-skill/scripts/export_candidates.py` 导出每个 query 的 Top 10 到 Top 20 候选。

```powershell
<venv_python> <sucai_skill_dir>\scripts\export_candidates.py --db "<db_path>" --library-id "<library_id>" --query "<query>" --query-embedding-file "<query_embedding_file>" --top-k 20 --output "<task_dir>\material_candidates_line_001.json" --summary-only
```

只有调试单条匹配时才用单条导出。正式生成优先用批量脚本。使用 `--summary-only`，完整候选写入文件，终端只输出轻量摘要。

Agent 只查看候选的轻量字段：

- `material_id`
- `path`
- `file_name`
- `original_file_name`
- `type`
- `duration_sec`
- `orientation`
- `summary`
- `keywords`
- `quality_score`
- `score`

## 最终选择

每个素材位只写选中的素材，不把候选全集写入最终计划。

```json
{
  "line_id": "line_001",
  "query": "湖边旅行开场画面，晴天，轻松",
  "selected_material_id": "mat_0001",
  "file_path": "D:\\素材库\\001\\mat_0001.mp4",
  "source": "sucai_library",
  "target_start_ms": 0,
  "target_end_ms": 3200
}
```

选择时考虑：语义匹配、画面方向、素材时长、质量分、重复使用次数和当前字幕节奏。

`target_start_ms` / `target_end_ms` 是素材在成片里的摆放时间。素材内部裁剪只使用 `source_start` / `source_end` 或 `source_start_ms` / `source_end_ms`；没有这些字段时，草稿生成器默认从素材开头取目标字幕所需时长。

批量脚本默认避免重复使用同一个 `material_id`：只要当前候选里还有未用素材，就优先选择未用素材。只有素材库候选不足、不得不复用同一个视频时，才写入 `source_start` / `source_end` 来错开素材内部入点，减少重复素材每次都从同一帧开始的观感。这个字段只表示素材文件内部时间，不表示字幕在成片里的时间。

`fast` 模式可以接受脚本自动选择。`refined` 模式只复核 Top 5 轻量摘要，最终仍然只写每个素材位选中的 1 条。

素材库候选不足时，按 `material-strategy.md` 中用户选择的来源策略处理。
