# 剪映草稿目录设置教程

当 `agent_context_file.paths.draft_output_dir` 为空、目录不存在，或用户询问“剪映草稿目录怎么设置”时，读取本教程并直接在对话中回复用户。回复时保留关键图片，不要只让用户自己去找文件。

## 对话回复模板

当前还没有设置剪映草稿目录，所以暂时不能生成剪映草稿。先按下面步骤设置：

1. 打开剪映，进入「设置」->「全局设置」。

   ![打开剪映设置](../assets/jianying-draft-dir/ai101x-0709133344.webp)

2. 在全局设置里找到「剪映草稿位置」，点击打开目录，然后复制完整文件夹路径。

   ![复制剪映草稿位置](../assets/jianying-draft-dir/ai101x-0827174229.webp)

   注意要复制完整路径，例如：

   - 正确：`D:\xxx\xxx\JianyingPro Drafts`
   - 正确：`D:\xxx\JianyingPro Drafts`
   - 错误：`JianyingPro Drafts`
   - 错误：`D:\xxx\JianyingPro\User Data\Presets`

3. 回到小圆 XYCut 客户端，进入「设置」->「目录/素材库」->「视频设置」，把刚才复制的路径填到剪映草稿目录里并保存。

   ![填写剪映草稿目录](../assets/jianying-draft-dir/ai101x-0709133420.webp)

设置完成后，重新复制视频模板提示词发给 Agent，再继续生成草稿。第一次设置后，如果剪映里看不到新草稿，重启剪映再看。

## 视频教程

本 Skill 内带有视频教程资源：

[剪映草稿目录设置教程.mp4](../assets/jianying-draft-dir/剪映草稿目录设置教程.mp4)
