# 素材整理主流程

## 先确认分析强度

正式处理素材前，必须确认用户想用哪种分析强度，除非用户已经明确说明：

- 快速分析
- 合理分析 / 前中后分析
- 精细分析并分割片段 / 分割素材 / 裁掉不要的片段

如果用户没有说明，先询问：

```text
你希望用哪种方式整理这个素材库？
1. 快速分析：每个视频取中间 1 帧，速度最快。
2. 合理分析：每个视频取前、中、后 3 帧，更适合普通素材理解。
3. 精细分析并分割片段：约每秒取 1 帧，自动剔除无效片段，并把长视频拆成多个 5-10 秒左右的可用素材；原始长视频不作为正式素材保存。
```

只有用户选择后，才开始调用脚本。

## 每轮处理

每轮读取最多 10 个待整理素材。

如果 `agent_context_file` 里有 `tools.ffmpeg_path` 和 `tools.ffprobe_path`，调用时显式传入：

```powershell
python xycut-agent-kit\skills\xycut-sucai-skill\scripts\prepare_analysis_batch.py --db "C:\...\xycut-sucai.db" --library-id "lib_001" --limit 10 --analysis-level quick --ffmpeg "C:\...\ffmpeg.exe" --ffprobe "C:\...\ffprobe.exe" --output "D:\task\material_batch.json"
```

如果上下文里没有工具路径，也可以不传 `--ffmpeg` / `--ffprobe`，脚本会自动查找小圆 XYCut 客户端的 runtime 目录和系统 PATH。

根据用户选择替换 `--analysis-level`：

- `quick`：快速分析
- `balanced`：合理分析
- `precise`：精细分析并分割片段

读取 `material_batch.json` 后，只分析其中 `materials` 列表里的素材。素材图片输入使用每条素材的 `analysis_inputs`。

如果选择 `precise`：

- 视频素材必须输出 `save_mode: "split_only"`。
- 视频素材必须输出 `segments`。
- 每个片段建议 5-10 秒，极端情况下可保留 3-4 秒。
- 不要因为画面 1-2 秒快切就拆成过短素材，应合并成 5 秒左右的可用片段。
- 原始视频只作为来源记录，不作为正式素材入库。

## 保存分析结果

把本轮分析结果保存为 JSON 文件，再调用：

```powershell
python xycut-agent-kit\skills\xycut-sucai-skill\scripts\save_material_analysis.py "D:\task\analysis.json" --ffmpeg "C:\...\ffmpeg.exe"
```

保存成功后继续下一轮。再次调用 `prepare_analysis_batch.py --limit 10`，如果还有待整理素材，就继续处理；如果返回数量为 0，说明当前素材库已经整理完成。

## 中断后继续

如果任务中断，下次仍然从 `prepare_analysis_batch.py --limit 10` 开始。脚本会继续读取未完成素材，不需要 Agent 自己记录进度。

## 自动更新智能索引

开始整理前，可以先尝试触发一次客户端更新索引，处理之前已经完成但还没向量化的素材。优先使用 `agent_context_file` 里的 `local_api.sucai_build_embeddings_url`：

```powershell
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:17651/sucai/embeddings/build" -ContentType "application/json" -Body '{"library_id":"lib_001","limit":100}'
```

全部待整理素材完成后，再尝试调用一次同样的 API。

这个 API 和客户端「更新索引」按钮是同一套逻辑。调用失败时不要中断素材整理结果，只提醒用户回到客户端素材库页面点击「刷新」，再点击「更新索引」。
