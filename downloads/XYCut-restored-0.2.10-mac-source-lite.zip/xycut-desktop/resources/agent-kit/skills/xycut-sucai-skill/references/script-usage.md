# 脚本使用

## check_runtime.py

检查当前环境是否能处理视频素材。

```powershell
python xycut-agent-kit\skills\xycut-sucai-skill\scripts\check_runtime.py
```

如果 `agent_context_file` 里有 `tools.ffmpeg_path` 和 `tools.ffprobe_path`，优先显式传入：

```powershell
python xycut-agent-kit\skills\xycut-sucai-skill\scripts\check_runtime.py --ffmpeg "C:\...\ffmpeg.exe" --ffprobe "C:\...\ffprobe.exe"
```

如果没有显式传入，脚本会自动查找小圆 XYCut 客户端 runtime 目录和系统 PATH。

如果缺少 FFmpeg / FFprobe，提示用户打开小圆 XYCut 客户端：

```text
左侧菜单「素材库」 -> 右上角「运行组件」 -> 点击「安装 FFmpeg 视频处理组件」。
安装完成后，回到 Agent 对话中发送“已安装，继续处理”。
```

## prepare_analysis_batch.py

读取当前素材库中未完成的素材，并为图片/视频生成压缩后的分析输入。

```powershell
python xycut-agent-kit\skills\xycut-sucai-skill\scripts\prepare_analysis_batch.py --db "C:\...\xycut-sucai.db" --library-id "lib_001" --limit 10 --analysis-level quick --ffmpeg "C:\...\ffmpeg.exe" --ffprobe "C:\...\ffprobe.exe" --output "D:\task\material_batch.json"
```

关键参数：

- `--db`：客户端传入的数据库路径。
- `--library-id`：当前素材库 ID。
- `--limit 10`：每轮最多 10 个。
- `--analysis-level quick|balanced|precise`：分析强度；`precise` 表示精细分析并分割片段。
- `--ffmpeg` / `--ffprobe`：优先使用 `agent_context_file` 里的工具路径；不传时脚本会自动查找。
- `--max-image-edge 768`：分析图片最长边，默认 768。
- `--output`：输出批次 JSON。

Agent 只能使用输出 JSON 中每个素材的 `analysis_inputs` 进行画面分析。

## save_material_analysis.py

保存 Agent 的分析结果。

```powershell
python xycut-agent-kit\skills\xycut-sucai-skill\scripts\save_material_analysis.py "D:\task\analysis.json"
```

分析 JSON 推荐结构：

```json
{
  "db_path": "C:\\...\\xycut-sucai.db",
  "library_id": "lib_001",
  "materials": [
    {
      "source_id": "src_0001",
      "analysis_level": "precise",
      "save_mode": "split_only",
      "summary": "蓝色湖面上一艘观光游船缓慢经过，远处是连绵山脉和晴朗天空。",
      "keywords": ["湖泊", "游船", "山脉", "晴天", "旅游"],
      "quality_score": 0.86,
      "segments": [
        {
          "start_sec": 5,
          "end_sec": 12,
          "summary": "湖边游船从画面左侧缓慢经过，远处山脉清晰，适合旅游风光转场。",
          "keywords": ["湖泊", "游船", "山脉", "旅游风光"],
          "quality_score": 0.88
        }
      ]
    }
  ]
}
```

保存脚本会把成品素材写入正式素材库目录，并更新数据库状态。

规则：

- `quick` / `balanced`：不要写 `segments`，保存原始素材。
- `precise` 视频：必须写 `save_mode: "split_only"` 和 `segments`，保存脚本会用 FFmpeg 切成多个独立素材，只保存切片，不保存原始长视频。
- `precise` 图片：图片没有分割概念，仍保存图片本身。
- 切片默认建议 5-10 秒；极端情况下可保留 3-4 秒，不要把 1-2 秒快切镜头机械拆成过短素材。

## search_materials.py

按文本关键词检索候选素材。

```powershell
python xycut-agent-kit\skills\xycut-sucai-skill\scripts\search_materials.py --db "C:\...\xycut-sucai.db" --library-id "lib_001" --query "湖边游船 晴天 山水" --top-k 10
```

## export_candidates.py

导出业务 Skill 可读取的候选素材 JSON。

```powershell
python xycut-agent-kit\skills\xycut-sucai-skill\scripts\export_candidates.py --db "C:\...\xycut-sucai.db" --library-id "lib_001" --query "湖边游船 晴天 山水" --output "D:\task\candidates.json"
```

业务 Skill 负责最终如何选择和使用候选素材。
