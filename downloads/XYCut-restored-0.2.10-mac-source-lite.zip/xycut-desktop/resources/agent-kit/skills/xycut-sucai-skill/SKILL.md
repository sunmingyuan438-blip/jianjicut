---
name: xycut-sucai-skill
description: 处理小圆 XYCut 素材库的待整理素材分析、正式入库和候选检索。遇到“素材库”“素材分析”“素材整理”“素材候选”“xycut-sucai.db”等请求时使用；业务模板如何最终选用素材由对应业务 Skill 决定。
metadata:
  version: 0.2.1
---

# 小圆素材库 Skill

## 目标

把客户端已经登记好的待整理图片/视频素材，整理成后续业务 Skill 可以稳定调用的本地素材库。

Agent 负责理解素材画面并输出结构化分析结果；脚本负责读取待处理批次、抽帧压缩、校验结果、保存成品素材、写入数据库和检索候选素材。

## 当前任务入口

用户通常会提供：

```json
{
  "agent_context_file": "C:\\Users\\...\\agent-context.json",
  "db_path": "C:\\Users\\...\\xycut-sucai.db",
  "library_id": "lib_001",
  "library_name": "素材库名称"
}
```

如果提示词提供 `agent_context_file` 和 `db_path`，以提示词里的路径为准。不要猜测其他用户目录。

如果提供了 `agent_context_file`，先读取它。常用字段：

- `tools.ffmpeg_path`
- `tools.ffprobe_path`
- `local_api.sucai_build_embeddings_url`

如果 `tools.ffmpeg_path` / `tools.ffprobe_path` 有值，调用脚本时显式传入 `--ffmpeg` / `--ffprobe`。如果没有值，脚本会自动尝试查找小圆 XYCut 客户端的 runtime 目录。

## 必须读取的参考文档

处理素材整理、继续整理、重新分析时，先阅读：

- `references/main-flow.md`
- `references/analysis-rules.md`
- `references/script-usage.md`

只做素材候选检索时，阅读：

- `references/script-usage.md`

## 核心规则

- Agent 不直接写 SQL，不手动修改 `xycut-sucai.db`。
- 所有数据库写入必须通过本 Skill 的脚本完成。
- 每轮最多处理 10 个待整理素材。
- 中断后继续处理时，只处理 `pending` / `failed` 素材，不重复处理已完成素材。
- 没有明确分析强度时，必须先询问用户，不能直接调用批次脚本。
- 普通素材整理不创建分组，不输出 `category`。
- 描述和标签只写素材真实内容，不写通用素材库词。
- 不移动、删除、修改用户原始素材。
- 输出给 Agent 分析的图片必须使用脚本生成的压缩图或抽帧图，不直接把原始大图/视频帧发给 Agent。

## 分析输出格式

每个素材输出：

```json
{
  "source_id": "src_0001",
  "summary": "蓝色湖面上一艘观光游船缓慢经过，远处是连绵山脉和晴朗天空。",
  "keywords": ["湖泊", "游船", "山脉", "晴天", "旅游", "休闲"],
  "quality_score": 0.86
}
```

要求：

- `source_id` 必须原样返回本轮批次中的值。
- `summary` 用一句话描述画面主体、动作、环境和氛围。
- `keywords` 写真实可用于匹配的标签。
- `quality_score` 是 Agent 对画面可用性的判断，范围 0 到 1。
- 快速分析和合理分析时不要写 `segments`，脚本会保存原始素材。
- 精细分析表示“精细分析并分割片段”：视频必须输出 `save_mode: "split_only"` 和可用 `segments`，脚本只保存拆出来的片段，不把原始长视频保存为正式素材。
- 精细分割片段建议每段 5-10 秒；画面 1-2 秒快切时不要机械拆成过短素材，应合并为 5 秒左右的可用片段；极端情况下才保留 3-4 秒片段。

## 完成后

全部待整理素材完成后，按 `references/main-flow.md` 的规则尝试触发客户端更新智能索引。失败时不要影响已保存的素材结果，只提醒用户回到客户端素材库页面点击「刷新」，再点击「更新索引」。
