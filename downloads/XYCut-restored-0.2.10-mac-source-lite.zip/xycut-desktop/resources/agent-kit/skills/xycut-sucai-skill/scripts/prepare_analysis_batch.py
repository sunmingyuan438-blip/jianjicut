from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path
from typing import Any, Optional

from common import (
    MISSING_FFMPEG_MESSAGE,
    collection_path,
    compact_material,
    connect_db,
    default_db_path,
    descendant_collection_ids,
    ffprobe_video,
    init_schema,
    resolve_ffmpeg,
    resolve_ffprobe,
    write_json,
)


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_")[:80] or "material"


def frame_times(duration: float, analysis_level: str, frame_count: int, max_frames: int) -> list[float]:
    if duration <= 0:
        return [0.1]
    def clamp_time(value: float) -> float:
        upper = max(0.1, duration - 0.05)
        return max(0.1, min(upper, value))

    if analysis_level == "quick":
        return [clamp_time(duration * 0.5)]
    if analysis_level == "precise":
        count = max(1, min(max(1, int(duration)), max_frames))
        return [clamp_time(index + 0.5) for index in range(count)]
    ratios = [0.15, 0.5, 0.85]
    return [clamp_time(duration * ratio) for ratio in ratios[: max(1, frame_count)]]


def fill_video_metadata(material: dict[str, Any], ffprobe: Optional[str], warnings: list[dict[str, str]]) -> None:
    if material["type"] != "video" or not ffprobe or material.get("duration_sec"):
        return
    try:
        metadata = ffprobe_video(Path(material["path"]), ffprobe)
    except Exception as exc:
        warnings.append({"material_id": material["material_id"], "warning": "读取视频信息失败: %s" % exc})
        return
    for key in ("duration_sec", "width", "height", "orientation", "fps"):
        if metadata.get(key) is not None:
            material[key] = metadata[key]


def resize_filter(max_image_edge: int) -> str:
    edge = max(256, int(max_image_edge or 768))
    return "scale=%d:%d:force_original_aspect_ratio=decrease" % (edge, edge)


def resize_image_for_analysis(
    ffmpeg: str,
    material: dict[str, Any],
    frames_dir: Path,
    max_image_edge: int,
    image_quality: int,
) -> str:
    frames_dir.mkdir(parents=True, exist_ok=True)
    output = frames_dir / ("%s_image.jpg" % safe_name(material["material_id"]))
    command = [
        ffmpeg,
        "-y",
        "-i",
        material["path"],
        "-vf",
        resize_filter(max_image_edge),
        "-frames:v",
        "1",
        "-q:v",
        str(max(2, min(31, image_quality))),
        str(output),
    ]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=30)
    return str(output) if output.is_file() else material["path"]


def extract_frames(
    ffmpeg: str,
    material: dict[str, Any],
    frames_dir: Path,
    frame_count: int,
    analysis_level: str,
    max_frames: int,
    max_image_edge: int,
    image_quality: int,
) -> list[str]:
    if material["type"] != "video":
        return [
            resize_image_for_analysis(
                ffmpeg,
                material,
                frames_dir,
                max_image_edge,
                image_quality,
            )
        ]
    duration = float(material.get("duration_sec") or 0)
    times = frame_times(duration, analysis_level, frame_count, max_frames)
    output_paths = []
    frames_dir.mkdir(parents=True, exist_ok=True)
    for index, timestamp in enumerate(times, start=1):
        output = frames_dir / ("%s_%02d.jpg" % (safe_name(material["material_id"]), index))
        command = [
            ffmpeg,
            "-y",
            "-ss",
            "%.3f" % timestamp,
            "-i",
            material["path"],
            "-frames:v",
            "1",
            "-vf",
            resize_filter(max_image_edge),
            "-q:v",
            str(max(2, min(31, image_quality))),
            str(output),
        ]
        subprocess.run(command, check=True, capture_output=True, text=True, timeout=30)
        if output.is_file():
            output_paths.append(str(output))
    return output_paths


def compact_source_material(row) -> dict[str, Any]:
    return {
        "source_id": row["id"],
        "material_id": row["id"],
        "library_id": row["library_id"],
        "collection_id": "",
        "collection": "",
        "path": row["original_path"],
        "original_path": row["original_path"],
        "original_file_name": row["file_name"],
        "relative_path": row["file_name"],
        "file_name": row["file_name"],
        "type": row["type"],
        "duration_sec": None,
        "width": None,
        "height": None,
        "orientation": "",
        "fingerprint": row["fingerprint"],
        "summary": "",
        "keywords": [],
        "quality_score": None,
        "analysis_status": row["status"],
        "embedding_status": "pending",
        "is_source_material": True,
    }


def prepare(args: argparse.Namespace) -> dict[str, Any]:
    db_path = Path(args.db).expanduser().resolve()
    statuses = [item.strip() for item in args.status.split(",") if item.strip()]
    where = []
    params: list[Any] = []
    if args.library_id:
        where.append("library_id = ?")
        params.append(args.library_id)

    with connect_db(db_path) as conn:
        init_schema(conn)
        source_where = []
        source_params: list[Any] = []
        if args.library_id:
            source_where.append("library_id = ?")
            source_params.append(args.library_id)
            conn.execute(
                "UPDATE source_materials SET status = 'pending' WHERE library_id = ? AND status = 'processing'",
                (args.library_id,),
            )
        else:
            conn.execute("UPDATE source_materials SET status = 'pending' WHERE status = 'processing'")
        if statuses:
            source_where.append("status IN (%s)" % ",".join("?" for _ in statuses))
            source_params.extend(statuses)
        source_sql = "SELECT * FROM source_materials"
        if source_where:
            source_sql += " WHERE " + " AND ".join(source_where)
        source_sql += " ORDER BY updated_at ASC, file_name ASC LIMIT ?"
        source_params.append(args.limit)
        source_rows = conn.execute(source_sql, tuple(source_params)).fetchall()
        if source_rows:
            now = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).replace(microsecond=0).isoformat()
            conn.executemany(
                "UPDATE source_materials SET status = 'processing', updated_at = ? WHERE id = ?",
                [(now, row["id"]) for row in source_rows],
            )
            conn.commit()
        materials = [compact_source_material(row) for row in source_rows]

        if len(materials) < args.limit:
            material_limit = args.limit - len(materials)
            material_where = list(where)
            material_params = list(params)
            collection_ids = descendant_collection_ids(conn, args.collection_id)
            if collection_ids:
                material_where.append("collection_id IN (%s)" % ",".join("?" for _ in collection_ids))
                material_params.extend(collection_ids)
            if statuses:
                material_where.append("analysis_status IN (%s)" % ",".join("?" for _ in statuses))
                material_params.extend(statuses)
            sql = "SELECT * FROM materials"
            if material_where:
                sql += " WHERE " + " AND ".join(material_where)
            sql += " ORDER BY updated_at ASC, file_name ASC LIMIT ?"
            material_params.append(material_limit)
            rows = conn.execute(sql, tuple(material_params)).fetchall()
            materials.extend([compact_material(row, collection_path(conn, row["collection_id"])) for row in rows])

    videos = [item for item in materials if item["type"] == "video"]
    ffmpeg = resolve_ffmpeg(args.ffmpeg)
    ffprobe = resolve_ffprobe(args.ffprobe)
    if videos and not args.no_frames and not ffmpeg:
        return {"ok": False, "message": MISSING_FFMPEG_MESSAGE, "missing": "ffmpeg"}

    warnings = []
    frames_dir = Path(args.frames_dir).expanduser().resolve() if args.frames_dir else None
    if not frames_dir and args.output:
        frames_dir = Path(args.output).expanduser().resolve().parent / "analysis-frames"
    if not frames_dir:
        frames_dir = Path.cwd() / "analysis-frames"
    for item in materials:
        item["analysis_inputs"] = [item["path"]]
        fill_video_metadata(item, ffprobe, warnings)
        if item["type"] in {"video", "image"} and not args.no_frames and ffmpeg and frames_dir:
            try:
                item["analysis_inputs"] = extract_frames(
                    ffmpeg,
                    item,
                    frames_dir,
                    args.frame_count,
                    args.analysis_level,
                    args.max_frames,
                    args.max_image_edge,
                    args.image_quality,
                )
                item["analysis_level"] = args.analysis_level
                item["analysis_image_max_edge"] = args.max_image_edge
            except Exception as exc:
                warning_text = "抽帧失败: %s" % exc if item["type"] == "video" else "图片压缩失败: %s" % exc
                warnings.append({"material_id": item["material_id"], "warning": warning_text})
                item["analysis_inputs"] = [item["path"]]
        elif item["type"] == "image" and not ffmpeg:
            warnings.append({"material_id": item["material_id"], "warning": "未找到 FFmpeg，图片将使用原图给 Agent 分析。"})

    payload = {
        "ok": True,
        "schema_version": 1,
        "mode": args.mode,
        "analysis_level": args.analysis_level,
        "analysis_image_max_edge": args.max_image_edge,
        "db_path": str(db_path),
        "library_id": args.library_id,
        "collection_id": args.collection_id,
        "count": len(materials),
        "materials": materials,
        "agent_output_schema": {
            "material_id": "mat_0001",
            "source_id": "src_0001（如果本轮素材来自待整理来源，请原样返回）",
            "analysis_level": args.analysis_level,
            "save_mode": "split_only（仅 precise 视频素材使用；quick/balanced 不要填写）",
            "summary": "素材画面摘要",
            "keywords": ["关键词1", "关键词2"],
            "quality_score": 0.86,
            "segments": [
                {
                    "start_sec": 1.2,
                    "end_sec": 7.8,
                    "summary": "视频中可用片段摘要",
                    "keywords": ["片段关键词"],
                    "quality_score": 0.8,
                }
            ],
            "notes": "文件名和目录名只能辅助判断真实地点、主体、场景和动作；不要把竖屏、横屏、免费商用、素材、视频、高清、无水印等通用词写入 summary 或 keywords；方向、尺寸、时长由代码记录；不要输出 category 或创建分组；quick/balanced 不要输出 segments；precise 表示精细分析并分割片段，视频必须输出 save_mode=split_only 和可用 segments，片段建议 5-10 秒，极端情况下可保留 3-4 秒，不要按 1-2 秒快切机械拆分。",
        },
        "warnings": warnings,
    }
    if args.output:
        output = Path(args.output).expanduser().resolve()
        write_json(output, payload)
        payload["output"] = str(output)
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description="Export a small material batch for Agent visual analysis.")
    parser.add_argument("--db", default=str(default_db_path()), help="SQLite DB path.")
    parser.add_argument("--library-id", help="Filter by library id.")
    parser.add_argument("--collection-id", help="Filter by collection id, including descendants.")
    parser.add_argument("--status", default="pending,failed", help="Comma separated analysis_status values.")
    parser.add_argument("--limit", type=int, default=10, help="Max materials to export.")
    parser.add_argument("--mode", choices=["small_batch", "organize"], default="small_batch")
    parser.add_argument("--analysis-level", choices=["quick", "balanced", "precise"], default="quick", help="quick=middle frame, balanced=front/middle/back, precise=one frame per second.")
    parser.add_argument("--output", help="Output JSON file.")
    parser.add_argument("--frames-dir", help="Directory for extracted video frames.")
    parser.add_argument("--ffmpeg", help="Explicit ffmpeg executable path.")
    parser.add_argument("--ffprobe", help="Explicit ffprobe executable path.")
    parser.add_argument("--frame-count", type=int, default=3, help="Frames per video for balanced analysis.")
    parser.add_argument("--max-frames", type=int, default=60, help="Max frames per video for precise analysis.")
    parser.add_argument("--max-image-edge", type=int, default=768, help="Resize analysis images so the longest edge is at most this many pixels.")
    parser.add_argument("--image-quality", type=int, default=5, help="JPEG quality for analysis images. Smaller is better quality in ffmpeg.")
    parser.add_argument("--no-frames", action="store_true", help="Do not extract video frames.")
    args = parser.parse_args()

    try:
        result = prepare(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("ok") else 2
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
