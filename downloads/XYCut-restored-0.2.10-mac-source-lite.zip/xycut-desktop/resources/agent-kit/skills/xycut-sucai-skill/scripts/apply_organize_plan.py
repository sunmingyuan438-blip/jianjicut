from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

from common import MISSING_FFMPEG_MESSAGE, read_json, resolve_ffmpeg, write_json


def is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def unique_target(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    parent = path.parent
    for index in range(1, 1000):
        candidate = parent / f"{stem}-{index}{suffix}"
        if not candidate.exists():
            return candidate
    return parent / f"{stem}-{int(path.stat().st_mtime)}{suffix}"


def copy_item(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def clip_item(ffmpeg: str, source: Path, target: Path, start_sec: float, end_sec: float) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    command = [
        ffmpeg,
        "-y",
        "-ss",
        "%.3f" % start_sec,
        "-to",
        "%.3f" % end_sec,
        "-i",
        str(source),
        "-map",
        "0",
        "-c",
        "copy",
        str(target),
    ]
    completed = subprocess.run(command, check=False, capture_output=True, text=True, timeout=180)
    if completed.returncode != 0:
        command = [
            ffmpeg,
            "-y",
            "-ss",
            "%.3f" % start_sec,
            "-to",
            "%.3f" % end_sec,
            "-i",
            str(source),
            "-c:v",
            "libx264",
            "-c:a",
            "aac",
            "-movflags",
            "+faststart",
            str(target),
        ]
        subprocess.run(command, check=True, capture_output=True, text=True, timeout=300)


def apply_plan(args: argparse.Namespace) -> dict[str, Any]:
    plan_path = Path(args.plan).expanduser().resolve()
    plan = read_json(plan_path)
    if not isinstance(plan, dict) or plan.get("purpose") != "xycut_sucai_organize_plan":
        raise ValueError("不是有效的 xycut_sucai_organize_plan")
    if not args.confirm:
        return {
            "ok": False,
            "requires_confirm": True,
            "message": "执行整理计划前必须显式传入 --confirm。请先让客户端/用户确认计划内容。",
            "plan": str(plan_path),
        }
    output_dir = Path(plan.get("output_dir") or args.output_dir or "").expanduser().resolve()
    if not output_dir:
        raise ValueError("缺少 output_dir")
    items = plan.get("items")
    if not isinstance(items, list):
        raise ValueError("plan.items 必须是数组")

    needs_ffmpeg = any(isinstance(item, dict) and item.get("action") == "clip" for item in items)
    ffmpeg = resolve_ffmpeg(args.ffmpeg)
    if needs_ffmpeg and not ffmpeg:
        return {"ok": False, "message": MISSING_FFMPEG_MESSAGE, "missing": "ffmpeg"}

    executed = []
    skipped = []
    for raw in items:
        if not isinstance(raw, dict):
            skipped.append({"warning": "跳过非 object 项"})
            continue
        action = str(raw.get("action") or "copy").strip().lower()
        if action == "skip":
            skipped.append({"material_id": raw.get("material_id"), "reason": raw.get("reason") or "skip"})
            continue
        source = Path(str(raw.get("source_path") or "")).expanduser().resolve()
        if not source.is_file():
            skipped.append({"material_id": raw.get("material_id"), "warning": f"源文件不存在: {source}"})
            continue
        target = Path(str(raw.get("target_path") or "")).expanduser().resolve()
        if not is_relative_to(target, output_dir):
            raise ValueError(f"目标路径不在 output_dir 中: {target}")
        target = unique_target(target)
        if action == "clip":
            start_sec = float(raw.get("start_sec"))
            end_sec = float(raw.get("end_sec"))
            if end_sec <= start_sec:
                raise ValueError(f"clip 时间无效: {raw.get('material_id')}")
            clip_item(ffmpeg or "ffmpeg", source, target, start_sec, end_sec)
        elif action == "copy":
            copy_item(source, target)
        else:
            skipped.append({"material_id": raw.get("material_id"), "warning": f"未知 action: {action}"})
            continue
        executed.append(
            {
                "material_id": raw.get("material_id"),
                "action": action,
                "source_path": str(source),
                "target_path": str(target),
            }
        )

    result = {
        "ok": True,
        "plan": str(plan_path),
        "output_dir": str(output_dir),
        "executed_count": len(executed),
        "skipped_count": len(skipped),
        "executed": executed,
        "skipped": skipped,
    }
    if args.report:
        report = Path(args.report).expanduser().resolve()
        write_json(report, result)
        result["report"] = str(report)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply a confirmed xycut-sucai material organize plan.")
    parser.add_argument("plan", help="Organize plan JSON file.")
    parser.add_argument("--output-dir", help="Override output directory when plan omits it.")
    parser.add_argument("--ffmpeg", help="Explicit ffmpeg executable path.")
    parser.add_argument("--confirm", action="store_true", help="Required to execute copy/clip operations.")
    parser.add_argument("--report", help="Write execution report JSON.")
    args = parser.parse_args()

    try:
        result = apply_plan(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("ok") else 2
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
