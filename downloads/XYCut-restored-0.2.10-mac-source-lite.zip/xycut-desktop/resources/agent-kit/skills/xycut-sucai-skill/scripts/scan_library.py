from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from common import (
    MISSING_FFMPEG_MESSAGE,
    connect_db,
    default_db_path,
    ensure_collection_path,
    ensure_library,
    ffprobe_video,
    image_size,
    init_schema,
    material_id_for,
    media_type,
    orientation,
    resolve_ffprobe,
    sha256_file,
    upsert_material,
    write_json,
)


def collection_parts(root: Path, path: Path, classified: bool) -> list[str]:
    if not classified:
        return ["未分类"]
    rel_parent = path.relative_to(root).parent
    parts = [part for part in rel_parent.parts if part not in ("", ".")]
    return parts or ["未分类"]


def scan(args: argparse.Namespace) -> dict[str, Any]:
    root = Path(args.root).expanduser().resolve()
    if not root.is_dir():
        raise FileNotFoundError("素材目录不存在: %s" % root)

    db_path = Path(args.db).expanduser().resolve()
    ffprobe = resolve_ffprobe(args.ffprobe)
    files = [path for path in sorted(root.rglob("*")) if path.is_file() and media_type(path)]
    has_video = any(media_type(path) == "video" for path in files)
    if has_video and not ffprobe:
        return {"ok": False, "message": MISSING_FFMPEG_MESSAGE, "missing": "ffprobe"}

    warnings = []
    inserted_or_changed = 0
    with connect_db(db_path) as conn:
        init_schema(conn)
        preserved_library_root = None
        if getattr(args, "preserve_library_root", False) and args.library_id:
            row = conn.execute("SELECT root_path FROM libraries WHERE id = ?", (args.library_id,)).fetchone()
            preserved_library_root = str(row["root_path"]) if row and row["root_path"] else None
        library_id = ensure_library(conn, root, args.library_name, args.library_id, args.description)
        if preserved_library_root:
            conn.execute("UPDATE libraries SET root_path = ? WHERE id = ?", (preserved_library_root, library_id))
        for path in files:
            kind = media_type(path)
            rel = path.relative_to(root).as_posix()
            width = height = duration_sec = None
            fps = None
            if kind == "video" and ffprobe:
                try:
                    probed = ffprobe_video(path, ffprobe)
                    width = probed.get("width")
                    height = probed.get("height")
                    duration_sec = probed.get("duration_sec")
                    fps = probed.get("fps")
                except Exception as exc:
                    warnings.append({"path": str(path), "warning": "视频探测失败: %s" % exc})
            elif kind == "image":
                width, height = image_size(path)

            parts = collection_parts(root, path, not args.unclassified)
            collection_id = ensure_collection_path(conn, library_id, parts, args.collection_type)
            fingerprint = sha256_file(path)
            item = {
                "id": material_id_for(conn, library_id, rel),
                "library_id": library_id,
                "collection_id": collection_id,
                "path": str(path),
                "relative_path": rel,
                "file_name": path.name,
                "type": kind,
                "duration_sec": duration_sec,
                "width": width,
                "height": height,
                "orientation": orientation(width, height),
                "fingerprint": fingerprint,
            }
            if fps is not None:
                item["fps"] = fps
            if upsert_material(conn, item):
                inserted_or_changed += 1
        conn.commit()

    result = {
        "ok": True,
        "db_path": str(db_path),
        "library_id": library_id,
        "root_path": str(root),
        "total": len(files),
        "inserted_or_changed": inserted_or_changed,
        "warnings": warnings,
    }
    if args.legacy_cache:
        cache = {
            "schema_version": 1,
            "library_id": library_id,
            "material_dir": str(root),
            "materials": [
                {
                    "id": material_id_for(conn, library_id, path.relative_to(root).as_posix()),
                    "name": path.name,
                    "relative_path": path.relative_to(root).as_posix(),
                    "source_path": str(path),
                    "type": media_type(path),
                    "folder_tags": collection_parts(root, path, not args.unclassified),
                }
                for path in files
            ],
        }
        cache_path = root / "material-cache.json"
        write_json(cache_path, cache)
        result["legacy_cache"] = str(cache_path)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Scan an image/video material library into xycut-sucai.db.")
    parser.add_argument("root", help="Material library root directory.")
    parser.add_argument("--db", default=str(default_db_path()), help="SQLite DB path.")
    parser.add_argument("--library-id", help="Optional stable library id.")
    parser.add_argument("--library-name", help="Library display name. Defaults to root folder name.")
    parser.add_argument("--description", help="Library description.")
    parser.add_argument("--ffprobe", help="Explicit ffprobe executable path.")
    parser.add_argument("--unclassified", action="store_true", help="Put every material into 未分类.")
    parser.add_argument("--collection-type", default="folder", help="Collection type label.")
    parser.add_argument("--legacy-cache", action="store_true", help="Also export root/material-cache.json.")
    parser.add_argument("--preserve-library-root", action="store_true", help="Keep existing library root_path when scanning into an existing library id.")
    args = parser.parse_args()

    try:
        result = scan(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("ok") else 2
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
