from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Optional

from common import (
    connect_db,
    default_db_path,
    embedding_id_for,
    ffprobe_video,
    image_size,
    init_schema,
    media_type,
    next_table_id,
    normalize_keywords,
    now_text,
    parse_vector,
    read_json,
    resolve_ffmpeg,
    resolve_ffprobe,
    segment_id_for,
    sha256_file,
    source_hash,
    validate_score,
)


def load_items(value: str) -> list[dict[str, Any]]:
    text = str(value).strip()
    if text.startswith("{") or text.startswith("["):
        data = json.loads(text)
    else:
        path = Path(text)
        data = read_json(path) if path.is_file() else json.loads(text)
    if isinstance(data, dict) and isinstance(data.get("items"), list):
        data = data["items"]
    elif isinstance(data, dict) and isinstance(data.get("analyses"), list):
        data = data["analyses"]
    elif isinstance(data, dict) and isinstance(data.get("materials"), list):
        data = data["materials"]
    elif isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        raise ValueError("analysis 必须是 JSON object 或 object 数组")
    items = []
    for item in data:
        if not isinstance(item, dict):
            raise ValueError("analysis 数组里的每一项都必须是 object")
        items.append(item)
    return items


def save_embedding(conn, material_id: str, segment_id: Any, payload: dict[str, Any]) -> bool:
    vector_value = payload.get("embedding_json") if "embedding_json" in payload else payload.get("embedding")
    vector = parse_vector(vector_value)
    if not vector:
        return False
    provider = str(payload.get("provider") or "").strip()
    model = str(payload.get("model") or "").strip()
    if not provider or not model:
        raise ValueError("写入 embedding_json 时必须同时提供 provider 和 model")
    source_text = str(payload.get("source_text") or "").strip()
    if not source_text:
        source_text = str(payload.get("summary") or "").strip()
    if not source_text:
        raise ValueError("写入 embedding_json 时必须提供 source_text 或 summary")
    hashed = source_hash(source_text)
    now = now_text()
    conn.execute(
        """
        INSERT INTO material_embeddings(
          id, material_id, segment_id, provider, model, source_text, source_hash,
          embedding_json, dimension, created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          source_text = excluded.source_text,
          source_hash = excluded.source_hash,
          embedding_json = excluded.embedding_json,
          dimension = excluded.dimension,
          updated_at = excluded.updated_at
        """,
        (
            embedding_id_for(conn, material_id, segment_id, provider, model, hashed),
            material_id,
            segment_id,
            provider,
            model,
            source_text,
            hashed,
            json.dumps(vector, ensure_ascii=False, separators=(",", ":")),
            len(vector),
            now,
            now,
        ),
    )
    return True


def validate_analysis(item: dict[str, Any]) -> dict[str, Any]:
    material_id = str(item.get("material_id") or item.get("id") or "").strip()
    source_id = str(item.get("source_id") or "").strip()
    if not source_id and material_id.startswith("src_"):
        source_id = material_id
    if not material_id and source_id:
        material_id = source_id
    if not material_id:
        raise ValueError("material_id 必填")
    summary = str(item.get("summary") or "").strip()
    if not summary:
        raise ValueError("summary 必填: %s" % material_id)
    keywords = normalize_keywords(item.get("keywords"))
    score = validate_score(item.get("quality_score"))
    segments = item.get("segments") or []
    if not isinstance(segments, list):
        raise ValueError("segments 必须是数组: %s" % material_id)
    analysis_level = str(item.get("analysis_level") or "").strip()
    save_mode = str(item.get("save_mode") or "").strip()
    return {
        "material_id": material_id,
        "source_id": source_id,
        "analysis_level": analysis_level,
        "save_mode": save_mode,
        "summary": summary,
        "keywords": keywords,
        "quality_score": score,
        "segments": segments,
        "embedding": item.get("embedding") or {
            key: item.get(key)
            for key in ("provider", "model", "source_text", "embedding_json", "embedding")
            if key in item
        },
    }


def safe_path_part(value: str) -> str:
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", str(value or "")).strip(" ._")
    return text or "material"


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem or "material"
    suffix = path.suffix
    for index in range(2, 10000):
        candidate = path.with_name(f"{stem}-{index}{suffix}")
        if not candidate.exists():
            return candidate
    raise ValueError("无法生成可用素材文件名: %s" % path)


def material_bucket_dir(material_id: str) -> str:
    match = re.search(r"(\d+)$", material_id)
    number = int(match.group(1)) if match else 1
    bucket = ((max(1, number) - 1) // 100) + 1
    return f"{bucket:03d}"


def should_split_source_video(source, item: dict[str, Any]) -> bool:
    if not source or str(source["type"] or "") != "video":
        return False
    return item["save_mode"] == "split_only" or item["analysis_level"] in {"precise", "precise_split"}


def material_info(path: Path, kind: str) -> dict[str, Any]:
    if kind == "video":
        ffprobe = resolve_ffprobe()
        if ffprobe:
            try:
                return ffprobe_video(path, ffprobe)
            except Exception:
                return {"duration_sec": None, "width": None, "height": None, "orientation": ""}
    width, height = image_size(path) if kind == "image" else (None, None)
    orientation = ""
    if width and height:
        orientation = "portrait" if height > width else "landscape" if width > height else "square"
    return {"duration_sec": None, "width": width, "height": height, "orientation": orientation}


def valid_segment_bounds(segment: dict[str, Any], source_duration: Optional[float]) -> tuple[float, float]:
    start_sec = max(0.0, float(segment.get("start_sec")))
    end_sec = float(segment.get("end_sec"))
    if source_duration is not None:
        end_sec = min(float(source_duration), end_sec)
    if end_sec <= start_sec:
        raise ValueError("segment.end_sec 必须大于 start_sec")
    return round(start_sec, 3), round(end_sec, 3)


def cut_video_segment(ffmpeg: str, source_path: Path, target_path: Path, start_sec: float, end_sec: float) -> None:
    target_path.parent.mkdir(parents=True, exist_ok=True)
    duration = max(0.1, end_sec - start_sec)
    timeout = max(60, int(duration * 4) + 30)
    transcode_command = [
        ffmpeg,
        "-y",
        "-ss",
        f"{start_sec:.3f}",
        "-i",
        str(source_path),
        "-t",
        f"{duration:.3f}",
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "20",
        "-c:a",
        "aac",
        "-b:a",
        "128k",
        "-movflags",
        "+faststart",
        str(target_path),
    ]
    completed = subprocess.run(transcode_command, capture_output=True, text=True, timeout=timeout)
    if completed.returncode != 0 or not target_path.is_file() or target_path.stat().st_size <= 0:
        stderr = (completed.stderr or "").strip()
        raise ValueError("切割视频片段失败: %s" % (stderr[-500:] or target_path))


def insert_completed_material(
    conn,
    *,
    material_id: str,
    library_id: str,
    collection_id: Optional[str],
    target_path: Path,
    library_root: Path,
    original_path: Path,
    original_file_name: str,
    kind: str,
    summary: str,
    keywords: list[str],
    quality_score: float,
) -> None:
    relative_path = str(target_path.relative_to(library_root)).replace("\\", "/")
    info = material_info(target_path, kind)
    now = now_text()
    conn.execute(
        """
        INSERT INTO materials(
          id, library_id, collection_id, path, relative_path, file_name,
          original_path, original_file_name, type,
          duration_sec, width, height, orientation, fingerprint, summary,
          keywords_json, quality_score, analysis_status, embedding_status,
          created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', 'pending', ?, ?)
        """,
        (
            material_id,
            library_id,
            collection_id,
            str(target_path.resolve()),
            relative_path,
            target_path.name,
            str(original_path.resolve()),
            original_file_name,
            kind,
            info.get("duration_sec"),
            info.get("width"),
            info.get("height"),
            info.get("orientation") or "",
            sha256_file(target_path),
            summary,
            json.dumps(keywords, ensure_ascii=False),
            quality_score,
            now,
            now,
        ),
    )


def create_split_materials_from_source(conn, source, item: dict[str, Any], ffmpeg: Optional[str]) -> list[dict[str, Any]]:
    if not ffmpeg:
        raise ValueError("精细分析并分割片段需要 FFmpeg。")
    if not item["segments"]:
        raise ValueError("精细分析并分割片段时，视频必须输出可用 segments。")

    library = conn.execute("SELECT root_path FROM libraries WHERE id = ?", (source["library_id"],)).fetchone()
    if not library:
        raise ValueError("未找到素材库: %s" % source["library_id"])
    library_root = Path(str(library["root_path"])).expanduser()
    library_root.mkdir(parents=True, exist_ok=True)
    original_path = Path(str(source["original_path"])).expanduser()
    if not original_path.is_file():
        raise ValueError("原始素材文件不存在: %s" % original_path)

    source_info = material_info(original_path, "video")
    source_duration = source_info.get("duration_sec")
    created = []
    for index, segment in enumerate(item["segments"], start=1):
        if not isinstance(segment, dict):
            raise ValueError("segment 必须是 object: %s" % item["material_id"])
        start_sec, end_sec = valid_segment_bounds(segment, source_duration)
        segment_summary = str(segment.get("summary") or item["summary"]).strip()
        segment_keywords = normalize_keywords(segment.get("keywords") or item["keywords"])
        segment_score = validate_score(segment.get("quality_score", item["quality_score"]))
        material_id = next_table_id(conn, "materials", "mat", 4)
        target_dir = library_root / material_bucket_dir(material_id)
        target_path = unique_path(target_dir / f"{material_id}.mp4")
        cut_video_segment(ffmpeg, original_path, target_path, start_sec, end_sec)
        insert_completed_material(
            conn,
            material_id=material_id,
            library_id=source["library_id"],
            collection_id=None,
            target_path=target_path,
            library_root=library_root,
            original_path=original_path,
            original_file_name=source["file_name"] or original_path.name,
            kind="video",
            summary=segment_summary,
            keywords=segment_keywords,
            quality_score=segment_score,
        )
        if segment.get("embedding"):
            save_embedding(conn, material_id, None, segment["embedding"])
        created.append({
            "material_id": material_id,
            "source_id": source["id"],
            "segment_index": index,
            "start_sec": start_sec,
            "end_sec": end_sec,
        })
    conn.execute(
        "UPDATE source_materials SET status = 'completed', error_message = '', updated_at = ? WHERE id = ?",
        (now_text(), source["id"]),
    )
    return created


def default_segments_for_material(material, item: dict[str, Any]) -> list[dict[str, Any]]:
    if item["segments"]:
        return item["segments"]
    if str(material["type"] or "") != "video":
        return []
    duration = material["duration_sec"]
    if duration is None:
        return []
    try:
        end_sec = float(duration)
    except Exception:
        return []
    if end_sec <= 0:
        return []
    return [
        {
            "start_sec": 0,
            "end_sec": round(end_sec, 3),
            "summary": item["summary"],
            "keywords": item["keywords"],
            "quality_score": item["quality_score"],
        }
    ]


def create_material_from_source(conn, source, item: dict[str, Any]) -> tuple[str, Optional[str]]:
    library = conn.execute("SELECT root_path FROM libraries WHERE id = ?", (source["library_id"],)).fetchone()
    if not library:
        raise ValueError("未找到素材库: %s" % source["library_id"])
    library_root = Path(str(library["root_path"])).expanduser()
    library_root.mkdir(parents=True, exist_ok=True)
    original_path = Path(str(source["original_path"])).expanduser()
    if not original_path.is_file():
        conn.execute(
            "UPDATE source_materials SET status = 'failed', error_message = ?, updated_at = ? WHERE id = ?",
            ("原始素材文件不存在", now_text(), source["id"]),
        )
        raise ValueError("原始素材文件不存在: %s" % original_path)
    kind = media_type(original_path) or str(source["type"] or "unknown")
    fingerprint = str(source["fingerprint"] or "") or sha256_file(original_path)
    existing = conn.execute(
        "SELECT id FROM materials WHERE library_id = ? AND fingerprint = ? LIMIT 1",
        (source["library_id"], fingerprint),
    ).fetchone()
    if existing:
        return str(existing["id"]), None
    material_id = next_table_id(conn, "materials", "mat", 4)
    file_name = f"{material_id}{original_path.suffix.lower()}"
    target_dir = library_root / material_bucket_dir(material_id)
    target_dir.mkdir(parents=True, exist_ok=True)
    target_path = unique_path(target_dir / file_name)
    file_name = target_path.name
    shutil.copy2(original_path, target_path)
    relative_path = str(target_path.relative_to(library_root)).replace("\\", "/")
    info = material_info(target_path, kind)
    now = now_text()
    conn.execute(
        """
        INSERT INTO materials(
          id, library_id, collection_id, path, relative_path, file_name,
          original_path, original_file_name, type,
          duration_sec, width, height, orientation, fingerprint, summary,
          keywords_json, quality_score, analysis_status, embedding_status,
          created_at, updated_at
        )
        VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', '[]', NULL, 'pending', 'pending', ?, ?)
        """,
        (
            material_id,
            source["library_id"],
            str(target_path.resolve()),
            relative_path,
            file_name,
            str(original_path.resolve()),
            original_path.name,
            kind,
            info.get("duration_sec"),
            info.get("width"),
            info.get("height"),
            info.get("orientation") or "",
            fingerprint,
            now,
            now,
        ),
    )
    return material_id, None


def save(args: argparse.Namespace) -> dict[str, Any]:
    db_path = Path(args.db).expanduser().resolve()
    items = [validate_analysis(item) for item in load_items(args.analysis)]
    saved = []
    ffmpeg = resolve_ffmpeg(args.ffmpeg)
    with connect_db(db_path) as conn:
        init_schema(conn)
        for item in items:
            material = conn.execute("SELECT * FROM materials WHERE id = ?", (item["material_id"],)).fetchone()
            source = None
            if not material:
                source_id = item.get("source_id") or item["material_id"]
                source = conn.execute("SELECT * FROM source_materials WHERE id = ?", (source_id,)).fetchone()
                if not source:
                    raise ValueError("未在素材库 DB 中找到素材或待整理来源: %s" % item["material_id"])
                if should_split_source_video(source, item):
                    try:
                        split_items = create_split_materials_from_source(conn, source, item, ffmpeg)
                        saved.append({
                            "source_id": source["id"],
                            "save_mode": "split_only",
                            "materials": split_items,
                            "segments": len(split_items),
                        })
                    except Exception as exc:
                        conn.execute(
                            "UPDATE source_materials SET status = 'failed', error_message = ?, updated_at = ? WHERE id = ?",
                            (str(exc), now_text(), source["id"]),
                        )
                        saved.append({
                            "source_id": source["id"],
                            "save_mode": "split_only",
                            "status": "failed",
                            "error": str(exc),
                        })
                    continue
                material_id, source_collection_id = create_material_from_source(conn, source, item)
                item["material_id"] = material_id
                material = conn.execute("SELECT * FROM materials WHERE id = ?", (item["material_id"],)).fetchone()
                collection_id = source_collection_id
            else:
                collection_id = material["collection_id"]
            now = now_text()
            embedding_saved = False
            if item.get("embedding"):
                embedding_saved = save_embedding(conn, item["material_id"], None, item["embedding"])
            conn.execute(
                """
                UPDATE materials
                SET collection_id = ?, summary = ?, keywords_json = ?, quality_score = ?,
                    analysis_status = 'completed',
                    embedding_status = CASE WHEN ? THEN 'completed' ELSE embedding_status END,
                    updated_at = ?
                WHERE id = ?
                """,
                (
                    collection_id,
                    item["summary"],
                    json.dumps(item["keywords"], ensure_ascii=False),
                    item["quality_score"],
                    1 if embedding_saved else 0,
                    now,
                    item["material_id"],
                ),
            )
            if source:
                conn.execute(
                    "UPDATE source_materials SET status = 'completed', error_message = '', updated_at = ? WHERE id = ?",
                    (now, source["id"]),
                )
            conn.execute("DELETE FROM material_segments WHERE material_id = ?", (item["material_id"],))
            segment_count = 0
            for segment in default_segments_for_material(material, item):
                if not isinstance(segment, dict):
                    raise ValueError("segment 必须是 object: %s" % item["material_id"])
                start_sec = float(segment.get("start_sec"))
                end_sec = float(segment.get("end_sec"))
                if end_sec <= start_sec:
                    raise ValueError("segment.end_sec 必须大于 start_sec: %s" % item["material_id"])
                segment_summary = str(segment.get("summary") or "").strip()
                segment_keywords = normalize_keywords(segment.get("keywords"))
                segment_score = validate_score(segment.get("quality_score"))
                seg_id = segment_id_for(conn, item["material_id"], start_sec, end_sec, segment_summary)
                conn.execute(
                    """
                    INSERT INTO material_segments(
                      id, material_id, start_sec, end_sec, summary, keywords_json,
                      quality_score, created_at, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        seg_id,
                        item["material_id"],
                        start_sec,
                        end_sec,
                        segment_summary,
                        json.dumps(segment_keywords, ensure_ascii=False),
                        segment_score,
                        now,
                        now,
                    ),
                )
                if segment.get("embedding"):
                    save_embedding(conn, item["material_id"], seg_id, segment["embedding"])
                segment_count += 1
            saved.append({"material_id": item["material_id"], "segments": segment_count})
        conn.commit()
    return {"ok": True, "db_path": str(db_path), "saved_count": len(saved), "saved": saved}


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Agent material analysis JSON and save it to DB.")
    parser.add_argument("analysis", help="Analysis JSON string or JSON file path.")
    parser.add_argument("--db", default=str(default_db_path()), help="SQLite DB path.")
    parser.add_argument("--ffmpeg", help="Explicit ffmpeg executable path for precise split mode.")
    args = parser.parse_args()

    try:
        print(json.dumps(save(args), ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
