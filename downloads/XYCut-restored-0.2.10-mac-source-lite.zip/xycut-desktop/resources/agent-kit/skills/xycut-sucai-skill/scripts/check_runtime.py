from __future__ import annotations

import argparse
import json
import platform
import sqlite3
import sys
from pathlib import Path

from common import MISSING_FFMPEG_MESSAGE, default_db_path, executable_version, resolve_ffmpeg, resolve_ffprobe


def main() -> int:
    parser = argparse.ArgumentParser(description="Check local runtime for xycut-sucai-skill.")
    parser.add_argument("--db", default=str(default_db_path()), help="SQLite DB path.")
    parser.add_argument("--ffmpeg", help="Explicit ffmpeg executable path.")
    parser.add_argument("--ffprobe", help="Explicit ffprobe executable path.")
    args = parser.parse_args()

    ffmpeg = resolve_ffmpeg(args.ffmpeg)
    ffprobe = resolve_ffprobe(args.ffprobe)
    ok = bool(ffmpeg and ffprobe)
    payload = {
        "ok": ok,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "sqlite": sqlite3.sqlite_version,
        "db_path": str(Path(args.db).expanduser()),
        "ffmpeg_path": ffmpeg,
        "ffmpeg_version": executable_version(ffmpeg),
        "ffprobe_path": ffprobe,
        "ffprobe_version": executable_version(ffprobe),
    }
    if not ok:
        payload["message"] = MISSING_FFMPEG_MESSAGE
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
