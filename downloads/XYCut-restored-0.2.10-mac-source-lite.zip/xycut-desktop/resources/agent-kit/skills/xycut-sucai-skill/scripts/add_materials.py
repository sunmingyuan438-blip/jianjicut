from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Any

from common import connect_db, default_db_path, init_schema, media_type, sha256_file
from scan_library import scan


def safe_name(value: str) -> str:
    clean = "".join("_" if ch in '<>:"/\\|?*' or ord(ch) < 32 else ch for ch in value).strip(" ._")
    return clean or "material"


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    for index in range(2, 10000):
        candidate = path.with_name(f"{stem}-{index}{suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"无法生成可用文件名: {path}")


def iter_media_sources(source: Path) -> list[Path]:
    if source.is_file():
        return [source] if media_type(source) else []
    if source.is_dir():
        return [path for path in sorted(source.rglob("*")) if path.is_file() and media_type(path)]
    return []


def existing_fingerprints(db_path: Path, library_id: str) -> set[str]:
    with connect_db(db_path) as conn:
        init_schema(conn)
        rows = conn.execute("SELECT fingerprint FROM materials WHERE library_id = ?", (library_id,)).fetchall()
    return {str(row["fingerprint"]) for row in rows if row["fingerprint"]}


def copy_sources(args: argparse.Namespace) -> dict[str, Any]:
    db_path = Path(args.db).expanduser().resolve()
    target_root = Path(args.library_root).expanduser().resolve()
    target_root.mkdir(parents=True, exist_ok=True)
    known_fingerprints = existing_fingerprints(db_path, args.library_id)

    copied = []
    skipped = []
    for raw_source in args.sources:
        source = Path(raw_source).expanduser().resolve()
        media_files = iter_media_sources(source)
        if not media_files:
            skipped.append({"source": str(source), "reason": "没有找到图片或视频素材"})
            continue
        source_label = safe_name(source.stem if source.is_file() else source.name)
        for file_path in media_files:
            fingerprint = sha256_file(file_path)
            if fingerprint in known_fingerprints:
                skipped.append({"source": str(file_path), "reason": "素材库中已存在相同文件"})
                continue
            if source.is_dir():
                relative = file_path.relative_to(source)
                target_path = target_root / source_label / Path(*[safe_name(part) for part in relative.parts])
            else:
                target_path = target_root / safe_name(file_path.name)
            target_path = unique_path(target_path)
            target_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(file_path, target_path)
            known_fingerprints.add(fingerprint)
            copied.append({"source": str(file_path), "target": str(target_path), "fingerprint": fingerprint})

    scan_args = argparse.Namespace(
        root=str(target_root),
        db=str(db_path),
        ffprobe=args.ffprobe,
        library_id=args.library_id,
        library_name=args.library_name,
        description=args.description,
        unclassified=False,
        collection_type="folder",
        legacy_cache=False,
    )
    scan_result = scan(scan_args)
    return {
        "ok": True,
        "db_path": str(db_path),
        "library_id": args.library_id,
        "library_root": str(target_root),
        "copied_count": len(copied),
        "skipped_count": len(skipped),
        "copied": copied,
        "skipped": skipped,
        "scan": scan_result,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Copy source media into a stable xycut sucai library directory and scan it into DB.")
    parser.add_argument("sources", nargs="+", help="Source files or folders.")
    parser.add_argument("--db", default=str(default_db_path()), help="SQLite DB path.")
    parser.add_argument("--library-id", required=True, help="Target library id.")
    parser.add_argument("--library-name", required=True, help="Target library display name.")
    parser.add_argument("--library-root", required=True, help="Stable target library directory.")
    parser.add_argument("--description", default="", help="Library description.")
    parser.add_argument("--ffprobe", help="Explicit ffprobe executable path.")
    args = parser.parse_args()

    try:
        print(json.dumps(copy_sources(args), ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
