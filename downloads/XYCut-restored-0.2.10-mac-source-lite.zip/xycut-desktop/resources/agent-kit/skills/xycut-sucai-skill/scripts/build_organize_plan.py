from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Optional

from common import connect_db, default_db_path, init_schema, read_json, write_json


def safe_category(value: Any) -> str:
    text = str(value or "").strip().replace("\\", "/")
    parts = [re.sub(r'[<>:"|?*\x00-\x1f]+', "_", part).strip(" .") for part in text.split("/") if part.strip()]
    return "/".join(part for part in parts if part) or "未分类"


def load_items(value: str) -> list[dict[str, Any]]:
    text = str(value).strip()
    if text.startswith("{") or text.startswith("["):
        data = json.loads(text)
    else:
        path = Path(text).expanduser()
        data = read_json(path.resolve()) if path.is_file() else json.loads(text)
    if isinstance(data, dict):
        for key in ("items", "analyses", "materials"):
            if isinstance(data.get(key), list):
                data = data[key]
                break
        else:
            data = [data]
    if not isinstance(data, list):
        raise ValueError("analysis 必须是 object 或 object 数组")
    result = []
    for item in data:
        if not isinstance(item, dict):
            raise ValueError("analysis 数组中的每一项都必须是 object")
        result.append(item)
    return result


def material_by_id(conn, material_id: str) -> Optional[dict[str, Any]]:
    row = conn.execute("SELECT * FROM materials WHERE id = ?", (material_id,)).fetchone()
    return dict(row) if row else None


def number_or_none(value: Any) -> Optional[float]:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def build_plan(args: argparse.Namespace) -> dict[str, Any]:
    db_path = Path(args.db).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    raw_items = load_items(args.analysis)
    items = []
    warnings = []

    with connect_db(db_path) as conn:
        init_schema(conn)
        for raw in raw_items:
            material_id = str(raw.get("material_id") or raw.get("id") or "").strip()
            if not material_id:
                warnings.append({"warning": "跳过缺少 material_id 的分析项", "item": raw})
                continue
            material = material_by_id(conn, material_id)
            if not material:
                warnings.append({"material_id": material_id, "warning": "素材库 DB 中找不到该素材，已跳过"})
                continue
            category = safe_category(raw.get("category") or raw.get("target_category"))
            action = str(raw.get("action") or "").strip().lower()
            start_sec = number_or_none(raw.get("start_sec"))
            end_sec = number_or_none(raw.get("end_sec"))
            if action not in {"copy", "clip", "skip"}:
                action = "clip" if start_sec is not None and end_sec is not None else "copy"
            if action == "clip":
                if material.get("type") != "video":
                    warnings.append({"material_id": material_id, "warning": "非视频素材不能 clip，已改为 copy"})
                    action = "copy"
                elif start_sec is None or end_sec is None or end_sec <= start_sec:
                    warnings.append({"material_id": material_id, "warning": "clip 缺少有效 start_sec/end_sec，已改为 copy"})
                    action = "copy"
            extension = Path(str(material["path"])).suffix
            target_name = str(raw.get("target_name") or material.get("file_name") or f"{material_id}{extension}").strip()
            target_name = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", target_name).strip(" .") or f"{material_id}{extension}"
            item = {
                "material_id": material_id,
                "source_path": material["path"],
                "target_category": category,
                "target_path": str(output_dir.joinpath(*category.split("/"), target_name)),
                "action": action,
                "type": material.get("type") or "",
                "summary": str(raw.get("summary") or material.get("summary") or "").strip(),
                "keywords": raw.get("keywords") if isinstance(raw.get("keywords"), list) else [],
            }
            if action == "clip":
                item["start_sec"] = start_sec
                item["end_sec"] = end_sec
            if raw.get("reason"):
                item["reason"] = str(raw.get("reason"))
            items.append(item)

    plan = {
        "ok": True,
        "schema_version": 1,
        "purpose": "xycut_sucai_organize_plan",
        "mode": args.mode,
        "db_path": str(db_path),
        "output_dir": str(output_dir),
        "requires_client_confirmation": True,
        "items": items,
        "warnings": warnings,
    }
    if args.output:
        output = Path(args.output).expanduser().resolve()
        write_json(output, plan)
        plan["output"] = str(output)
    return plan


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a reviewable material organize plan from Agent analysis JSON.")
    parser.add_argument("analysis", help="Agent analysis JSON string or file path.")
    parser.add_argument("--db", default=str(default_db_path()), help="SQLite DB path.")
    parser.add_argument("--output-dir", required=True, help="Organized material library output directory.")
    parser.add_argument("--mode", choices=["copy", "copy_or_clip"], default="copy_or_clip")
    parser.add_argument("--output", help="Output organize plan JSON file.")
    args = parser.parse_args()

    try:
        print(json.dumps(build_plan(args), ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
