from __future__ import annotations

import argparse
import json
from pathlib import Path

from common import connect_db, default_db_path, init_schema


def main() -> int:
    parser = argparse.ArgumentParser(description="Initialize xycut sucai SQLite database.")
    parser.add_argument("--db", default=str(default_db_path()), help="SQLite DB path.")
    args = parser.parse_args()

    db_path = Path(args.db).expanduser().resolve()
    with connect_db(db_path) as conn:
        init_schema(conn)
        tables = [
            row["name"]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            ).fetchall()
        ]
    print(json.dumps({"ok": True, "db_path": str(db_path), "tables": tables}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
