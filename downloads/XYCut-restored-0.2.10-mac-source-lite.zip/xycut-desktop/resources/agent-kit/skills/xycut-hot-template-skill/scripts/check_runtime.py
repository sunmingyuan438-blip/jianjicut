from __future__ import annotations

import json
import os
import platform
import sys
from pathlib import Path
from typing import Optional


def runtime_root() -> Path:
    configured = os.environ.get("XYCUT_HOT_TEMPLATE_RUNTIME_DIR", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    common_root = os.environ.get("XYCUT_AGENT_RUNTIME_DIR", "").strip()
    if common_root:
        return Path(common_root).expanduser().resolve()
    return (Path.cwd() / ".xycut-agent-runtime").resolve()


def python_bin(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def client_runtime_python() -> Optional[Path]:
    explicit_python = os.environ.get("XYCUT_CLIENT_PYTHON", "").strip()
    if explicit_python:
        path = Path(explicit_python).expanduser()
        if path.is_file():
            return path.resolve()

    runtime_dir = os.environ.get("XYCUT_PYTHON_RUNTIME_DIR", "").strip()
    candidates: list[Path] = []
    if runtime_dir:
        candidates.append(Path(runtime_dir).expanduser())
    if os.name == "nt":
        local_app_data = os.environ.get("LOCALAPPDATA", "").strip()
        if local_app_data:
            candidates.append(Path(local_app_data) / "com.xiaoyuan.jianji" / "runtime" / "python39")

    for root in candidates:
        python = root / ("python.exe" if os.name == "nt" else "bin/python3")
        if python.is_file():
            return python.resolve()
    return None


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    runtime = runtime_root()
    venv_dir = runtime / ".venv"
    venv_python = python_bin(venv_dir)
    fallback_python = client_runtime_python()
    payload = {
        "ok": True,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "tool_root": str(root),
        "runtime_root": str(runtime),
        "venv": str(venv_dir),
        "venv_python": str(venv_python),
        "venv_python_exists": venv_python.is_file(),
        "fallback_python": str(fallback_python) if fallback_python else None,
        "fallback_python_exists": bool(fallback_python and fallback_python.is_file()),
        "recommended_python": str(venv_python if venv_python.is_file() else fallback_python) if (venv_python.is_file() or fallback_python) else None,
        "requirements": str(root / "requirements.txt"),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
