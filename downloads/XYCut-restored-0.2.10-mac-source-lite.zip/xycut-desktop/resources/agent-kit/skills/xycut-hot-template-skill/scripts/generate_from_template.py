from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

VIDEO_EXTS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".flv", ".m4v", ".3gp"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def media_type(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in VIDEO_EXTS:
        return "video"
    if ext in IMAGE_EXTS:
        return "photo"
    return "unknown"


def media_type_matches(expected: str, actual: str) -> bool:
    if not expected or actual == "unknown":
        return True
    if expected in {"photo", "video"} and actual in {"photo", "video"}:
        return True
    return expected == actual


def expected_orientation(width: int, height: int) -> str:
    if width <= 0 or height <= 0:
        return ""
    return "portrait" if height >= width else "landscape"


def executable_name(base: str) -> str:
    return f"{base}.exe" if os.name == "nt" else base


def find_named_file_in_dir(dir_path: Path, file_name: str, depth: int = 0) -> Path | None:
    if depth > 5 or not dir_path.is_dir():
        return None
    try:
        entries = list(dir_path.iterdir())
    except OSError:
        return None
    for path in entries:
        if path.is_file() and path.name.lower() == file_name.lower():
            return path
        if path.is_dir():
            found = find_named_file_in_dir(path, file_name, depth + 1)
            if found:
                return found
    return None


def find_media_tool(command: str) -> str | None:
    env_key = f"XYCUT_{command.upper()}_PATH"
    env_path = os.environ.get(env_key, "").strip().strip('"')
    if env_path and Path(env_path).is_file():
        return env_path

    found = shutil.which(command)
    if found:
        return found

    command_name = executable_name(command)
    runtime_roots: list[Path] = []
    local_app_data = os.environ.get("LOCALAPPDATA", "").strip()
    if local_app_data:
        runtime_roots.append(Path(local_app_data) / "com.xiaoyuan.jianji" / "runtime" / "ffmpeg")
    home = Path.home()
    runtime_roots.append(home / ".local" / "share" / "com.xiaoyuan.jianji" / "runtime" / "ffmpeg")

    for root in runtime_roots:
        found_path = find_named_file_in_dir(root, command_name)
        if found_path:
            return str(found_path)
    return None


def probe_video(path: Path) -> dict[str, Any]:
    ffprobe = find_media_tool("ffprobe")
    if not ffprobe:
        return {"warnings": ["未找到 ffprobe，已跳过视频尺寸和时长检查。"]}
    command = [
        ffprobe,
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=width,height,duration:format=duration",
        "-of",
        "json",
        str(path),
    ]
    try:
        completed = subprocess.run(command, check=True, capture_output=True, text=True, timeout=10)
        data = json.loads(completed.stdout or "{}")
    except Exception as exc:
        return {"warnings": [f"视频探测失败，已跳过尺寸和时长检查: {exc}"]}
    stream = (data.get("streams") or [{}])[0]
    duration_seconds = stream.get("duration") or data.get("format", {}).get("duration") or 0
    try:
        duration_ms = int(float(duration_seconds) * 1000)
    except (TypeError, ValueError):
        duration_ms = 0
    width = int(stream.get("width") or 0)
    height = int(stream.get("height") or 0)
    return {
        "duration_ms": duration_ms,
        "width": width,
        "height": height,
        "orientation": expected_orientation(width, height),
        "warnings": [],
    }


def probe_media(path: Path, actual_type: str) -> dict[str, Any]:
    if actual_type == "video":
        return probe_video(path)
    return {"warnings": ["图片素材暂不探测尺寸。"] if actual_type == "photo" else []}


def plan_items(plan: dict[str, Any], key: str) -> list[dict[str, Any]]:
    values = plan.get(key)
    return [item for item in values if isinstance(item, dict)] if isinstance(values, list) else []


def slot_index(item: dict[str, Any]) -> int:
    try:
        return int(item.get("slot_index") or item.get("index") or 0)
    except (TypeError, ValueError):
        return 0


def positive_slot_indices(slots: Any) -> set[int]:
    output: set[int] = set()
    if not isinstance(slots, list):
        return output
    for slot in slots:
        if not is_enabled_slot(slot):
            continue
        try:
            index = int(slot.get("index") or 0)
        except (TypeError, ValueError):
            continue
        if index > 0:
            output.add(index)
    return output


def slot_by_index(slots: Any) -> dict[int, dict[str, Any]]:
    output: dict[int, dict[str, Any]] = {}
    if not isinstance(slots, list):
        return output
    for slot in slots:
        if not is_enabled_slot(slot):
            continue
        try:
            index = int(slot.get("index") or 0)
        except (TypeError, ValueError):
            continue
        if index > 0:
            output[index] = slot
    return output


def is_enabled_slot(slot: Any) -> bool:
    return isinstance(slot, dict) and slot.get("enabled") is not False


def to_positive_int(value: Any) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return 0
    return number if number > 0 else 0


def text_visible_chars(text: str) -> int:
    units = 0
    has_visible = False
    for char in str(text or ""):
        if char.isspace():
            continue
        has_visible = True
        units += 1 if ord(char) < 128 else 2
    count = units // 2
    return max(1, count) if has_visible else 0


def slot_original_chars(slot: dict[str, Any]) -> int:
    return text_visible_chars(str(slot.get("original_text") or ""))


def text_char_range(slot: dict[str, Any]) -> tuple[int, int]:
    explicit_max = 0
    for key in ("max_chars", "limit_chars", "char_limit", "slot_max_chars"):
        limit = to_positive_int(slot.get(key))
        if limit:
            explicit_max = limit
            break

    suggest_text = str(slot.get("suggest_chars") or "")
    numbers = [int(value) for value in re.findall(r"\d+", suggest_text)]
    suggest_min = min(numbers) if len(numbers) >= 2 else 0
    suggest_max = max(numbers) if numbers else 0
    original_count = slot_original_chars(slot)
    original_min = max(1, int(original_count * 0.9)) if original_count else 0
    char_limit = explicit_max or suggest_max or original_count
    if original_count:
        char_limit = min(char_limit, original_count) if char_limit else original_count
    suggest_min = max(suggest_min, original_min)
    if suggest_min and char_limit and suggest_min > char_limit:
        suggest_min = char_limit
    return suggest_min, char_limit


def validate_plan(
    template_dir: Path,
    template_config_file: Path,
    draft_output_dir: Path,
    plan_path: Path,
) -> dict[str, Any]:
    config = read_json(template_config_file)
    plan = read_json(plan_path)
    if not isinstance(config, dict) or not isinstance(plan, dict):
        raise ValueError("模板参数文件和生成计划必须是 JSON object")

    if not template_dir.is_dir():
        raise FileNotFoundError(f"找不到模板目录: {template_dir}")
    source_content_path = template_dir / "preset_draft" / "draft_content.json"
    if not source_content_path.is_file():
        raise FileNotFoundError(f"找不到模板 draft_content.json: {source_content_path}")

    text_slots = config.get("text_slots") if isinstance(config.get("text_slots"), list) else []
    media_slots = config.get("media_slots") if isinstance(config.get("media_slots"), list) else []
    text_slot_indices = positive_slot_indices(text_slots)
    text_slot_map = slot_by_index(text_slots)
    media_slot_indices = positive_slot_indices(media_slots)
    media_slot_map = slot_by_index(media_slots)

    text_report: list[dict[str, Any]] = []
    seen_text_indices: set[int] = set()
    for item in plan_items(plan, "text_replacements"):
        index = slot_index(item)
        duplicate = index in seen_text_indices
        if index > 0:
            seen_text_indices.add(index)
        text = str(item.get("text") or "")
        slot = text_slot_map.get(index, {})
        char_count = text_visible_chars(text)
        char_min, char_limit = text_char_range(slot)
        under_limit = bool(char_min and char_count < char_min)
        over_limit = bool(char_limit and char_count > char_limit)
        text_report.append(
            {
                "slot_index": index,
                "status": "ok" if index in text_slot_indices and text and not duplicate and not under_limit and not over_limit else "invalid",
                "chars": char_count,
                "char_min": char_min,
                "char_limit": char_limit,
                "under_limit": under_limit,
                "over_limit": over_limit,
                "suggest_chars": slot.get("suggest_chars") or "",
                "text": text,
            }
        )

    media_report: list[dict[str, Any]] = []
    seen_media_indices: set[int] = set()
    for item in plan_items(plan, "media_replacements"):
        index = slot_index(item)
        duplicate = index in seen_media_indices
        if index > 0:
            seen_media_indices.add(index)
        raw_path = str(item.get("file_path") or "").strip().strip('"')
        file_path = Path(raw_path)
        exists = file_path.is_file()
        actual_media_type = media_type(file_path)
        slot = media_slot_map.get(index, {})
        expected_media_type = str(slot.get("material_type") or "")
        expected_slot_orientation = str(slot.get("orientation") or "")
        min_duration_ms = int(slot.get("min_duration_ms") or slot.get("duration_ms") or 0)
        type_matches = media_type_matches(expected_media_type, actual_media_type)
        probe = probe_media(file_path, actual_media_type) if exists else {"warnings": []}
        actual_orientation = str(probe.get("orientation") or "")
        duration_ms = int(probe.get("duration_ms") or 0)
        duration_ok = not duration_ms or not min_duration_ms or duration_ms >= min_duration_ms
        orientation_matches = not actual_orientation or not expected_slot_orientation or actual_orientation == expected_slot_orientation
        warnings = list(probe.get("warnings") or [])
        if actual_orientation and expected_slot_orientation and actual_orientation != expected_slot_orientation:
            warnings.append(f"素材方向为 {actual_orientation}，槽位建议为 {expected_slot_orientation}。")
        media_report.append(
            {
                "slot_index": index,
                "status": "ok" if index in media_slot_indices and exists and type_matches and duration_ok and not duplicate else "invalid",
                "file_path": raw_path,
                "exists": exists,
                "media_type": actual_media_type,
                "expected_media_type": expected_media_type,
                "type_matches": type_matches,
                "duration_ms": duration_ms,
                "min_duration_ms": min_duration_ms,
                "duration_ok": duration_ok,
                "width": probe.get("width") or 0,
                "height": probe.get("height") or 0,
                "orientation": actual_orientation,
                "expected_orientation": expected_slot_orientation,
                "orientation_matches": orientation_matches,
                "warnings": warnings,
            }
        )

    errors: list[str] = []
    missing_text_indices = sorted(text_slot_indices - seen_text_indices)
    missing_media_indices = sorted(media_slot_indices - seen_media_indices)
    if missing_text_indices:
        errors.append(f"缺少文字槽位替换项: {missing_text_indices}")
    if missing_media_indices:
        errors.append(f"缺少素材槽位替换项: {missing_media_indices}")
    if len(seen_text_indices) < len(plan_items(plan, "text_replacements")):
        errors.append("存在重复文字槽位替换项")
    if len(seen_media_indices) < len(plan_items(plan, "media_replacements")):
        errors.append("存在重复素材槽位替换项")
    if any(item["status"] != "ok" for item in text_report):
        errors.append("存在无效文字替换项")
    over_limit_items = [item for item in text_report if item.get("over_limit")]
    if over_limit_items:
        details = [
            f"槽位 {item['slot_index']} 当前 {item['chars']} 字，最多 {item['char_limit']} 字"
            for item in over_limit_items
        ]
        errors.append("文字超出模板槽位字数限制: " + "；".join(details))
    under_limit_items = [item for item in text_report if item.get("under_limit")]
    if under_limit_items:
        details = [
            f"槽位 {item['slot_index']} 当前 {item['chars']} 字，至少 {item['char_min']} 字"
            for item in under_limit_items
        ]
        errors.append("文字低于模板槽位建议字数: " + "；".join(details))
    if any(item["status"] != "ok" for item in media_report):
        errors.append("存在无效素材替换项")
    if not draft_output_dir.exists():
        errors.append("剪映草稿输出目录不存在，需要创建或重新设置")
    warnings = [
        warning
        for item in media_report
        for warning in item.get("warnings", [])
    ]

    return {
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "message": "生成计划已校验，请交给小圆 XYCut 客户端完成最终草稿组装。"
        if not errors
        else "生成计划校验未通过，请修正后再交给小圆 XYCut 客户端。",
        "client_command": "generate_ai_editing_draft",
        "client_api": {
            "method": "POST",
            "url": "http://127.0.0.1:17651/ai-editing/generate",
            "body": {
                "mode": "hot_template",
                "template_slug": config.get("slug") or config.get("template_slug") or template_dir.name,
                "template_dir": str(template_dir),
                "template_config_file": str(template_config_file),
                "draft_output_dir": str(draft_output_dir),
                "generation_plan": plan,
            },
        },
        "template_dir": str(template_dir),
        "template_config_file": str(template_config_file),
        "draft_output_dir": str(draft_output_dir),
        "generation_plan_file": str(plan_path),
        "generation_plan_json": json.dumps(plan, ensure_ascii=False, separators=(",", ":")),
        "template_summary": {
            "template_name": config.get("name") or config.get("template_name") or template_dir.name,
            "template_slug": config.get("slug") or config.get("template_slug") or template_dir.name,
            "text_slots": len(text_slots),
            "media_slots": len(media_slots),
        },
        "validation": {
            "text_replacements": text_report,
            "media_replacements": media_report,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate a Xiaoying hot-template generation plan for the client assembler."
    )
    parser.add_argument("--template-dir", required=True)
    parser.add_argument("--template-config-file", required=True)
    parser.add_argument("--draft-output-dir", required=True)
    parser.add_argument("--generation-plan", required=True)
    parser.add_argument("--output", help="Optional path to write the validated client request JSON.")
    args = parser.parse_args()

    try:
        result = validate_plan(
            Path(args.template_dir),
            Path(args.template_config_file),
            Path(args.draft_output_dir),
            Path(args.generation_plan),
        )
        if args.output:
            write_json(Path(args.output), result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 2
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
