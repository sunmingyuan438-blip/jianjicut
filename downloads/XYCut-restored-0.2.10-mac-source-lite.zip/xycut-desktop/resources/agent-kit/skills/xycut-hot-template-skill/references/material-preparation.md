# 素材准备分支

## 核心原则

用户给了素材文件或素材目录，不等于同意整理进素材库。

素材整理是确认后的动作。没有用户明确选择“整理进素材库”前，不调用 `xycut-sucai-skill` 创建素材库、导入素材、分析素材或建立索引。

## 什么时候进入这个分支

读本文件的常见情况：

- 用户选择“使用当前素材库自动匹配”，但 `agent_context_file.sucai.library_id` 为空。
- 当前素材库为空，或没有可用于匹配的已整理素材。
- 用户给了一批素材文件或一个素材目录，但没有说明是临时使用还是整理进素材库。
- 用户说“先给你一堆素材”“这些素材后面还要用”“帮我整理这些素材”等。

## 用户给了素材，但没有明确要求整理

先询问，不要自动整理：

```text
你给的是一批素材。

这批素材要怎么处理？

A 只用于当前这个模板，不整理进素材库
B 整理进已有素材库，后续也能继续复用
C 创建一个新素材库，并把这批素材整理进去

如果选 B，请告诉我要归档到哪个素材库。
如果选 C，我可以默认用文件夹名作为素材库名称。
```

如果 `agent_context_file.sucai` 中没有任何素材库，或客户端上下文无法提供已有素材库信息，不显示 B：

```text
你给的是一批素材，但现在还没有素材库。

这批素材要怎么处理？

A 只用于当前这个模板，不整理进素材库
B 创建一个新素材库，并把这批素材整理进去，后续可以继续复用

如果选 B，我可以默认用文件夹名作为素材库名称。
```

## 用户选择 A：只用于当前模板

- 不调用 `xycut-sucai-skill`。
- 按 [material-strategy.md](material-strategy.md) 的“用户提供素材”处理。
- 如果用户给的是目录，优先由 Agent 按画面需求选择合格素材；只有素材顺序明显影响结果、素材不足或无法判断时，才列出文件让用户确认顺序。
- 最终在当前模板的 `generation_plan.json` 中写 `media_replacements`。

## 用户选择 B/C：整理进素材库

先确认三件事：

- 素材来源目录或文件列表。
- 目标素材库：已有素材库名称，或新素材库名称。
- 整理完成后是否继续回到当前爆款模板生成。

确认后再调用 `xycut-sucai-skill`。爆款模板 Skill 只负责转交和恢复流程，不复制素材整理细节。

建议在当前 `<task_dir>\hot_template_analysis.json` 记录：

```json
{
  "status": "waiting_material_library",
  "template_config_file": "...",
  "agent_context_file": "...",
  "user_topic": "...",
  "copywriting_strategy": "A/B/C",
  "material_strategy": "prepare_library",
  "material_source_paths": [],
  "target_library_name": "...",
  "return_to_hot_template_after_ready": true
}
```

## 调用素材库 Skill 后

素材库整理完成后，回到当前爆款模板任务：

1. 读取更新后的 `agent_context_file.sucai`。
2. 确认素材库中已有已理解、可匹配的素材。
3. 按 [material-strategy.md](material-strategy.md) 导出轻量候选。
4. 继续文案、素材安排、字数校验和客户端生成流程。

## 禁止

- 不要因为用户拖入文件夹就默认创建素材库。
- 不要在爆款模板 Skill 中实现抽帧、分析、入库、向量化细节。
- 不要把完整素材库 DB 或大量素材描述贴进对话。
- 不要在用户还没确认目标素材库时移动、复制或删除素材。
