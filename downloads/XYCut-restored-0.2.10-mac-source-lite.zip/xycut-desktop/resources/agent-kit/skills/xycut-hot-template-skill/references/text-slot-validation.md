# 文字槽字数校验

## 原则

字数检查由代码完成，文案优化由 Agent 完成。

代码只负责数数和判定，不自动截断、不自动改写。自动截断容易破坏语义和节奏。

## 字数来源

校验脚本会同时读取文字槽下限和上限。模板原始文案字数是硬上限；如果 `original_text` 是 20 字，即使旧模板里写着 `15-25字`，实际校验范围也按 `18-20字` 处理。

上限按顺序读取：

1. `max_chars`
2. `limit_chars`
3. `char_limit`
4. `slot_max_chars`
5. 从 `suggest_chars` 中提取最大值，例如 `18-20字` 取 `20`

下限优先从 `suggest_chars` 中提取最小值，例如 `18-20字` 取 `18`；同时不能低于 `original_text` 可见字数的 `0.9` 倍。

脚本计算可见字数时会去掉空白字符。

## Agent 必须执行

1. Agent 先根据模板槽位写文案。
2. 写入 `generation_plan.json`。
3. 运行 `generate_from_template.py` 校验。
4. 如果 `validation.text_replacements[].under_limit` 或 `validation.text_replacements[].over_limit` 为 `true`，读取脚本返回的：
   - `slot_index`
   - `chars`
   - `char_min`
   - `char_limit`
   - `under_limit`
   - `over_limit`
   - `suggest_chars`
   - `text`
5. Agent 重写太短或超出的槽位。
6. 重新运行校验。
7. 全部通过后，才允许调用客户端生成草稿。

连续 3 次重写仍无法通过时，再停下来告诉用户受限槽位、建议字数范围和当前表达难点，请用户确认是否改表达方向。

## 禁止

- 不要让代码自动截断文案。
- 不要第一次超字数就把错误甩给用户。
- 不要为模板参数文件中不存在的槽位创建替换项。
