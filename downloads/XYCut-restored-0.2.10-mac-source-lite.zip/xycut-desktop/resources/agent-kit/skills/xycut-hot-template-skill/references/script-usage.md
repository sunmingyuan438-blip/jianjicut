# 脚本使用

## Skill 更新和 Python 环境

先检查当前已安装的 `xycut-hot-template-skill` 版本。Windows 默认安装目录通常是：

```text
C:\Users\Administrator\.codex\skills\xycut-hot-template-skill
```

从 `agent_context_file.skills["xycut-hot-template-skill"].version` 读取客户端期望版本。从 `install_dir` 读取小圆 XYCut 分发的 Skill 源目录。

如果客户端期望版本高于当前 Skill，先从 `install_dir` 拷贝/覆盖到 Agent 的 skills 目录后再继续。

运行脚本前确认已安装 Skill 根目录包含：

- `scripts/check_runtime.py`
- `scripts/setup_runtime.py`
- `scripts/generate_from_template.py`

先用 Agent 当前可用的 Python 运行环境检查；如果能创建 venv，脚本会使用 `<agent_workdir>\.xycut-agent-runtime\.venv`，如果创建失败，会自动回退到小圆 XYCut 客户端已安装的 `runtime\python39\python.exe`：

```powershell
python <installed_skill_dir>\scripts\check_runtime.py
python <installed_skill_dir>\scripts\setup_runtime.py --install
```

读取 `setup_runtime.py` 输出 JSON 中的 `python` 字段，作为后续校验命令里的 `<runtime_python>`。这个字段可能是 venv Python，也可能是客户端 runtime Python；不要手写固定路径。

Windows 默认 venv 路径：

```text
<agent_workdir>\.xycut-agent-runtime\.venv\Scripts\python.exe
```

Windows 客户端 runtime 兜底路径：

```text
%LOCALAPPDATA%\com.xiaoyuan.jianji\runtime\python39\python.exe
```

如果 `setup_runtime.py` 返回 `ok: false`，提示用户先到小圆 XYCut ：`设置 -> 启动 AI 剪辑 -> 安装运行环境`。

如果 `agent_context_file.tools.ffprobe_path` 存在，运行校验脚本前可以设置环境变量 `XYCUT_FFPROBE_PATH` 为该路径。脚本也会自动尝试从小圆 XYCut 客户端运行目录 `%LOCALAPPDATA%\com.xiaoyuan.jianji\runtime\ffmpeg` 查找 `ffprobe`，不要求用户把 FFmpeg 加到系统 PATH。

## generation_plan.json

基础格式：

```json
{
  "draft_name": "xycut_0903220608",
  "text_replacements": [
    {
      "slot_index": 1,
      "text": "第一段文案"
    }
  ],
  "media_replacements": [
    {
      "slot_index": 1,
      "file_path": "D:\\素材\\01.mp4"
    }
  ]
}
```

规则：

- `slot_index` 必须来自模板参数文件中的 `index`。
- 不允许为不存在的槽位创建替换项。
- 爆款模板的所有启用素材位都必须写入 `media_replacements`，不能保留模板示例素材。
- 默认草稿名使用 `xycut_月日时分秒`，不要用画面标题当草稿目录名。
- 新版爆款模板的 `template_config_file` 是给 Agent 读取的轻量文件，其中的 `assembly_config_file` 是相对 `template_config_file` 所在目录的完整组装参数文件名；校验和客户端生成请求仍传入 `template_config_file`，不要把路径替换成 `assembly_config_file`。

## 校验命令

Windows：

```powershell
<runtime_python> <installed_skill_dir>\scripts\generate_from_template.py --template-dir "<template_dir>" --template-config-file "<template_config_file>" --draft-output-dir "<draft_output_dir>" --generation-plan "<task_dir>\generation_plan.json" --output "<task_dir>\client_request.json"
```

macOS/Linux：

```bash
<runtime_python> <installed_skill_dir>/scripts/generate_from_template.py --template-dir "<template_dir>" --template-config-file "<template_config_file>" --draft-output-dir "<draft_output_dir>" --generation-plan "<task_dir>/generation_plan.json" --output "<task_dir>/client_request.json"
```

脚本只负责校验模板参数、文字槽字数、素材路径和生成计划，不直接生成剪映草稿。

如果返回 `ok: false`，按 `errors` 和 `validation` 修正计划，不要继续组装。

如果返回 `ok: true`，读取 `client_api`，交给客户端生成。
