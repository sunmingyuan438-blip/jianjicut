# 输入解析和模板定位

## 目标

从用户复制的自然语言提示词中解析任务，并用 `agent-context.json` 定位模板、草稿目录、Skill 分发目录和本地客户端接口。

## 解析字段

从提示词中读取：

- `Agent 上下文文件` 后一行：`agent_context_file`
- `任务`：`单个模板` 或 `批量生成`
- `模板`：单模板名称，或批量模板列表
- `模板标识`：如果存在，优先当作 slug
- `素材库`：只作为用户可读提示；实际素材库信息仍从 `agent_context_file.sucai` 读取

## 读取 agent-context

必须先读取 `agent_context_file`。常用字段：

- `paths.draft_output_dir`
- `paths.hot_templates_dir`
- `paths.local_hot_templates_dir`
- `paths.local_hot_template_index_file`
- `skills["xycut-hot-template-skill"].version`
- `skills["xycut-hot-template-skill"].install_dir`
- `skills["xycut-sucai-skill"].install_dir`
- `sucai`
- `tools.ffmpeg_path`
- `tools.ffprobe_path`
- `local_api.base_url`
- `local_api.generate_url`

不要把密钥写入回复。

## 定位模板参数文件

对每个模板名称或 slug 按顺序查找：

1. `paths.hot_templates_dir\<template_slug>\<template_slug>.template.json`
2. `paths.local_hot_templates_dir\<template_slug>\<template_slug>.template.json`
3. 读取 `paths.local_hot_template_index_file`，用模板名称或 slug 反查 `template_config_file`

找到 `template_config_file` 后，不要期待模板 JSON 内包含实际路径。按来源确定 `template_dir`：

- 命中 `paths.hot_templates_dir\<template_slug>\<template_slug>.template.json` 时，`template_dir` 为 `paths.hot_templates_dir\<template_slug>\<template_slug>`。
- 命中 `paths.local_hot_templates_dir\<template_slug>\<template_slug>.template.json` 时，优先读取 `paths.local_hot_template_index_file` 中同 slug 的 `template_dir`。
- 通过本地索引反查到模板时，使用索引记录里的 `template_dir`。

不要从提示词中猜测模板目录，也不要要求 `template_config_file` 或 `assembly_config_file` 内写入用户机器的实际路径。

新版爆款模板可能同时包含 `assembly_config_file`。该字段是相对 `template_config_file` 所在目录的组装参数文件名；Agent 只需要读取轻量的 `template_config_file` 来理解槽位、分组和素材要求，不要主动读取 `assembly_config_file`。

如果找不到模板参数文件，让用户回到小圆 XYCut 安装模板后重新复制提示词。

## 批量任务

批量任务共享用户主题和素材策略，但每个模板必须：

- 独立创建子任务目录
- 独立读取 `template_config_file`
- 独立生成文案
- 独立写 `generation_plan.json`
- 独立调用客户端生成草稿

不要把同一份文案原样套用到多个模板。
