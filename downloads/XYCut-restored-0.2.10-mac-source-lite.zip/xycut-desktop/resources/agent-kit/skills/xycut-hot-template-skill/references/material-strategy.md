# 素材策略

## 两种素材策略

用户需要选择：

- 1 使用当前素材库自动匹配
- 2 用户自己提供素材文件/目录

爆款模板的原素材只是示例素材，必须替换；不要提供“只替换文案、保留模板原素材”的选项。

## 策略 1：素材库自动匹配

从 `agent_context_file.sucai` 读取素材库上下文：

- `db_path`
- `library_id`
- `library_name`
- `library_root`
- `collection_id`
- `collection_name`

从 `agent_context_file.skills["xycut-sucai-skill"].install_dir` 找到素材库 Skill。调用候选检索脚本时，只导出每个素材位 Top 10 到 Top 20 的轻量候选。

Agent 只查看轻量字段，例如：

- 素材路径
- summary
- keywords
- 时长
- 方向
- 质量分

不要读取或复制完整数据库。

## 策略 2：用户提供素材

让用户提供素材文件、素材目录或明确素材顺序。

如果用户给了一批素材文件或素材目录，但没有明确说明“只用于当前模板”还是“整理进素材库以后复用”，先读 [material-preparation.md](material-preparation.md)，询问用户如何处理。不要默认调用素材库 Skill。

如果用户只给目录，优先由 Agent 按画面需求选择合格素材；只有素材顺序明显影响结果、素材不足或无法判断时，才列出文件让用户确认顺序。

`media_slots` 中的 `material_type` 是模板原始素材类型；用户提供图片或视频都可以作为替换素材，最终由客户端按实际文件类型写入草稿。

## 素材位规则

- 只根据 `media_slots` 数量安排素材。
- 所有启用的 `media_slots` 都必须写入 `media_replacements`。
- 不要把 `resources`、锁定轨道、装饰元素、背景音乐当成用户需要提供的素材位。
- 如果用户要求替换数量超过 `media_slots`，只处理模板参数文件中列出的槽位，并说明多出来的素材未使用。
