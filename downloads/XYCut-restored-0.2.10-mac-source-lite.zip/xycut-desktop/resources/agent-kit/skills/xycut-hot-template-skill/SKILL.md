---
name: xycut-hot-template-skill
description: 使用小圆 XYCut 的爆款模板生成剪映草稿。遇到“小圆爆款模板”“爆款模板”“hot_template”“template_config_file”“用这个模板生成视频”“替换模板文字和素材”“sucai_library”等请求时使用；最终草稿组装必须交给小圆 XYCut 客户端。
metadata:
  version: 0.1.33
---

# 小圆爆款模板 Skill

## 目标

把用户从小圆 XYCut 复制出来的爆款模板提示词，转成一个可执行的剪映草稿生成流程。

Agent 负责理解用户主题、选择文案策略、选择素材策略、生成替换计划和核对结果；最终剪映草稿组装必须交给小圆 XYCut 客户端。客户端负责登录态、会员/积分权益校验、模板固定元素保留、资源重链和草稿写入。

## 硬性停止条件

- 没有读取 `Agent 上下文文件` 前，不定位模板、不调用本地客户端接口。
- 没有读取 `template_config_file` 前，不创作文案、不安排素材。
- 没有拿到“主题/资料、文案策略、素材策略”前，不导出素材候选、不写 `generation_plan.json`。
- 爆款模板的示例素材必须替换；不提供“只替换文案、保留模板原素材”的选项。
- 用户给了素材文件或目录，不等于同意整理进素材库；没有明确确认前，不调用 `xycut-sucai-skill` 入库整理。
- 文案低于或超出模板文字槽字数范围时，不允许继续生成草稿；必须由 Agent 重写后重新校验。
- 用户已经提供主题/资料并选择文案策略和素材策略后，视为授权本次爆款模板继续到生成；不要在校验通过后再次要求“确认生成”。
- 批量模板必须每个模板独立读取参数、独立创作文案、独立生成草稿；不要把同一份文案原样套用到多个模板。
- Agent 不直接写剪映草稿目录，不手写或修补剪映内部 JSON 字段，不绕过客户端生成草稿。

## 职责边界

- `text_slots` 和 `media_slots` 是唯一允许替换的槽位来源。
- `text_group_summary` 是给 Agent 快速理解分组的人话摘要；如果存在，先读它，再用 `text_group_hints` 和 `text_slots` 落槽。
- `text_group_hints` 只作为 Agent 理解文字结构的辅助依据；它不能新增槽位，最终仍必须写入 `text_slots` 中已有的 `index`。
- 新版模板会把 Agent 读取的轻量参数写在 `*.template.json`，把客户端组装所需的完整参数写在 `*.assembly.json`；两个文件都不写入用户机器的实际路径，`assembly_config_file` 只保存相对文件名。Agent 默认只读取 `template_config_file`，不要主动展开 `assembly_config_file`。
- 不重新扫描模板草稿来新增文字槽或素材槽。
- 不读取或展开 `excluded_*` 项来新增替换内容；后台未勾选的项目默认固定保留。
- 模板样式复刻、固定内容复制、资源路径修复、未引用材料清理，由客户端和 Python core 处理。
- 素材库的扫描、抽帧、理解、向量化和入库归 `xycut-sucai-skill`；本 Skill 只读取已整理素材库的候选。
- `generation_plan.json`、`client_request.json`、`hot_template_analysis.json` 等文件只作为 Agent、脚本和客户端之间的中间数据；不要把它们当成普通用户的结果或操作入口。

## 输入

用户提示词是普通文本，不要求用户阅读或编辑 JSON。至少包含：

```text
Agent 上下文文件：
xxx\com.xiaoyuan.jianji\agent-context.json

任务：单个模板
模板：xycut_news_005
```

批量任务包含多个模板：

```text
任务：批量生成
模板：
1. xycut_news_015
2. xycut_news_014
```

提示词中的 `Agent 上下文文件` 是唯一必须直接读取的用户本机路径。草稿目录、模板根目录、Skill 分发目录、本地客户端接口、素材库 DB 和第三方 API 等通用信息，都从这个文件读取。

## 任务目录

- 每次独立任务创建：`<agent_workdir>\xycut-tasks\<task_id>`。
- `task_id` 建议：`YYYYMMDD_HHMMSS_<template_slug>`。
- 批量任务创建父目录：`<agent_workdir>\xycut-tasks\<YYYYMMDD_HHMMSS>_hot_template_batch`，每个模板一个子目录。
- 主文件：`<task_dir>\hot_template_analysis.json`。
- 执行计划：`<task_dir>\generation_plan.json`。
- 客户端请求：`<task_dir>\client_request.json`。
- 所有中间文件都写入 `<task_dir>`，禁止散落在 Agent 工作目录根部。

## 路由

收到任务后按需读取下面的 reference，不要一次性读取所有文件：

- 解析自然语言提示词、agent-context、单模板/批量模板：读 [references/input-routing.md](references/input-routing.md)。
- 文案策略、开始前提问、爆款新闻文案写法：读 [references/copywriting-strategy.md](references/copywriting-strategy.md)。
- 素材策略、素材库候选、用户自带素材：读 [references/material-strategy.md](references/material-strategy.md)。
- 用户给了素材但没有素材库，或可能需要先归档整理素材：读 [references/material-preparation.md](references/material-preparation.md)。
- 文字槽字数检查、太短或超字数重写规则：读 [references/text-slot-validation.md](references/text-slot-validation.md)。
- Python 环境、脚本命令、`generation_plan.json` 格式：读 [references/script-usage.md](references/script-usage.md)。
- 交给小圆 XYCut 客户端预览/生成、成功回复：读 [references/preview-and-generate.md](references/preview-and-generate.md)。

## 推荐主流程

1. 读 [input-routing.md](references/input-routing.md)，解析 `agent_context_file`、任务类型和模板名称。
2. 定位并读取每个模板的 `template_config_file`，确认 `text_slots`、`media_slots`，并优先查看是否存在 `text_group_hints`。如果存在 `assembly_config_file`，只把它当作相对 `template_config_file` 所在目录的组装文件名记录，不要为了创作文案而读取完整组装文件。
3. 读 [copywriting-strategy.md](references/copywriting-strategy.md) 和 [material-strategy.md](references/material-strategy.md)，一次性向用户询问主题/资料、文案策略和素材策略。槽位概况只用于内部判断，不要主动发给用户。
4. 如果用户给了素材但没有明确是否整理入库，再读 [material-preparation.md](references/material-preparation.md)。
5. 按用户选择创作文案并替换全部素材位。
6. 读 [text-slot-validation.md](references/text-slot-validation.md) 和 [script-usage.md](references/script-usage.md)，写入并校验 `generation_plan.json`。
7. 如果脚本返回文字超字数，Agent 重写超出的槽位，再重新校验。
8. 校验通过后，读 [preview-and-generate.md](references/preview-and-generate.md)，调用小圆 XYCut 客户端生成草稿；不要再次要求用户确认生成。

## 完成回复

若缺少主题/策略、需要选择 B 的文案方向、需要确认素材入库，或校验失败，则说明当前状态并等待用户补充。

生成成功后，最终回复只面向普通用户：

```md
# 剪映草稿已生成：<草稿名称>

请打开剪映草稿箱，搜索上面的草稿名称并打开继续编辑。
```

批量生成时，按草稿名称逐行列出即可。不要默认列出 `generation_plan.json`、`client_request.json`、`hot_template_analysis.json`、素材候选 JSON、任务目录或其他中间文件。只有用户明确要求排查或调试时，才补充这些路径。

## 安全边界

- 不覆盖用户原始模板。
- 不删除用户素材。
- 不修改小圆 XYCut 安装目录中的模板。
- 不在本 Skill 中做素材库前置分析、抽帧、向量化或分类整理。
- 最终草稿组装不能在 Skill 中绕过客户端。
