# remake_plan.json 协议

`remake_plan.json` 是爆款复刻的执行计划。它把模板提取结果、用户新文案和素材匹配结果连接起来。

## 顶层字段

```json
{
  "version": "0.1",
  "draft_name": "爆款复刻_001",
  "template_design_file": "D:\\task\\template\\template_design.json",
  "layout_design_file": "D:\\task\\template\\layout_design.json",
  "rhythm_design_file": "D:\\task\\template\\rhythm_design.json",
  "source_brief": {},
  "script_segments": [],
  "text_replacements": [],
  "media_plan": [],
  "audio_plan": {},
  "warnings": []
}
```

## source_brief

记录用户的新内容输入：

```json
{
  "topic": "新视频主题",
  "copywriting_strategy": "保持参考视频的新闻口吻",
  "material_strategy": "使用素材库候选",
  "source_text": "用户原始文案或资料"
}
```

## script_segments

把用户新文案拆成与节奏段匹配的片段：

```json
{
  "index": 1,
  "rhythm_segment_index": 1,
  "start_ms": 0,
  "end_ms": 1800,
  "text": "新的第一段文案",
  "role": "headline"
}
```

## text_replacements

映射到 `layout_design.text_blocks`：

```json
{
  "text_block_index": 1,
  "source_text": "参考图里的原文字",
  "replacement_text": "你的新标题",
  "fit_status": "ok"
}
```

## media_plan

按 `rhythm_design.segments` 匹配素材：

```json
{
  "rhythm_segment_index": 1,
  "target_start_ms": 0,
  "target_duration_ms": 1800,
  "material_id": "library-item-001",
  "file_path": "D:\\materials\\clip001.mp4",
  "source_start_ms": 0,
  "source_duration_ms": 1800,
  "fit_reason": "超市场景，与参考段落一致"
}
```

## audio_plan

```json
{
  "mode": "keep_reference_audio",
  "audio_path": "D:\\task\\template\\audio\\source.mp3",
  "volume": 1.0
}
```

可选 `mode`：

- `keep_reference_audio`：保留参考音频。
- `replace_bgm`：替换 BGM。
- `none`：不放音频。

## 校验原则

- `replacement_text` 不应直接等于参考原文，除非用户要求原样复刻。
- 每个需要替换的主要文字块都应有 `text_replacements`。
- 每个节奏段都应有素材或明确说明使用模糊背景/固定背景。
- 如果素材不足，先向用户说明缺口，不要硬生成明显空洞的视频。
