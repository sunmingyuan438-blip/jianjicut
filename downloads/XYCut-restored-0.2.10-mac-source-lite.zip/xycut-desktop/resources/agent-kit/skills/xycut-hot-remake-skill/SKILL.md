---
name: xycut-hot-remake-skill
description: 使用小圆 XYCut 做爆款复刻；从参考截图或视频提取版式和节奏模板，再结合用户文案与素材生成新的剪映草稿。适用于“爆款复刻”“照这个视频做一条”“用我的文案复刻这个模板”“hot_remake”等请求。
metadata:
  version: 0.1.0
---

# 小圆爆款复刻 Skill

## 目标

把参考爆款截图或视频拆成可复用模板资产，再用用户的新文案和素材生成一条新的剪映草稿。

本 skill 是编排型能力，复用两类已有能力：

- 模板提取：复用 `xycut-template-designer-skill` 的版式分析、视频抽帧、音频提取和 `layout_design.json` / `rhythm_design.json` 协议。
- 创作剪辑：复用小圆爆款模板/视频模板的文案落槽、素材匹配和客户端草稿生成能力。

## 职责边界

- 不复制模板设计逻辑；需要版式或节奏提取时，按模板设计 skill 的协议产出模板资产。
- 不直接手写剪映完整草稿；最终草稿仍交给小圆 XYCut 客户端或 core API 生成。
- 不把参考视频的原文字当作最终文案，除非用户明确要求“原样复刻”。
- 不在未确认素材策略时整理用户素材库；素材入库仍遵循现有素材库 skill 的边界。

## 输入

用户通常会提供：

- 参考截图或参考视频。
- 新文案、主题、资料，或希望 Agent 帮忙生成的新文案方向。
- 用户素材目录、素材库，或允许使用已有素材库候选。
- 小圆 XYCut 的 `agent_context_file`。

如果缺少新文案/主题和素材策略，先询问，不要直接生成。

## 输出文件

任务目录建议：

```text
task_dir/
  template/
    layout_design.json
    rhythm_design.json
    template_design.json
  remake/
    remake_brief.json
    remake_plan.json
    client_request.json
```

## 主流程

1. 读取 `agent_context_file`，确认客户端 API、草稿目录和素材库能力。
2. 提取参考模板资产：
   - 截图：生成 `layout_design.json`。
   - 视频：抽 3 到 5 帧、提取音频，生成 `layout_design.json` 和 `rhythm_design.json`。
3. 获取用户新内容：
   - 新文案或主题资料。
   - 素材来源：素材库、用户目录、用户指定文件。
4. 生成 `remake_plan.json`：
   - 把新文案拆成与参考节奏匹配的段落。
   - 把段落映射到 `layout_design` 的文字块或文字组。
   - 按 `rhythm_design.segments` 匹配素材、时长和节奏。
5. 校验：
   - 文案长度适配文字框。
   - 素材数量和时长覆盖节奏段落。
   - 不能把参考文字误当成最终文案。
6. 调用客户端/API 生成新的剪映草稿。

## 需要读取的参考

- `references/remake-plan-schema.md`：写 `remake_plan.json` 时读取。
- 如需解释模板提取产物，读取 `xycut-template-designer-skill/references/template-assets.md` 和 `rhythm-design-schema.md`。

## 完成回复

生成成功后只面向普通用户回复：

```md
# 剪映草稿已生成：<草稿名称>

请打开剪映草稿箱，搜索上面的草稿名称并打开继续编辑。
```

不要默认暴露 `layout_design.json`、`rhythm_design.json`、`remake_plan.json` 等中间文件；只有用户要求排查时再提供。
