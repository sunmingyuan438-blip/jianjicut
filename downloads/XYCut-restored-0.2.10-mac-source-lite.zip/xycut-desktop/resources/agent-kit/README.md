# 小圆 XYCut Agent Kit

这是安装包裁剪后的 Agent Skill 资源目录。
这里只包含 Agent 使用 Skill 所需的说明、前置分析脚本和统一工作台前端资源，不包含客户端 Python core 源码、加密脚本、临时目录或开发文件。

包含 Skills：xycut-hot-remake-skill, xycut-hot-template-skill, xycut-sucai-skill, xycut-template-designer-skill, xycut-video-template-skill
包含 Tools：editing-workbench/public
