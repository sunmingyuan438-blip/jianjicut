# Mac Delivery Repair Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Publish complete self-contained source and both precompiled Mac test bundles that external Macs can download and verify.

**Architecture:** Preserve the existing application payload; correct the resource preparation and binary transport. Re-read uploaded bytes from GitHub and require matching size, SHA-256 and ZIP CRC before claiming delivery.

**Tech Stack:** Node.js, Python, GitHub Git Data API, Electron.

**Spec:** User-provided Mac installation handoff report, 2026-10-10, this conversation.

## Global Constraints

- macOS 13 or higher; Apple Silicon arm64 and Intel x64.
- Include frontend, recovered core, Agent Kit, presets, draft shell, scripts, tests and restoration-build.json.
- Do not require a sibling xycut-recovered-0.2.10 directory on external machines.
- Use native CPython 3.9 for marshal bytecode, regardless of the system Python version.
- Do not run real cloud generation or billing tests.
- New source content must receive new truthful hashes; an old SHA cannot describe modified bytes.

## Task 1: Standalone resource preparation

- [ ] Update scripts/prepare-resources.cjs to prefer included resources.
- [ ] Move scripts/package-mac.py Windows app.asar verification into its assembly-only main entry.
- [ ] Extract into an isolated directory with no sibling recovery directory, run preparation, and compare required resource hashes.
- [ ] Import the Mac runtime preparation module with no dist/win-unpacked present; require successful import.

## Task 2: Reliable binary publication

- [ ] Assemble the complete Mac source ZIP with zipfile and require testzip() is None.
- [ ] Read binary payloads in chunks below the command-output cap; join Base64 in memory, create immutable Git blobs, and compare returned blob SHA against local Git blob SHA.
- [ ] Publish existing arm64/x64 precompiled archives as bounded Git parts with a SHA-256 manifest and download/reassembly script.
- [ ] Download remote bytes into a clean directory, reassemble, and require exact archive size, SHA-256 and ZIP CRC.

## Task 3: Source repository and tester instructions

- [ ] Include platform-neutral resources in the Git tree; ignore only generated native runtime/cache files.
- [ ] Update README.md, GITHUB_MAC_TEST.md and MAC_TEST_PROMPT.md around the verified downloads.
- [ ] Publish checksums only for files that can actually be obtained, and mark Mac runtime acceptance pending.
- [ ] Fetch final main tree and compare each published Git blob SHA against the local manifest.
